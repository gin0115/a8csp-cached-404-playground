# A8csp Cached 404 Page

A must-use plugin that answers requests for terms, posts and authors that do not exist with a light 404, before normal plugins, the theme and the main query load. Bots that walk a site's tag or post URLs with made-up slugs then cost one indexed query each instead of a full WordPress page load.

Each site chooses which URL types are answered, from **Settings → Cached 404** or WP-CLI. Anything the plugin is not sure about is left to WordPress.

The page sent is a static HTML file: the site's own 404, captured once from the theme, with the stylesheets and scripts you choose to keep. It is built when it is created or saved, and never at 404 time.

- [How a request is answered](#how-a-request-is-answered)
- [What it answers](#what-it-answers)
- [Requirements](#requirements)
- [Installation](#installation)
- [Settings → Cached 404](#settings--cached-404)
- [Creating the 404 page](#creating-the-404-page)
- [When the stored page is rebuilt](#when-the-stored-page-is-rebuilt)
- [Previewing](#previewing)
- [Filter](#filter)
- [WP-CLI](#wp-cli)
- [Stored data](#stored-data)
- [Development](#development)

## How a request is answered

1. A loader in `mu-plugins` requires `a8csp-cached-404-page.php`. While that file is included, before normal plugins and the theme load, `Request\EarlyResponse::maybe_send()` runs.
2. Only `GET` and `HEAD` requests are looked at, never admin, AJAX or cron requests, and nothing at all while the plugin is off or for the request that [captures](#creating-the-404-page) the site's own 404.
3. The site folder and any ticked [language folder](#translation-plugins) are removed from the request path, which is then matched against the ticked URL types. A match runs an indexed lookup, cached in the object cache group `a8csp_cached_404`.
4. When the item is missing, `Request\Responder::send()` sends status `404`, no-cache headers, an `X-A8CSP-404` header naming the URL type that answered, and streams the stored page file with `readfile()`. When no stored file can be read, it sends a plain "Not Found" page.
5. Anything else carries on into WordPress as normal.

Nothing is rendered at 404 time: the only work is reading the autoloaded `a8csp_cached_404_settings` option, the lookup, and streaming the file. Under a ticked Weglot folder, Weglot's two stored lists are read as well.

## What it answers

When the item does not exist:

- term archives under a base, such as `/tag/<slug>/` and `/category/<parent>/<child>/`, with their paged and embed forms;
- posts under a permalink structure with something in front of `%postname%`, such as `/%year%/%monthnum%/%day%/%postname%/`, with their paged and embed forms;
- single items of custom post types with a base, such as `/product/<slug>/`;
- author archives, `/author/<nicename>/`;
- with **Made-up paths after a single item** on, a made-up part after a post or item, such as `/product/<slug>/<made-up>/`, when no post or attachment has a name starting with it;
- with **Loose mode** on, any other address that the site's saved rewrite rules read as one page, attachment or item, such as `/2015/04/old-post/image/`, except `.xml` and `.xsl` files, which sitemap plugins may answer in their own code;
- any of these with a ticked [language folder](#translation-plugins) in front, such as `/fr/tag/<slug>/`.

Never: feeds, `/%postname%/` posts, post formats, admin, AJAX or cron requests, or any post whose name WordPress would redirect to (a name starting with the slug, or an old slug). Pages and attachments only in loose mode. `docs/ARCHITECTURE.md` explains each.

## Requirements

PHP 8.4 or later and WordPress 7.1 or later, as the plugin header declares (`Requires PHP`, `Requires at least`). Below either, it stays off and shows an admin notice. It works with block and classic themes.

## Installation

1. Put the `a8csp-cached-404-page` folder in `wp-content/mu-plugins/`.
1. WordPress only loads files in the root of `mu-plugins`, so a loader file there must require `a8csp-cached-404-page/a8csp-cached-404-page.php`. `tests/mu-loader.php` is a minimal one.
1. Turn it on under **Settings → Cached 404**, or with WP-CLI as below. It does nothing until it is on and at least one URL type is ticked.

The dashboard has a **Cached 404** widget showing whether it is on, how many URL types are on, whether the stored page is built and whether detection is up to date, with a link to the settings.

## Settings → Cached 404

![Settings → Cached 404](docs/images/settings.png)

Every change is applied with **Save changes**, which also re-reads the site's URL types and rebuilds the stored page.

| Box | What it does |
|---|---|
| **Status** | The main on/off. The line under it says what is happening now, including when loose mode is on. |
| **404 page** | Which page is sent: **Your site's own 404, captured** (see [Creating the 404 page](#creating-the-404-page)), an **Uploaded file** at `uploads/cached-404.html` (greyed out and marked "Not found" until the file exists), or **Plain "Not Found"**. Whichever is chosen, a missing file falls back to the plain page. Under the choices: what the last capture loaded and when, such as "32 stylesheets (15 files, 17 inline only) and 65 scripts (61 files, 1 inline only, 3 modules)", **Create the 404 page** (**Capture again** once there is one) and **View 404 page**. When the [filter](#filter) sets a file, a notice here says it overrules the choice. |
| **What to answer** | Tabs for **Archives**, **Single items** and, when a [translation plugin](#translation-plugins) is found, **Language folders**, each showing how many are ticked. Each URL type shows an example URL. Under the tabs, **Also answer** holds **Made-up paths after a single item** and **Loose mode** (see [What it answers](#what-it-answers)), then a line naming what cannot be answered on this site and why, such as posts and pages under `/%postname%/`. |
| **Advanced** | Closed unless paths are set. **Never answer**: paths, one per line, that always go to WordPress, such as `/tag/keep-me/`. **Cache**: also remember tags and categories that do not exist, for an hour. Found items are always remembered. |

## Creating the 404 page

The stored page is the site's own 404, as the theme shows it, captured once:

1. **Create the 404 page** in the **404 page** box opens a new window showing a made-up address, which WordPress answers with the theme's 404. The address carries a one-time key, made for that click and kept for ten minutes, so that request is left to WordPress, shown logged out (no toolbar, no user details), and stored with the stylesheets and scripts it loaded. Nothing else on the site is paused.
1. Once that page has loaded and five seconds have passed, the window closes, and the box lists what was loaded in two tabs, **Stylesheets** and **Scripts**. Files are grouped by where they come from (WordPress, the theme, each plugin, other, or inline only), each group with its ticked count, **Tick all** and **Untick all**. WordPress, theme and inline-only items are ticked; plugin and other files are not.
1. **Next: create the page** saves the ticks and writes the page to `uploads/a8csp-cached-404/404.html`: the captured 404, without the unticked stylesheets and scripts (each with its inline CSS or code, found by the IDs WordPress prints on them). It becomes the page in use, and **View 404 page** opens it.

The window needs pop-ups allowed for the site. Capture again after a theme or plugin update.

## Translation plugins

When a translation plugin puts languages in folders, such as `/fr/tag/anything/`, its folders are listed under **Language folders** in **What to answer**, and by `wp cached-404 prefix list`. A ticked plugin's folder is removed before the URL types are checked, so missing items in every language are answered too. Addresses without a folder are answered as before.

| Plugin | Folders listed |
|---|---|
| **Polylang** | Every language, when the language is set from the folder. Under `language/` when Polylang keeps that in the address. Subdomains and separate domains have no folders. Translations are ordinary terms and posts, so the usual lookups apply. |
| **TranslatePress** | Every published language; the default language only when TranslatePress gives it a folder. With the paid SEO Pack, which translates slugs, only the default language. |
| **Weglot** | Every public language, by the code in its address (the custom code when one is set). Weglot translates slugs, so each part of the address is swapped back to the original from Weglot's stored lists (`weglot_slugs_cache`, and `custom_urls` in `weglot_cache_cdn`) before the lookup, as Weglot does. When those lists are missing, or a part is an original Weglot would redirect to its translation, the request is left to WordPress. A language whose address code differs from its own code with no custom code set (`pt-br`, `zh-tw`, `sr-lt`) is always left to WordPress. |
| **WPML** | Every active language, when languages are in folders. Tested with stand-ins only, not against a real WPML install. |

Polylang 3.8, TranslatePress 3.3 and Weglot 6.4 are tested end to end against the real plugins (`tests/EndToEnd/polylang.spec.js`, `translatepress.spec.js`, `weglot.spec.js`); Weglot runs on made-up project settings, without reaching its servers.

## When the stored page is rebuilt

The stored page is written to `uploads/a8csp-cached-404/404.html` when:

- **Next: create the page** is pressed after a capture;
- **Save changes** is pressed under Settings → Cached 404;
- any WP-CLI command that changes settings runs, or `wp cached-404 page build`.

Each rebuild uses the last capture and the saved ticks. Before the first capture it writes a small placeholder page: the site name, "Page not found" and a link home.

## Previewing

**View 404 page** under Settings → Cached 404 opens `/?404-test=<nonce>`. For the logged-in user who opened it, the stored page is sent exactly as visitors get it, with status `404` and the header `X-A8CSP-404: preview`. It shows the page as last saved.

## Filter

`a8csp_cached_404_page_file` sets the absolute path of the page file, overruling the choice under **404 page**. Return `''` to use the chosen page.

```php
add_filter(
	'a8csp_cached_404_page_file',
	static fn (): string => WP_CONTENT_DIR . '/my-404.html'
);
```

The request check runs before normal plugins and the theme load, so the filter is not read at 404 time. It is read when the stored page is rebuilt (see above), and the path it returns is stored. After changing the filter, save the settings or run `wp cached-404 page build`.

## WP-CLI

```sh
wp cached-404 status
wp cached-404 enable | disable
wp cached-404 detect
wp cached-404 shortcut list | enable <key>... | disable <key>...
wp cached-404 prefix list | enable <key>... | disable <key>...
wp cached-404 exclude list | add <path>... | remove <path>...
wp cached-404 cache-misses on | off
wp cached-404 page build
wp cached-404 page source captured | file | plain
wp cached-404 export > choices.json
wp cached-404 import choices.json
```

`status` includes the page source, any file the filter sets, and the stored page's path. `page source` warns when the filter overrules it. Capturing the 404 needs a browser, so it is only in Settings → Cached 404.

`export` holds only the choices (on/off, miss caching, which URL types and language folders are on, excluded paths), so it can be imported on a site with different URL bases; `import` runs detection on that site first.

## Stored data

| Name | Kind | Holds |
|---|---|---|
| `a8csp_cached_404_settings` | option, autoloaded | Every setting, the detected URL types and the stored page's path. |
| `a8csp_cached_404_html` | option | The captured 404, as WordPress sent it. |
| `a8csp_cached_404_styles` | option | The stylesheets the captured 404 loaded, and their inline CSS. |
| `a8csp_cached_404_scripts` | option | The scripts it loaded, and the enqueued script modules with every module they import. |
| `a8csp_cached_404_ticked` | option | The ticked stylesheets and scripts. |
| `a8csp_cached_404_recorded_at` | option | When the 404 was last captured. |
| `a8csp_cached_404_capture` | transient | The one-time key of a capture in progress, for ten minutes. |
| `uploads/a8csp-cached-404/404.html` | file | The stored page built from the capture. |
| `a8csp_cached_404` | object cache group | Lookup results for the request check. |

## Development

Install dependencies, build the assets, and start the local environment:

```sh
composer install
npm install
npm run build
npm run wp-env:start
```

The plugin loads as a must-use plugin at the wp-env port declared in `.wp-env.json`; `tests/README.md` documents the test environments. wp-env publishes the site on all network interfaces with fixed development credentials, so treat the dev site as visible to your local network, not just localhost.

The admin scripts are in `assets/js/src` and the styles in `assets/css/src`, all named `cached-404-*`. `npm run build` builds them into `assets/js/build` and `assets/css/build`, the same layout as a8csp-atlantis.

The architecture map and how to add a URL type or a translation plugin live in [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md); the build plan and its findings in [`docs/PLAN.md`](docs/PLAN.md); the test workflow in [`tests/README.md`](tests/README.md).

`composer.json` points at a fork of `a8csp/configs` (`gin0115/a8csp-configs`) that allows PHP 8.4 for local tooling. Before a pull request, switch the `repositories` entry back to `https://github.com/a8cteam51/a8csp-configs` and add `--runtime-set testVersion 8.4-` to the `lint:php:phpcs` and `lint:php:phpcs:tests` scripts.

`composer packages-update` and `npm run packages-update` update every dependency within the range its manifest declares. `npm run packages-update:wp` moves the `@wordpress/*` packages, across major versions, to the npm dist-tag named in the script; keep that tag at the plugin's WordPress floor.

### Releasing

Every pull request that changes behavior carries a changelog fragment:

```sh
composer changelog:add
```

The command asks for a significance (`patch`, `minor`, `major`), a type, and the entry text, then writes one file under `changelog/`; `-s`, `-t` and `-e` supply the same answers non-interactively. `composer changelog:validate` only checks the fragments that exist and passes on an empty directory, so a forgotten fragment surfaces as a missing release note rather than as a red check.

Releases are cut from trunk, in four steps.

1. **Materialize the changelog.** `composer changelog:write` derives the next version from the newest `CHANGELOG.md` entry and the pending fragments' significance, writes that section, and deletes the fragments it consumed. There is nothing to derive from while the changelog is empty, so the first release names its whole version with `--use-version`, a first prerelease included. Preview the derived version with `vendor/bin/changelogger version next`, which takes the same `--prerelease`, and pin the version with `--use-version` whenever the preview is not the release you mean:

   ```sh
   composer changelog:write -- --use-version=1.0.0-beta.1
   vendor/bin/changelogger version next --prerelease=beta.2
   composer changelog:write -- --prerelease=beta.2
   composer changelog:write -- --use-version=1.0.0
   ```

2. **Bump the other two versions to the same string.** The release refuses to run unless the plugin header's `Version:` in `a8csp-cached-404-page.php`, `"version"` in `package.json`, and the newest `CHANGELOG.md` heading all state one version. Commit the three together and land them on trunk.

3. **Let trunk go green, then rehearse.** The release reuses the trunk-push Quality and Tests runs from the exact commit it tags, so tag only once those have finished. With them green, run the **Release** workflow from the Actions tab leaving **Create the GitHub release** off: that exercises the version check, the provenance check, the build and the smoke install without creating anything.

4. **Tag the green commit and publish the tag.**

   ```sh
   git tag -s "v1.0.0" -m "v1.0.0"
   git push origin "v1.0.0"
   ```

   Pushing a `v*` tag runs the release, and the publish step passes `--verify-tag`, so the tag has to reach the remote before the release can be created.

The release history is [`CHANGELOG.md`](CHANGELOG.md).
