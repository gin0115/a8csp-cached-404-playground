<?php declare( strict_types=1 );
/**
 * The captured stylesheets and scripts as two tabbed checklists, grouped by where each file comes
 * from, with a ticked count and tick all or none per group.
 *
 * @since   1.0.0
 * @version 1.0.0
 * @package A8C\SpecialProjects\A8cspCached404Page
 *
 * @var array<string, array{label: string, items: array<string, array{label: string, url: string, notes: list<string>, group: string, default: bool}>, ticked: list<string>, note: string}> $a8csp_cached_404_lists The checklists, keyed `styles` and `scripts`.
 */

\defined( 'ABSPATH' ) || exit;

?>
<div class="a8csp-cached-404-tab-list" role="tablist">
	<?php
	$a8csp_cached_404_first = true;
	foreach ( $a8csp_cached_404_lists as $a8csp_cached_404_name => $a8csp_cached_404_list ) :
		$a8csp_cached_404_count = \count( \array_intersect( \array_map( 'strval', \array_keys( $a8csp_cached_404_list['items'] ) ), $a8csp_cached_404_list['ticked'] ) );
		?>
		<button type="button" role="tab" class="a8csp-cached-404-tab" id="<?php echo esc_attr( 'a8csp-cached-404-tab-' . $a8csp_cached_404_name ); ?>" aria-controls="<?php echo esc_attr( 'a8csp-cached-404-panel-' . $a8csp_cached_404_name ); ?>" aria-selected="<?php echo $a8csp_cached_404_first ? 'true' : 'false'; ?>">
			<?php echo esc_html( $a8csp_cached_404_list['label'] ); ?>
			<span class="a8csp-cached-404-tab-count"><span data-a8csp-cached-404-count="<?php echo esc_attr( $a8csp_cached_404_name ); ?>"><?php echo esc_html( (string) $a8csp_cached_404_count ); ?></span>/<?php echo esc_html( (string) \count( $a8csp_cached_404_list['items'] ) ); ?></span>
		</button>
		<?php
		$a8csp_cached_404_first = false;
	endforeach;
	?>
</div>
<?php
$a8csp_cached_404_first = true;
foreach ( $a8csp_cached_404_lists as $a8csp_cached_404_name => $a8csp_cached_404_list ) :
	$a8csp_cached_404_groups = array();
	foreach ( $a8csp_cached_404_list['items'] as $a8csp_cached_404_key => $a8csp_cached_404_item ) {
		$a8csp_cached_404_groups[ $a8csp_cached_404_item['group'] ][ (string) $a8csp_cached_404_key ] = $a8csp_cached_404_item;
	}
	?>
	<div role="tabpanel" class="a8csp-cached-404-panel" id="<?php echo esc_attr( 'a8csp-cached-404-panel-' . $a8csp_cached_404_name ); ?>" aria-labelledby="<?php echo esc_attr( 'a8csp-cached-404-tab-' . $a8csp_cached_404_name ); ?>" data-a8csp-cached-404-list="<?php echo esc_attr( $a8csp_cached_404_name ); ?>"<?php echo $a8csp_cached_404_first ? '' : ' hidden'; ?>>
		<?php if ( array() === $a8csp_cached_404_groups ) : ?>
			<p class="description"><?php esc_html_e( 'None were loaded.', 'a8csp-cached-404-page' ); ?></p>
		<?php endif; ?>
		<?php foreach ( $a8csp_cached_404_groups as $a8csp_cached_404_group => $a8csp_cached_404_items ) : ?>
			<details class="a8csp-cached-404-group">
				<summary>
					<span class="a8csp-cached-404-group-name"><?php echo esc_html( (string) $a8csp_cached_404_group ); ?></span>
					<span class="a8csp-cached-404-group-count">
						<?php
						/* translators: 1: number ticked, 2: number in the group */
						\printf( esc_html__( '%1$s of %2$s ticked', 'a8csp-cached-404-page' ), '<span class="a8csp-cached-404-group-ticked">' . esc_html( (string) \count( \array_intersect( \array_keys( $a8csp_cached_404_items ), $a8csp_cached_404_list['ticked'] ) ) ) . '</span>', esc_html( (string) \count( $a8csp_cached_404_items ) ) );
						?>
					</span>
				</summary>
				<div class="a8csp-cached-404-group-body">
					<p class="a8csp-cached-404-group-actions">
						<button type="button" class="button-link" data-a8csp-cached-404-tick="all"><?php esc_html_e( 'Tick all', 'a8csp-cached-404-page' ); ?></button> |
						<button type="button" class="button-link" data-a8csp-cached-404-tick="none"><?php esc_html_e( 'Untick all', 'a8csp-cached-404-page' ); ?></button>
					</p>
					<div class="a8csp-cached-404-grid">
						<?php foreach ( $a8csp_cached_404_items as $a8csp_cached_404_key => $a8csp_cached_404_item ) : ?>
							<label class="a8csp-cached-404-item">
								<input type="checkbox" name="<?php echo esc_attr( 'ticked[' . $a8csp_cached_404_name . '][]' ); ?>" value="<?php echo esc_attr( $a8csp_cached_404_key ); ?>"<?php checked( \in_array( $a8csp_cached_404_key, $a8csp_cached_404_list['ticked'], true ) ); ?> />
								<span class="a8csp-cached-404-item-name"><?php echo esc_html( $a8csp_cached_404_item['label'] ); ?></span>
								<span class="a8csp-cached-404-item-file"><?php echo esc_html( \implode( ' + ', $a8csp_cached_404_item['notes'] ) ); ?></span>
							</label>
						<?php endforeach; ?>
					</div>
				</div>
			</details>
		<?php endforeach; ?>
		<p class="description"><?php echo esc_html( $a8csp_cached_404_list['note'] ); ?></p>
	</div>
	<?php
	$a8csp_cached_404_first = false;
endforeach;
