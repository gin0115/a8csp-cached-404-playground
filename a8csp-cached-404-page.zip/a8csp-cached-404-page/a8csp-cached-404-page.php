<?php declare( strict_types=1 );
/**
 * The A8csp Cached 404 Page bootstrap file.
 *
 * This file must remain parsable on PHP versions below the plugin's declared floor, since it
 * runs before the requirements check can report a friendly error; a dedicated CI job lints it
 * directly against the older PHP versions.
 *
 * @since       1.0.0
 * @version     1.0.0
 * @package     A8C\SpecialProjects\A8cspCached404Page
 * @author      A8C Special Projects
 * @license     GPL-2.0-or-later
 *
 * @noinspection    ALL
 *
 * @wordpress-plugin
 * Plugin Name:             A8csp Cached 404 Page
 * Plugin URI:              https://specialprojects.automattic.com
 * Update URI:              https://github.com/a8cteam51/a8csp-cached-404-page
 * Description:             Answers requests for terms, posts and authors that do not exist with a light 404, before the rest of WordPress loads.
 * Version:                 1.0.0-RC3
 * Requires at least:       7.1
 * Tested up to:            7.1
 * Requires PHP:            8.4
 * Author:                  A8C Special Projects
 * Author URI:              https://specialprojects.automattic.com
 * License:                 GPL v2 or later
 * License URI:             https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:             a8csp-cached-404-page
 * Domain Path:             /languages
 */

\defined( 'ABSPATH' ) || exit;

// Define plugin constants.
\define( 'A8CSP_CACHED_404_FILE', __FILE__ );
\define( 'A8CSP_CACHED_404_BASENAME', plugin_basename( __FILE__ ) );
\define( 'A8CSP_CACHED_404_DIR_PATH', plugin_dir_path( __FILE__ ) );
\define( 'A8CSP_CACHED_404_DIR_URL', plugin_dir_url( __FILE__ ) );

// The bootstrap's helper functions live in functions-bootstrap.php, which shares this file's
// below-floor parse constraint; they must exist before the requirements gate below can reference them.
require_once A8CSP_CACHED_404_DIR_PATH . 'functions-bootstrap.php';

// Must-use plugins register their translations path themselves. Gettext calls still wait for `init` (JIT).
load_muplugin_textdomain( 'a8csp-cached-404-page', dirname( A8CSP_CACHED_404_BASENAME ) . '/languages' );

// Load the autoloader.
if ( ! \is_file( A8CSP_CACHED_404_DIR_PATH . 'vendor/autoload.php' ) ) {
	a8csp_cached_404_output_requirements_error( new WP_Error( 'missing_autoloader' ) );
	return;
}
require_once A8CSP_CACHED_404_DIR_PATH . 'vendor/autoload.php';

// Answer requests for missing items now, before normal plugins, the theme and the main query load,
// and before the requirements gate below reads the plugin header from disk. The versions are the
// `Requires PHP` and `Requires at least` header values, checked directly here for the same reason.
if ( a8csp_cached_404_is_php_version_compatible( '8.4' ) && a8csp_cached_404_is_wp_version_compatible( '7.1' ) ) {
	\A8C\SpecialProjects\A8cspCached404Page\Request\EarlyResponse::maybe_send();
}

// Bootstrap the plugin (maybe)!
if ( is_wp_error( a8csp_cached_404_validate_requirements() ) ) {
	a8csp_cached_404_output_requirements_error( a8csp_cached_404_validate_requirements() );
} else {
	require_once A8CSP_CACHED_404_DIR_PATH . 'functions.php';
	add_action( 'plugins_loaded', array( a8csp_cached_404_plugin(), 'boot' ) );
}
