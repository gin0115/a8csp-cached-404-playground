<?php declare( strict_types=1 );
/**
 * BELOW-FLOOR BOOTSTRAP: LEGACY PHP PARSABILITY IS REQUIRED.
 *
 * These are the bootstrap's helper functions: plugin metadata, version compatibility checks, the
 * requirements gate, and its admin-notice reporter.
 *
 * This file loads before the requirements check can run, so it MUST remain parsable on PHP
 * versions below the plugin's declared floor. No modern syntax beyond what it already carries
 * belongs in this file, and a dedicated CI job lints it directly against the older PHP versions.
 *
 * @since       1.0.0
 * @version     1.0.0
 * @package     A8C\SpecialProjects\A8cspCached404Page
 * @author      A8C Special Projects
 * @license     GPL-2.0-or-later
 */

\defined( 'ABSPATH' ) || exit;

/**
 * Returns the plugin's metadata.
 *
 * @since   1.0.0
 * @version 1.0.0
 *
 * @template PluginMetaKey of key-of<PluginMetaData>
 *
 * @param   PluginMetaKey|null $property Optional. The property to return. Default all.
 *
 * @return  ($property is null ? PluginMetaData : ($property is PluginMetaKey ? PluginMetaData[PluginMetaKey] : null))
 */
function a8csp_cached_404_get_plugin_metadata( $property = null ) {
	static $plugin_data = array();

	$can_translate = 0 < did_action( 'init' );
	$cache_key     = $can_translate ? 'translated' : 'raw';

	if ( isset( $plugin_data[ $cache_key ] ) ) {
		$metadata = $plugin_data[ $cache_key ];
	} else {
		if ( ! \function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$plugin_file = \constant( 'A8CSP_CACHED_404_FILE' );
		$metadata    = get_plugin_data( $plugin_file, false, $can_translate );

		// Extra plugin headers exist only once the plugin registering them has loaded, and this
		// plugin loads first, so a read is cached only from `plugins_loaded` onward.
		if ( 0 < did_action( 'plugins_loaded' ) ) {
			$plugin_data[ $cache_key ] = $metadata;
		}
	}

	if ( null === $property ) {
		return $metadata;
	}

	if ( \is_string( $property ) && isset( $metadata[ $property ] ) ) {
		return $metadata[ $property ];
	}

	return null;
}

/**
 * Returns the plugin's slug.
 *
 * @api
 *
 * @since   1.0.0
 * @version 1.0.0
 *
 * @return  string
 */
function a8csp_cached_404_get_plugin_slug() {
	$text_domain = a8csp_cached_404_get_plugin_metadata( 'TextDomain' );
	return sanitize_key( $text_domain );
}

/**
 * Returns the plugin's name.
 *
 * @api
 *
 * @since   1.0.0
 * @version 1.0.0
 *
 * @return  string
 */
function a8csp_cached_404_get_plugin_name() {
	return a8csp_cached_404_get_plugin_metadata( 'Name' );
}

/**
 * Returns the plugin's version.
 *
 * @api
 *
 * @since   1.0.0
 * @version 1.0.0
 *
 * @return  string
 */
function a8csp_cached_404_get_plugin_version() {
	return a8csp_cached_404_get_plugin_metadata( 'Version' );
}

/**
 * Checks compatibility with the current WordPress version.
 *
 * @since   1.0.0
 * @version 1.0.0
 *
 * @param   string $min_wp_version The minimum WP version required to run.
 *
 * @return  bool
 */
function a8csp_cached_404_is_wp_version_compatible( $min_wp_version ) {
	if ( ! \function_exists( 'is_wp_version_compatible' ) ) {
		return false;
	}

	return is_wp_version_compatible( $min_wp_version );
}

/**
 * Checks compatibility with the current PHP version.
 *
 * @since   1.0.0
 * @version 1.0.0
 *
 * @param   string $min_php_version The minimum PHP version required to run.
 *
 * @return  bool
 */
function a8csp_cached_404_is_php_version_compatible( $min_php_version ) {
	if ( ! \function_exists( 'is_php_version_compatible' ) ) {
		return false;
	}

	return is_php_version_compatible( $min_php_version );
}

/**
 * Validates the plugin requirements once per request; later calls return the result the entry
 * file acted on. Callers read the result here, never through a constant: below PHP 8.1,
 * `define()` rejects the `WP_Error` this returns.
 *
 * @since   1.0.0
 * @version 1.0.0
 *
 * @return  true|\WP_Error
 */
function a8csp_cached_404_validate_requirements() {
	static $result = null;
	if ( null !== $result ) {
		return $result;
	}

	$plugin_metadata = a8csp_cached_404_get_plugin_metadata();
	if ( ! isset( $plugin_metadata['RequiresPHP'] ) || '' === $plugin_metadata['RequiresPHP'] ) {
		$plugin_metadata['RequiresPHP'] = '8.4';
	}
	if ( ! isset( $plugin_metadata['RequiresWP'] ) || '' === $plugin_metadata['RequiresWP'] ) {
		$plugin_metadata['RequiresWP'] = '7.1';
	}

	$is_php_compatible = a8csp_cached_404_is_php_version_compatible( $plugin_metadata['RequiresPHP'] );
	$is_wp_compatible  = a8csp_cached_404_is_wp_version_compatible( $plugin_metadata['RequiresWP'] );

	$wp_error = new \WP_Error();
	if ( ! $is_wp_compatible ) {
		$wp_error->add( 'plugin_wp_incompatible', '', array( 'requires_wp' => $plugin_metadata['RequiresWP'] ) );
	}
	if ( ! $is_php_compatible ) {
		$wp_error->add( 'plugin_php_incompatible', '', array( 'requires_php' => $plugin_metadata['RequiresPHP'] ) );
	}

	$result = $wp_error->has_errors() ? $wp_error : true;

	return $result;
}

/**
 * Outputs an error that the system requirements weren't met.
 *
 * The notice hangs on `all_admin_notices`, which fires on site, network, and user admin screens
 * alike — so a network activation that fails the gate is explained on the network admin screen
 * where it happened, not just on per-site dashboards.
 *
 * @since   1.0.0
 * @version 1.0.0
 *
 * @param   \WP_Error $error          The error message to display.
 *
 * @return  void
 */
function a8csp_cached_404_output_requirements_error( $error ) {
	add_action(
		'all_admin_notices',
		static function () use ( $error ) {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return;
			}

			$requirements_error = wp_sprintf(
				/* translators: 1: Plugin name, 2: Plugin version */
				__( '<strong>%1$s (version %2$s)</strong> could not be initialized.', 'a8csp-cached-404-page' ),
				a8csp_cached_404_get_plugin_name(),
				a8csp_cached_404_get_plugin_version()
			);

			if ( $error->has_errors() ) {
				$requirements_error .= ' ' . __( 'Your environment does not meet all the system requirements listed below:', 'a8csp-cached-404-page' );
				$requirements_error .= '<ul class="ul-disc">';

				foreach ( $error->get_error_codes() as $error_code ) {
					$error_data = $error->get_error_data( $error_code );
					if ( ! \is_array( $error_data ) ) {
						$error_data = array();
					}

					switch ( $error_code ) {
						case 'plugin_wp_incompatible':
							$error_message = wp_sprintf(
								/* translators: 1: Current WP version, 2: Minimum WP version */
								__( 'Current <em>WordPress version (%1$s)</em> does not meet minimum required version of %2$s.', 'a8csp-cached-404-page' ),
								get_bloginfo( 'version' ),
								$error_data['requires_wp']
							);
							break;
						case 'plugin_php_incompatible':
							$error_message = wp_sprintf(
								/* translators: 1: Current PHP version, 2: Minimum PHP version */
								__( 'Current <em>PHP version (%1$s)</em> does not meet minimum required version of %2$s.', 'a8csp-cached-404-page' ),
								PHP_VERSION,
								$error_data['requires_php']
							);
							break;
						case 'missing_autoloader':
							$error_message = __( 'The autoloader file is missing. Please run <code>composer install</code> to generate it.', 'a8csp-cached-404-page' );
							break;
						default:
							$error_message = $error->get_error_message( $error_code );
					}

					$requirements_error .= "<li>$error_message</li>";
				}

				$requirements_error .= '</ul>';
			}

			if ( \function_exists( 'wp_admin_notice' ) ) {
				wp_admin_notice( $requirements_error, array( 'type' => 'error' ) );
			} else {
				echo wp_kses_post( '<div class="notice notice-error"><p>' . $requirements_error . '</p></div>' );
			}
		}
	);
}
