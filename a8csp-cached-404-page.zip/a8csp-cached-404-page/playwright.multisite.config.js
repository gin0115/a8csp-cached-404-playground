/**
 * The multisite specs, against the converted network of `.wp-env.multisite.json`, which this
 * config starts when it is not already up.
 */
const config = require( '@a8csp/configs/node/playwright.config.base.js' )( {
	port: require( './.wp-env.multisite.json' ).port,
} );

module.exports = {
	...config,
	testDir: 'tests/EndToEnd/Multisite',
	webServer: {
		...config.webServer,
		command: 'npm run wp-env:multisite:start',
	},
};
