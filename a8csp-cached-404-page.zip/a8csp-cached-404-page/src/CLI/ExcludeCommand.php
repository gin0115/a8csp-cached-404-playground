<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\CLI;

use A8C\SpecialProjects\A8cspCached404Page\Settings\Settings;

\defined( 'ABSPATH' ) || exit;

/**
 * Manages the paths the light 404 never answers.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class ExcludeCommand {
	// region METHODS

	/**
	 * Lists the excluded paths.
	 *
	 * @subcommand list
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function list_(): void {
		foreach ( Settings::load()->excluded() as $path ) {
			\WP_CLI::line( $path );
		}
	}

	/**
	 * Adds excluded paths.
	 *
	 * ## OPTIONS
	 *
	 * <path>...
	 * : Path starts, written without the site folder or a language folder, such as /tag/keep-me/.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   array<int, string> $args Positional arguments.
	 *
	 * @return  void
	 */
	public function add( array $args ): void {
		$settings = Settings::load();
		$added    = Settings::clean_paths( $args );
		if ( \count( $added ) !== \count( $args ) ) {
			\WP_CLI::error( 'Paths may only hold letters, digits, -, _ and /.' );
			return;
		}

		Command::store( $settings->with_excluded( \array_merge( $settings->excluded(), $added ) ) );
		\WP_CLI::success( 'Excluded: ' . \implode( ', ', $added ) . '.' );
	}

	/**
	 * Removes excluded paths.
	 *
	 * ## OPTIONS
	 *
	 * <path>...
	 * : Paths as `wp cached-404 exclude list` prints them.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   array<int, string> $args Positional arguments.
	 *
	 * @return  void
	 */
	public function remove( array $args ): void {
		$settings = Settings::load();
		$removed  = Settings::clean_paths( $args );

		Command::store( $settings->with_excluded( \array_values( \array_diff( $settings->excluded(), $removed ) ) ) );
		\WP_CLI::success( 'No longer excluded: ' . \implode( ', ', $removed ) . '.' );
	}

	// endregion
}
