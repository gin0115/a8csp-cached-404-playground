<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\CLI;

use A8C\SpecialProjects\A8cspCached404Page\Detection\Detector;
use A8C\SpecialProjects\A8cspCached404Page\Settings\Settings;

\defined( 'ABSPATH' ) || exit;

/**
 * Lists and turns on or off the URL types the light 404 answers.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class ShortcutCommand {
	// region METHODS

	/**
	 * Lists the detected URL types.
	 *
	 * ## OPTIONS
	 *
	 * [--format=<format>]
	 * : Render output in a particular format.
	 * ---
	 * default: table
	 * options:
	 *   - table
	 *   - json
	 *   - csv
	 *   - yaml
	 * ---
	 *
	 * @subcommand list
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   array<int, string>    $args       Positional arguments (unused).
	 * @param   array<string, string> $assoc_args Associative arguments.
	 *
	 * @return  void
	 */
	public function list_( array $args, array $assoc_args ): void {
		$items = array();
		foreach ( Settings::load()->shortcuts() as $key => $shortcut ) {
			$items[] = array(
				'key'     => $key,
				'label'   => $shortcut['label'],
				'base'    => '/' . $shortcut['base'] . '/',
				'enabled' => $shortcut['enabled'] ? 'yes' : 'no',
			);
		}

		\WP_CLI\Utils\format_items( $assoc_args['format'] ?? 'table', $items, array( 'key', 'label', 'base', 'enabled' ) );
	}

	/**
	 * Turns URL types on.
	 *
	 * ## OPTIONS
	 *
	 * <key>...
	 * : One or more keys from `wp cached-404 shortcut list`.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   array<int, string> $args Positional arguments.
	 *
	 * @return  void
	 */
	public function enable( array $args ): void {
		$this->set( $args, true );
	}

	/**
	 * Turns URL types off.
	 *
	 * ## OPTIONS
	 *
	 * <key>...
	 * : One or more keys from `wp cached-404 shortcut list`.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   array<int, string> $args Positional arguments.
	 *
	 * @return  void
	 */
	public function disable( array $args ): void {
		$this->set( $args, false );
	}

	// endregion

	// region HELPERS

	/**
	 * Turns the named URL types on or off, running detection first when it has never run.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   array<int, string> $keys    The shortcut keys.
	 * @param   bool               $enabled The new value.
	 *
	 * @return  void
	 */
	private function set( array $keys, bool $enabled ): void {
		$settings = Settings::load();
		if ( 0 === $settings->detected()['at'] ) {
			$settings = ( new Detector() )->detect( $settings );
		}

		$unknown = \array_diff( $keys, \array_keys( $settings->shortcuts() ) );
		if ( array() !== $unknown ) {
			\WP_CLI::error( 'Unknown URL type: ' . \implode( ', ', $unknown ) . '. See `wp cached-404 shortcut list`.' );
			return;
		}

		foreach ( $keys as $key ) {
			$settings = $settings->with_shortcut_enabled( $key, $enabled );
		}

		Command::store( $settings );
		\WP_CLI::success( \sprintf( '%s: %s.', $enabled ? 'On' : 'Off', \implode( ', ', $keys ) ) );
	}

	// endregion
}
