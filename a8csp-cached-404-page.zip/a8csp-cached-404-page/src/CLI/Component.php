<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\CLI;

use A8C\SpecialProjects\A8cspCached404Page\AbstractComponent;

\defined( 'ABSPATH' ) || exit;

/**
 * Registers the `wp cached-404` commands. Loads only under WP-CLI.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class Component extends AbstractComponent {
	// region METHODS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public static function should_load(): bool {
		return \defined( 'WP_CLI' ) && true === \constant( 'WP_CLI' );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function register_hooks(): void {
		// WP-CLI fires `cli_init` on `init`, after the plugin has booted.
		add_action( 'cli_init', array( $this, 'add_commands' ) );
	}

	// endregion

	// region HOOKS

	/**
	 * Adds the commands.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function add_commands(): void {
		\WP_CLI::add_command( 'cached-404', Command::class );
		\WP_CLI::add_command( 'cached-404 shortcut', ShortcutCommand::class );
		\WP_CLI::add_command( 'cached-404 page', PageCommand::class );
		\WP_CLI::add_command( 'cached-404 prefix', PrefixCommand::class );
		\WP_CLI::add_command( 'cached-404 exclude', ExcludeCommand::class );
	}

	// endregion
}
