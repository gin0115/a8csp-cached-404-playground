<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\CLI;

use A8C\SpecialProjects\A8cspCached404Page\Page\PageStore;
use A8C\SpecialProjects\A8cspCached404Page\Settings\Settings;

\defined( 'ABSPATH' ) || exit;

/**
 * Manages the stored 404 page.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class PageCommand {
	// region METHODS

	/**
	 * Rebuilds the stored page from the chosen source, or the filter's file. The captured 404 is
	 * rebuilt with the ticked stylesheets and scripts.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function build(): void {
		$settings = Command::store( Settings::load() );
		if ( '' === $settings->page_file() ) {
			if ( 'captured' === $settings->page_source() && null === PageStore::filtered_file() ) {
				\WP_CLI::error( 'Could not write the page into uploads.' );
				return;
			}

			\WP_CLI::warning( 'No page file is in use, so the plain "Not Found" page is sent.' );
			return;
		}

		\WP_CLI::success( 'Page in use: ' . $settings->page_file() . '.' );
	}

	/**
	 * Chooses which page is sent for missing items. A path from the `a8csp_cached_404_page_file`
	 * filter overrules it.
	 *
	 * ## OPTIONS
	 *
	 * <source>
	 * : captured (the site's own 404, captured in Settings → Cached 404), file (uploads/cached-404.html) or plain.
	 * ---
	 * options:
	 *   - captured
	 *   - file
	 *   - plain
	 * ---
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   array<int, string> $args Positional arguments.
	 *
	 * @return  void
	 */
	public function source( array $args ): void {
		$settings = Command::store( Settings::load()->with_page_source( $args[0] ?? 'captured' ) );
		if ( null !== PageStore::filtered_file() ) {
			\WP_CLI::warning( 'The ' . PageStore::FILTER . ' filter overrules this.' );
		}

		\WP_CLI::success( 'Page source: ' . $settings->page_source() . '.' );
	}

	// endregion
}
