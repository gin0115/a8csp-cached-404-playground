<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\CLI;

use A8C\SpecialProjects\A8cspCached404Page\Detection\Detector;
use A8C\SpecialProjects\A8cspCached404Page\Page\PageStore;
use A8C\SpecialProjects\A8cspCached404Page\Request\Responder;
use A8C\SpecialProjects\A8cspCached404Page\Settings\Settings;

\defined( 'ABSPATH' ) || exit;

/**
 * Controls the light 404 for missing items.
 *
 * ## EXAMPLES
 *
 *     wp cached-404 status
 *     wp cached-404 enable
 *     wp cached-404 shortcut enable taxonomy:post_tag
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class Command {
	// region METHODS

	/**
	 * Shows the current state.
	 *
	 * ## OPTIONS
	 *
	 * [--format=<format>]
	 * : Render output in a particular format.
	 * ---
	 * default: table
	 * options:
	 *   - table
	 *   - json
	 *   - yaml
	 * ---
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   array<int, string>    $args       Positional arguments (unused).
	 * @param   array<string, string> $assoc_args Associative arguments.
	 *
	 * @return  void
	 */
	public function status( array $args, array $assoc_args ): void {
		$settings = Settings::load();
		$enabled  = \array_filter( $settings->shortcuts(), static fn ( array $shortcut ): bool => $shortcut['enabled'] );
		$prefixes = \array_filter( $settings->prefixes(), static fn ( array $prefix ): bool => $prefix['enabled'] );
		$at       = $settings->detected()['at'];

		$rows = array(
			'enabled'         => $settings->is_enabled() ? 'yes' : 'no',
			'cache_misses'    => $settings->cache_misses() ? 'yes' : 'no',
			'extra_segments'  => $settings->extra_segments() ? 'yes' : 'no',
			'loose'           => $settings->loose() ? 'yes' : 'no',
			'shortcuts_on'    => \implode( ',', \array_keys( $enabled ) ),
			'site_path'       => '' !== $settings->site_path() ? '/' . $settings->site_path() . '/' : '',
			'prefixes_on'     => \implode( ',', \array_keys( $prefixes ) ),
			'excluded'        => \implode( ',', $settings->excluded() ),
			'page_source'     => $settings->page_source(),
			'page_filter'     => PageStore::filtered_file() ?? '',
			'page_file'       => $settings->page_file(),
			'page_built'      => '' !== $settings->page_file() && \is_readable( $settings->page_file() ) ? 'yes' : 'no',
			'last_detection'  => $at > 0 ? \gmdate( 'Y-m-d H:i:s', $at ) . ' UTC' : 'never',
			'detection_stale' => ( new Detector() )->is_stale( $settings ) ? 'yes' : 'no',
			'response_header' => Responder::HEADER,
		);

		$items = array();
		foreach ( $rows as $setting => $value ) {
			$items[] = array(
				'setting' => $setting,
				'value'   => $value,
			);
		}

		\WP_CLI\Utils\format_items( $assoc_args['format'] ?? 'table', $items, array( 'setting', 'value' ) );
	}

	/**
	 * Turns the light 404 on. Runs detection first when it has never run.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function enable(): void {
		$settings = Settings::load();
		if ( 0 === $settings->detected()['at'] ) {
			$settings = ( new Detector() )->detect( $settings );
		}

		self::store( $settings->with_enabled( true ) );
		\WP_CLI::success( 'Cached 404 is on.' );
	}

	/**
	 * Turns the light 404 off. WordPress then handles every request as normal.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function disable(): void {
		self::store( Settings::load()->with_enabled( false ) );
		\WP_CLI::success( 'Cached 404 is off.' );
	}

	/**
	 * Re-reads the URL types the site has registered. On/off choices are kept.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function detect(): void {
		$settings = self::store( ( new Detector() )->detect( Settings::load() ) );
		\WP_CLI::success( \sprintf( 'Detected %d URL types.', \count( $settings->shortcuts() ) ) );
	}

	/**
	 * Turns caching of lookups that find nothing on or off.
	 *
	 * ## OPTIONS
	 *
	 * <state>
	 * : on or off.
	 * ---
	 * options:
	 *   - on
	 *   - off
	 * ---
	 *
	 * @subcommand cache-misses
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   array<int, string> $args Positional arguments.
	 *
	 * @return  void
	 */
	public function cache_misses( array $args ): void {
		$on = 'on' === ( $args[0] ?? '' );

		self::store( Settings::load()->with_cache_misses( $on ) );
		\WP_CLI::success( $on ? 'Missing slugs are cached.' : 'Missing slugs are not cached.' );
	}

	/**
	 * Turns answering made-up paths after a single item, such as `/product/<slug>/<anything>/`, on
	 * or off.
	 *
	 * ## OPTIONS
	 *
	 * <state>
	 * : on or off.
	 * ---
	 * options:
	 *   - on
	 *   - off
	 * ---
	 *
	 * @subcommand extra-segments
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   array<int, string> $args Positional arguments.
	 *
	 * @return  void
	 */
	public function extra_segments( array $args ): void {
		$on = 'on' === ( $args[0] ?? '' );

		self::store( Settings::load()->with_extra_segments( $on ) );
		\WP_CLI::success( $on ? 'Made-up paths after single items are answered.' : 'Made-up paths after single items are left to WordPress.' );
	}

	/**
	 * Turns loose mode on or off: any other missing address, checked against the saved rewrite
	 * rules. Plugins that route addresses in their own code are not seen this early.
	 *
	 * ## OPTIONS
	 *
	 * <state>
	 * : on or off.
	 * ---
	 * options:
	 *   - on
	 *   - off
	 * ---
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   array<int, string> $args Positional arguments.
	 *
	 * @return  void
	 */
	public function loose( array $args ): void {
		$on = 'on' === ( $args[0] ?? '' );

		self::store( ( new Detector() )->detect( Settings::load() )->with_loose( $on ) );
		\WP_CLI::success( $on ? 'Loose mode is on.' : 'Loose mode is off.' );
	}

	/**
	 * Prints this site's choices as JSON, for `import` on another site.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function export(): void {
		\WP_CLI::line( (string) wp_json_encode( Settings::load()->choices(), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) );
	}

	/**
	 * Applies choices exported from another site. Runs detection first, so this site's own URL bases
	 * are used, and ignores URL types this site does not have.
	 *
	 * ## OPTIONS
	 *
	 * <file>
	 * : The JSON file `export` printed. Use `-` to read from standard input.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   array<int, string> $args Positional arguments.
	 *
	 * @return  void
	 */
	public function import( array $args ): void {
		$file    = $args[0] ?? '';
		$json    = '-' === $file ? \stream_get_contents( STDIN ) : ( \is_readable( $file ) ? \file_get_contents( $file ) : false ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file named on the command line.
		$choices = \is_string( $json ) ? \json_decode( $json, true ) : null;
		if ( ! \is_array( $choices ) ) {
			\WP_CLI::error( 'Could not read JSON choices from ' . $file . '.' );
			return;
		}

		$settings = ( new Detector() )->detect( Settings::load() );
		$unknown  = \array_diff( \is_array( $choices['shortcuts'] ?? null ) ? $choices['shortcuts'] : array(), \array_keys( $settings->shortcuts() ) );
		foreach ( $unknown as $key ) {
			\WP_CLI::warning( \sprintf( 'This site has no URL type %s; skipped.', \is_scalar( $key ) ? (string) $key : '?' ) );
		}

		self::store( $settings->with_choices( $choices ) );
		\WP_CLI::success( 'Choices imported.' );
	}

	/**
	 * Rebuilds the stored page and saves the settings, as the admin page's Save does.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The settings to store.
	 *
	 * @return  Settings
	 */
	public static function store( Settings $settings ): Settings {
		$settings = ( new PageStore() )->build( $settings );
		$settings->save();

		return $settings;
	}

	// endregion
}
