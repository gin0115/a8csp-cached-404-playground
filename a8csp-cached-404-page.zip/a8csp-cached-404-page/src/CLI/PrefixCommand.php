<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\CLI;

use A8C\SpecialProjects\A8cspCached404Page\Detection\Detector;
use A8C\SpecialProjects\A8cspCached404Page\Settings\Settings;

\defined( 'ABSPATH' ) || exit;

/**
 * Lists and turns on or off the language folders removed before the URL types are checked.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class PrefixCommand {
	// region METHODS

	/**
	 * Lists the detected language folders.
	 *
	 * ## OPTIONS
	 *
	 * [--format=<format>]
	 * : Render output in a particular format.
	 * ---
	 * default: table
	 * options:
	 *   - table
	 *   - json
	 *   - csv
	 *   - yaml
	 * ---
	 *
	 * @subcommand list
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   array<int, string>    $args       Positional arguments (unused).
	 * @param   array<string, string> $assoc_args Associative arguments.
	 *
	 * @return  void
	 */
	public function list_( array $args, array $assoc_args ): void {
		$items = array();
		foreach ( Settings::load()->prefixes() as $key => $prefix ) {
			$items[] = array(
				'key'     => $key,
				'label'   => $prefix['label'],
				'folders' => \implode( ',', $prefix['values'] ),
				'enabled' => $prefix['enabled'] ? 'yes' : 'no',
			);
		}

		\WP_CLI\Utils\format_items( $assoc_args['format'] ?? 'table', $items, array( 'key', 'label', 'folders', 'enabled' ) );
	}

	/**
	 * Turns language folders on.
	 *
	 * ## OPTIONS
	 *
	 * <key>...
	 * : One or more keys from `wp cached-404 prefix list`.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   array<int, string> $args Positional arguments.
	 *
	 * @return  void
	 */
	public function enable( array $args ): void {
		$this->set( $args, true );
	}

	/**
	 * Turns language folders off.
	 *
	 * ## OPTIONS
	 *
	 * <key>...
	 * : One or more keys from `wp cached-404 prefix list`.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   array<int, string> $args Positional arguments.
	 *
	 * @return  void
	 */
	public function disable( array $args ): void {
		$this->set( $args, false );
	}

	// endregion

	// region HELPERS

	/**
	 * Turns the named prefixes on or off, running detection first when it has never run.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   array<int, string> $keys    The prefix keys.
	 * @param   bool               $enabled The new value.
	 *
	 * @return  void
	 */
	private function set( array $keys, bool $enabled ): void {
		$settings = Settings::load();
		if ( 0 === $settings->detected()['at'] ) {
			$settings = ( new Detector() )->detect( $settings );
		}

		$unknown = \array_diff( $keys, \array_keys( $settings->prefixes() ) );
		if ( array() !== $unknown ) {
			\WP_CLI::error( 'Unknown language folder: ' . \implode( ', ', $unknown ) . '. See `wp cached-404 prefix list`.' );
			return;
		}

		foreach ( $keys as $key ) {
			$settings = $settings->with_prefix_enabled( $key, $enabled );
		}

		Command::store( $settings );
		\WP_CLI::success( \sprintf( '%s: %s.', $enabled ? 'On' : 'Off', \implode( ', ', $keys ) ) );
	}

	// endregion
}
