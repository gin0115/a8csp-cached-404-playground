<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Dashboard;

use A8C\SpecialProjects\A8cspCached404Page\AbstractComponent;
use A8C\SpecialProjects\A8cspCached404Page\Detection\Detector;
use A8C\SpecialProjects\A8cspCached404Page\Settings\Component as SettingsComponent;
use A8C\SpecialProjects\A8cspCached404Page\Settings\Settings;

\defined( 'ABSPATH' ) || exit;

/**
 * The Cached 404 dashboard widget.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class Component extends AbstractComponent {
	// region METHODS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function register_hooks(): void {
		add_action( 'wp_dashboard_setup', array( $this, 'add_widget' ) );
	}

	// endregion

	// region HOOKS

	/**
	 * Adds the widget for users who can change the settings.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function add_widget(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		wp_add_dashboard_widget( 'a8csp_cached_404', __( 'Cached 404', 'a8csp-cached-404-page' ), array( $this, 'render' ) );
	}

	/**
	 * Prints the widget.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function render(): void {
		$settings = Settings::load();
		$on       = \count( \array_filter( $settings->shortcuts(), static fn ( array $shortcut ): bool => $shortcut['enabled'] ) );
		$built    = '' !== $settings->page_file() && \is_readable( $settings->page_file() );

		$rows = array(
			array( __( 'State', 'a8csp-cached-404-page' ), $settings->is_enabled() ? __( 'On', 'a8csp-cached-404-page' ) : __( 'Off', 'a8csp-cached-404-page' ) ),
			array( __( 'URL types on', 'a8csp-cached-404-page' ), (string) $on ),
			array( __( 'Stored page', 'a8csp-cached-404-page' ), $built ? __( 'Built', 'a8csp-cached-404-page' ) : __( 'Not built', 'a8csp-cached-404-page' ) ),
			array( __( 'Detection', 'a8csp-cached-404-page' ), ( new Detector() )->is_stale( $settings ) ? __( 'Out of date', 'a8csp-cached-404-page' ) : __( 'Up to date', 'a8csp-cached-404-page' ) ),
		);

		echo '<ul>';
		foreach ( $rows as list( $label, $value ) ) {
			echo '<li><strong>' . esc_html( $label ) . ':</strong> ' . esc_html( $value ) . '</li>';
		}
		echo '</ul>';

		echo '<p><a href="' . esc_url( admin_url( 'options-general.php?page=' . SettingsComponent::PAGE ) ) . '">' . esc_html__( 'Cached 404 settings', 'a8csp-cached-404-page' ) . '</a></p>';
	}

	// endregion
}
