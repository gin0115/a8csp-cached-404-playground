<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Page;

\defined( 'ABSPATH' ) || exit;

/**
 * The stylesheets and inline CSS WordPress printed on the last 404 recorded.
 *
 * @since   1.0.0
 * @version 1.0.0
 *
 * @phpstan-type StyleData array{url: string, media: string, inline: string}
 */
final class StyleList {
	// region FIELDS AND CONSTANTS

	/**
	 * The option holding the list, keyed by style handle. Not autoloaded.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string OPTION = 'a8csp_cached_404_styles';

	/**
	 * The start of the missing page's path that `check_url()` links to.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string CHECK_PATH = 'a8csp-cached-404-check-';

	// endregion

	// region METHODS

	/**
	 * The recorded styles, in the order WordPress printed them.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  array<string, StyleData>
	 */
	public static function load(): array {
		$list = get_option( self::OPTION, array() );
		if ( ! \is_array( $list ) ) {
			return array();
		}

		$clean = array();
		foreach ( $list as $handle => $style ) {
			if ( ! \is_array( $style ) ) {
				continue;
			}

			$url    = $style['url'] ?? '';
			$media  = $style['media'] ?? 'all';
			$inline = $style['inline'] ?? '';
			if ( \is_string( $url ) && \is_string( $media ) && \is_string( $inline ) ) {
				$clean[ (string) $handle ] = array(
					'url'    => $url,
					'media'  => $media,
					'inline' => $inline,
				);
			}
		}

		return $clean;
	}

	/**
	 * Stores the styles printed so far, when they differ from the stored list. Each keeps its file
	 * URL and its inline CSS; handles with neither are left out.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   \WP_Styles $styles The styles registry.
	 *
	 * @return  void
	 */
	public static function record( \WP_Styles $styles ): void {
		$list = array();
		foreach ( $styles->done as $handle ) {
			$style = $styles->registered[ $handle ] ?? null;
			if ( null === $style ) {
				continue;
			}

			$after  = $styles->get_data( $handle, 'after' );
			$inline = \is_array( $after ) ? \trim( \implode( "\n", \array_filter( $after, 'is_string' ) ) ) : '';
			$url    = \is_string( $style->src ) && '' !== $style->src ? self::url( $styles, $style ) : '';
			if ( '' === $url && '' === $inline ) {
				continue;
			}

			$list[ $handle ] = array(
				'url'    => $url,
				'media'  => \is_string( $style->args ) && '' !== $style->args ? $style->args : 'all',
				'inline' => $inline,
			);
		}

		if ( self::load() !== $list ) {
			update_option( self::OPTION, $list, false );
		}
	}

	/**
	 * A URL WordPress answers with its own 404. The path is new each time, so a page cache cannot
	 * serve a stored copy.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  string
	 */
	public static function check_url(): string {
		return home_url( '/' . self::CHECK_PATH . \time() . '/' );
	}

	// endregion

	// region HELPERS

	/**
	 * The stylesheet's full URL, with its version.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   \WP_Styles      $styles The styles registry.
	 * @param   \_WP_Dependency $style  The style.
	 *
	 * @return  string
	 */
	private static function url( \WP_Styles $styles, \_WP_Dependency $style ): string {
		$url = (string) $style->src;
		if ( 1 !== \preg_match( '#^(https?:)?//#', $url ) ) {
			$url = (string) $styles->base_url . $url;
		}

		$version = false === $style->ver ? $styles->default_version : $style->ver;

		return \is_string( $version ) && '' !== $version ? add_query_arg( 'ver', $version, $url ) : $url;
	}

	// endregion
}
