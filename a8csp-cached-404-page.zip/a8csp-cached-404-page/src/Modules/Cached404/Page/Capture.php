<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Page;

\defined( 'ABSPATH' ) || exit;

/**
 * Captures the site's own 404 once. A one-time key in the address marks the request: it is left to
 * WordPress, shown logged out, and stored with the stylesheets and scripts it loaded.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class Capture {
	// region FIELDS AND CONSTANTS

	/**
	 * The query argument that carries the key.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string ARG = 'a8csp-cached-404-capture';

	/**
	 * The option holding the captured page's HTML.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string HTML_OPTION = 'a8csp_cached_404_html';

	/**
	 * The option holding when the page was last captured.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string RECORDED_AT_OPTION = 'a8csp_cached_404_recorded_at';

	/**
	 * The transient holding the current key.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string TRANSIENT = 'a8csp_cached_404_capture';

	// endregion

	// region METHODS

	/**
	 * Starts a capture: makes a new key, clears the last capture and returns the address to open.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  string
	 */
	public static function start(): string {
		$key = wp_generate_password( 32, false );
		set_transient( self::TRANSIENT, $key, 10 * MINUTE_IN_SECONDS );

		delete_option( self::HTML_OPTION );
		delete_option( StyleList::OPTION );
		delete_option( ScriptList::OPTION );

		return add_query_arg( self::ARG, $key, StyleList::check_url() );
	}

	/**
	 * Whether the request has the key argument at all. Read before plugins load, so nothing is checked.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  bool
	 */
	public static function is_marked(): bool {
		return isset( $_GET[ self::ARG ] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only its presence is read.
	}

	/**
	 * Whether the request carries the current key.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  bool
	 */
	public static function is_capture(): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- The key is the check.
		$key = isset( $_GET[ self::ARG ] ) && \is_string( $_GET[ self::ARG ] ) ? sanitize_text_field( wp_unslash( $_GET[ self::ARG ] ) ) : '';
		if ( '' === $key ) {
			return false;
		}

		$expected = get_transient( self::TRANSIENT );

		return \is_string( $expected ) && \hash_equals( $expected, $key );
	}

	/**
	 * Whether a capture is started and its page not yet stored.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  bool
	 */
	public static function is_pending(): bool {
		return false !== get_transient( self::TRANSIENT );
	}

	/**
	 * Stores the captured page with the stylesheets and scripts WordPress printed, and ends the key.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $html The page as sent.
	 *
	 * @return  void
	 */
	public static function store( string $html ): void {
		StyleList::record( wp_styles() );
		ScriptList::record( wp_scripts(), wp_script_modules() );

		update_option( self::HTML_OPTION, $html, false );
		update_option( self::RECORDED_AT_OPTION, \time(), false );
		delete_transient( self::TRANSIENT );
	}

	/**
	 * The captured page's HTML, or '' when none is captured.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  string
	 */
	public static function html(): string {
		$html = get_option( self::HTML_OPTION, '' );

		return \is_string( $html ) ? $html : '';
	}

	// endregion
}
