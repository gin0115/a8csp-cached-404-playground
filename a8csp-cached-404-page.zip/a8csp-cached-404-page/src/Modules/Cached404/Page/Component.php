<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Page;

use A8C\SpecialProjects\A8cspCached404Page\AbstractComponent;
use A8C\SpecialProjects\A8cspCached404Page\Request\Responder;
use A8C\SpecialProjects\A8cspCached404Page\Settings\Page as SettingsPage;
use A8C\SpecialProjects\A8cspCached404Page\Settings\Settings;

\defined( 'ABSPATH' ) || exit;

/**
 * The stored page: capturing the site's own 404, building the page from it, and the preview.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class Component extends AbstractComponent {
	// region FIELDS AND CONSTANTS

	/**
	 * The query argument that previews the stored page; its value is a nonce.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string PREVIEW_ARG = '404-test';

	/**
	 * The preview nonce action.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string PREVIEW_ACTION = 'a8csp_cached_404_preview';

	/**
	 * The AJAX action that starts a capture.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string START_ACTION = 'a8csp_cached_404_capture_start';

	/**
	 * The AJAX action that returns the captured stylesheets and scripts as a checklist.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string LISTS_ACTION = 'a8csp_cached_404_capture_lists';

	/**
	 * The AJAX action that saves the ticked items and builds the page.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string BUILD_ACTION = 'a8csp_cached_404_capture_build';

	/**
	 * The nonce action for the three AJAX actions.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string AJAX_NONCE = 'a8csp_cached_404_capture';

	/**
	 * Whether this request's 404 is being buffered for the capture.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @var     bool
	 */
	private bool $buffering = false;

	// endregion

	// region METHODS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function register_hooks(): void {
		add_action( 'init', array( $this, 'preview' ) );
		add_action( 'init', array( $this, 'log_out_capture' ), PHP_INT_MIN );
		add_action( 'template_redirect', array( $this, 'start_capture' ), PHP_INT_MAX );
		add_action( 'shutdown', array( $this, 'finish_capture' ), 0 );
		add_action( 'wp_ajax_' . self::START_ACTION, array( $this, 'ajax_start' ) );
		add_action( 'wp_ajax_' . self::LISTS_ACTION, array( $this, 'ajax_lists' ) );
		add_action( 'wp_ajax_' . self::BUILD_ACTION, array( $this, 'ajax_build' ) );
	}

	/**
	 * The preview link for the current user.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  string
	 */
	public static function preview_url(): string {
		return add_query_arg( self::PREVIEW_ARG, wp_create_nonce( self::PREVIEW_ACTION ), home_url( '/' ) );
	}

	// endregion

	// region HOOKS

	/**
	 * Sends the stored page for `?404-test=<nonce>`, as visitors get it. Runs on `init`, where nonces
	 * and the current user are available; the request check runs before both.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function preview(): void {
		if ( is_admin() || ! isset( $_GET[ self::PREVIEW_ARG ] ) || ! \is_string( $_GET[ self::PREVIEW_ARG ] ) ) {
			return;
		}

		if ( false === wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET[ self::PREVIEW_ARG ] ) ), self::PREVIEW_ACTION ) ) {
			return;
		}

		Responder::send( 'preview', Settings::load()->page_file() );
	}

	/**
	 * Shows the capture request logged out, so the stored page has no toolbar or user details.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function log_out_capture(): void {
		if ( ! is_admin() && Capture::is_capture() ) {
			wp_set_current_user( 0 );
		}
	}

	/**
	 * Starts buffering the capture request's 404.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function start_capture(): void {
		if ( ! is_404() || ! Capture::is_capture() ) {
			return;
		}

		if ( ! \headers_sent() ) {
			nocache_headers();
		}

		$this->buffering = \ob_start();
	}

	/**
	 * Stores the buffered 404 with what it loaded, before WordPress flushes the buffers.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function finish_capture(): void {
		if ( ! $this->buffering ) {
			return;
		}

		$this->buffering = false;
		Capture::store( (string) \ob_get_contents() );
	}

	/**
	 * Starts a capture and returns the address to open.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function ajax_start(): void {
		self::check_ajax();

		wp_send_json_success( array( 'url' => Capture::start() ) );
	}

	/**
	 * Returns the captured stylesheets and scripts as a checklist, with the defaults ticked.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function ajax_lists(): void {
		self::check_ajax();

		if ( Capture::is_pending() ) {
			wp_send_json_error( array( 'code' => 'pending' ), 409 );
		}

		if ( '' === Capture::html() ) {
			wp_send_json_error( array( 'message' => __( 'Nothing was captured. Try again.', 'a8csp-cached-404-page' ) ), 404 );
		}

		$a8csp_cached_404_lists = self::lists( AssetList::defaults() );

		\ob_start();
		include \constant( 'A8CSP_CACHED_404_DIR_PATH' ) . 'templates/admin/cached-404-assets.php';

		wp_send_json_success(
			array(
				'html'    => (string) \ob_get_clean(),
				'summary' => SettingsPage::recorded(),
			)
		);
	}

	/**
	 * Saves the ticked items, builds the page from the capture and makes it the page in use.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function ajax_build(): void {
		self::check_ajax();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- check_ajax() checks the nonce; only strings in the captured lists are saved.
		$posted = isset( $_POST['ticked'] ) && \is_array( $_POST['ticked'] ) ? wp_unslash( $_POST['ticked'] ) : array();
		$styles = \is_array( $posted['styles'] ?? null ) ? \array_values( \array_filter( $posted['styles'], 'is_string' ) ) : array();
		$script = \is_array( $posted['scripts'] ?? null ) ? \array_values( \array_filter( $posted['scripts'], 'is_string' ) ) : array();
		AssetList::save_ticked( $styles, $script );

		$settings = ( new PageStore() )->build( Settings::load()->with_page_source( 'captured' ) );
		$settings->save();

		if ( '' === $settings->page_file() ) {
			wp_send_json_error( array( 'message' => __( 'The page could not be written into uploads.', 'a8csp-cached-404-page' ) ), 500 );
		}

		wp_send_json_success( array( 'url' => self::preview_url() ) );
	}

	// endregion

	// region HELPERS

	/**
	 * Stops an AJAX request without a valid nonce or the right to manage options.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	private static function check_ajax(): void {
		check_ajax_referer( self::AJAX_NONCE );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'You are not allowed to do this.', 'a8csp-cached-404-page' ) ), 403 );
		}
	}

	/**
	 * The two checklists, stylesheets and scripts, with what is ticked.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   array{styles: list<string>, scripts: list<string>} $ticked The ticked items.
	 *
	 * @return  array<string, array{label: string, items: array<string, array{label: string, url: string, notes: list<string>, group: string, default: bool}>, ticked: list<string>, note: string}>
	 */
	private static function lists( array $ticked ): array {
		return array(
			'styles'  => array(
				'label'  => __( 'Stylesheets', 'a8csp-cached-404-page' ),
				'items'  => AssetList::styles(),
				'ticked' => $ticked['styles'],
				'note'   => __( 'Unticked stylesheets, with their inline CSS, are taken out of the page.', 'a8csp-cached-404-page' ),
			),
			'scripts' => array(
				'label'  => __( 'Scripts', 'a8csp-cached-404-page' ),
				'items'  => AssetList::scripts(),
				'ticked' => $ticked['scripts'],
				'note'   => __( 'Unticked scripts, with their inline code, are taken out of the page.', 'a8csp-cached-404-page' ),
			),
		);
	}

	// endregion
}
