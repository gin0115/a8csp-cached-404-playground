<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Page;

\defined( 'ABSPATH' ) || exit;

/**
 * Builds the stored page from the captured 404: the same HTML, without the stylesheets and scripts
 * that are not ticked. Tags are found by the IDs WordPress prints on them.
 *
 * @since   1.0.0
 * @version 1.0.0
 *
 * @phpstan-import-type TickedData from AssetList
 */
final class PageBuilder {
	// region METHODS

	/**
	 * The captured page without the unticked stylesheets and scripts.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string     $html   The captured page.
	 * @param   TickedData $ticked The ticked items.
	 *
	 * @return  string
	 */
	public static function build( string $html, array $ticked ): string {
		$document = \Dom\HTMLDocument::createFromString( $html, LIBXML_NOERROR );

		foreach ( self::unticked_ids( $ticked ) as $id ) {
			$document->getElementById( $id )?->remove();
		}

		return $document->saveHtml();
	}

	// endregion

	// region HELPERS

	/**
	 * The tag IDs of every captured item that is not ticked.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   TickedData $ticked The ticked items.
	 *
	 * @return  list<string>
	 */
	private static function unticked_ids( array $ticked ): array {
		$ids = array();

		foreach ( \array_diff( \array_map( 'strval', \array_keys( AssetList::styles() ) ), $ticked['styles'] ) as $handle ) {
			\array_push( $ids, "$handle-css", "$handle-rtl-css", "$handle-inline-css" );
		}

		foreach ( \array_diff( \array_map( 'strval', \array_keys( AssetList::scripts() ) ), $ticked['scripts'] ) as $key ) {
			list( $type, $name ) = \explode( ':', $key, 2 );
			if ( 'module' === $type ) {
				\array_push( $ids, "$name-js-module", "$name-js-modulepreload", "wp-script-module-data-$name" );
			} else {
				\array_push( $ids, "$name-js", "$name-js-extra", "$name-js-before", "$name-js-after", "$name-js-translations" );
			}
		}

		return $ids;
	}

	// endregion
}
