<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Page;

\defined( 'ABSPATH' ) || exit;

/**
 * The scripts and script modules WordPress printed on the last 404 recorded.
 *
 * @since   1.0.0
 * @version 1.0.0
 *
 * @phpstan-type ScriptData array{url: string, footer: bool, before: string, after: string, data: string}
 * @phpstan-type ModuleData array{url: string, footer: bool, deps: list<string>, enqueued: bool, data: string}
 * @phpstan-type ScriptsData array{scripts: array<string, ScriptData>, modules: array<string, ModuleData>}
 */
final class ScriptList {
	// region FIELDS AND CONSTANTS

	/**
	 * The option holding the list. Not autoloaded.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string OPTION = 'a8csp_cached_404_scripts';

	// endregion

	// region METHODS

	/**
	 * The recorded scripts in the order WordPress printed them, and every recorded module: the
	 * enqueued ones and the ones they import.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  ScriptsData
	 */
	public static function load(): array {
		$list = get_option( self::OPTION, array() );
		$list = \is_array( $list ) ? $list : array();

		$scripts = array();
		foreach ( \is_array( $list['scripts'] ?? null ) ? $list['scripts'] : array() as $handle => $script ) {
			if ( \is_array( $script ) ) {
				$scripts[ (string) $handle ] = array(
					'url'    => \is_string( $script['url'] ?? null ) ? $script['url'] : '',
					'footer' => true === ( $script['footer'] ?? false ),
					'before' => \is_string( $script['before'] ?? null ) ? $script['before'] : '',
					'after'  => \is_string( $script['after'] ?? null ) ? $script['after'] : '',
					'data'   => \is_string( $script['data'] ?? null ) ? $script['data'] : '',
				);
			}
		}

		$modules = array();
		foreach ( \is_array( $list['modules'] ?? null ) ? $list['modules'] : array() as $id => $module ) {
			if ( \is_array( $module ) && \is_string( $module['url'] ?? null ) ) {
				$modules[ (string) $id ] = array(
					'url'      => $module['url'],
					'footer'   => true === ( $module['footer'] ?? false ),
					'deps'     => \is_array( $module['deps'] ?? null ) ? \array_values( \array_filter( $module['deps'], 'is_string' ) ) : array(),
					'enqueued' => true === ( $module['enqueued'] ?? false ),
					'data'     => \is_string( $module['data'] ?? null ) ? $module['data'] : '',
				);
			}
		}

		return array(
			'scripts' => $scripts,
			'modules' => $modules,
		);
	}

	/**
	 * Stores the scripts printed so far and the enqueued modules with everything they import, when
	 * they differ from the stored list.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   \WP_Scripts        $scripts The scripts registry.
	 * @param   \WP_Script_Modules $modules The script modules registry.
	 *
	 * @return  void
	 */
	public static function record( \WP_Scripts $scripts, \WP_Script_Modules $modules ): void {
		$list = array(
			'scripts' => array(),
			'modules' => array(),
		);

		foreach ( $scripts->done as $handle ) {
			$script = $scripts->registered[ $handle ] ?? null;
			if ( null === $script ) {
				continue;
			}

			$data = $scripts->get_data( $handle, 'data' );
			$item = array(
				'url'    => \is_string( $script->src ) && '' !== $script->src ? self::url( (string) $scripts->base_url, $script->src, false === $script->ver ? $scripts->default_version : $script->ver ) : '',
				'footer' => \in_array( $scripts->get_data( $handle, 'group' ), array( 1, '1' ), true ),
				'before' => $scripts->get_inline_script_data( $handle, 'before' ),
				'after'  => $scripts->get_inline_script_data( $handle, 'after' ),
				'data'   => \is_string( $data ) ? $data : '',
			);

			// Aliases with no file and no inline code have nothing to print.
			if ( '' !== $item['url'] || '' !== $item['before'] || '' !== $item['after'] || '' !== $item['data'] ) {
				$list['scripts'][ $handle ] = $item;
			}
		}

		$enqueued = $modules->get_queue();
		$pending  = $enqueued;
		while ( array() !== $pending ) {
			$id     = \array_shift( $pending );
			$module = isset( $list['modules'][ $id ] ) ? null : $modules->get_registered( $id );
			if ( null === $module ) {
				continue;
			}

			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core's documented filter for a module's page data.
			$data = apply_filters( 'script_module_data_' . $id, array() );
			$deps = \array_column( $module['dependencies'], 'id' );

			$list['modules'][ $id ] = array(
				'url'      => self::url( \untrailingslashit( site_url() ), $module['src'], $module['version'] ),
				'footer'   => $module['in_footer'],
				'deps'     => $deps,
				'enqueued' => \in_array( $id, $enqueued, true ),
				'data'     => \is_array( $data ) && array() !== $data ? (string) wp_json_encode( $data ) : '',
			);

			$pending = \array_merge( $pending, $deps );
		}

		if ( self::load() !== $list ) {
			update_option( self::OPTION, $list, false );
		}
	}

	// endregion

	// region HELPERS

	/**
	 * A full URL for a source that may be relative to the site, with its version.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $base    The URL a relative source is added to.
	 * @param   string $src     The source.
	 * @param   mixed  $version The version, used when it is a string.
	 *
	 * @return  string
	 */
	private static function url( string $base, string $src, mixed $version ): string {
		$url = 1 === \preg_match( '#^(https?:)?//#', $src ) ? $src : $base . $src;

		return \is_string( $version ) && '' !== $version ? add_query_arg( 'ver', $version, $url ) : $url;
	}

	// endregion
}
