<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Page;

\defined( 'ABSPATH' ) || exit;

/**
 * The captured stylesheets and scripts as checklist items, grouped by where they come from, and
 * which are ticked. WordPress, theme and inline-only items are ticked by default.
 *
 * @since   1.0.0
 * @version 1.0.0
 *
 * @phpstan-type ItemData array{label: string, url: string, notes: list<string>, group: string, default: bool}
 * @phpstan-type TickedData array{styles: list<string>, scripts: list<string>}
 */
final class AssetList {
	// region FIELDS AND CONSTANTS

	/**
	 * The option holding the ticked items.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string TICKED_OPTION = 'a8csp_cached_404_ticked';

	// endregion

	// region METHODS

	/**
	 * The captured stylesheets, keyed by handle.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  array<string, ItemData>
	 */
	public static function styles(): array {
		$items = array();
		foreach ( StyleList::load() as $handle => $style ) {
			$items[ $handle ] = self::item( $handle, $style['url'], '' !== $style['inline'] ? __( 'inline CSS', 'a8csp-cached-404-page' ) : '', __( 'Inline CSS only', 'a8csp-cached-404-page' ) );
		}

		return $items;
	}

	/**
	 * The captured scripts as `script:<handle>` and enqueued script modules as `module:<id>`.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  array<string, ItemData>
	 */
	public static function scripts(): array {
		$recorded = ScriptList::load();
		$inline   = __( 'Inline scripts only', 'a8csp-cached-404-page' );

		$items = array();
		foreach ( $recorded['scripts'] as $handle => $script ) {
			$items[ 'script:' . $handle ] = self::item( $handle, $script['url'], '' !== $script['before'] . $script['after'] . $script['data'] ? __( 'inline script', 'a8csp-cached-404-page' ) : '', $inline );
		}

		foreach ( $recorded['modules'] as $id => $module ) {
			if ( $module['enqueued'] ) {
				$items[ 'module:' . $id ] = self::item( $id, $module['url'], __( 'module', 'a8csp-cached-404-page' ), $inline );
			}
		}

		return $items;
	}

	/**
	 * The default ticks for the current capture.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  TickedData
	 */
	public static function defaults(): array {
		$default = static fn ( array $item ): bool => $item['default'];

		return array(
			'styles'  => \array_map( 'strval', \array_keys( \array_filter( self::styles(), $default ) ) ),
			'scripts' => \array_map( 'strval', \array_keys( \array_filter( self::scripts(), $default ) ) ),
		);
	}

	/**
	 * The ticked items, or the defaults when none are saved.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  TickedData
	 */
	public static function ticked(): array {
		$stored = get_option( self::TICKED_OPTION, null );
		if ( ! \is_array( $stored ) ) {
			return self::defaults();
		}

		return array(
			'styles'  => \is_array( $stored['styles'] ?? null ) ? \array_values( \array_filter( $stored['styles'], 'is_string' ) ) : array(),
			'scripts' => \is_array( $stored['scripts'] ?? null ) ? \array_values( \array_filter( $stored['scripts'], 'is_string' ) ) : array(),
		);
	}

	/**
	 * Saves the ticked items, keeping only those in the current capture.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   list<string> $styles  The ticked stylesheet handles.
	 * @param   list<string> $scripts The ticked `script:` and `module:` keys.
	 *
	 * @return  void
	 */
	public static function save_ticked( array $styles, array $scripts ): void {
		update_option(
			self::TICKED_OPTION,
			array(
				'styles'  => \array_values( \array_intersect( $styles, \array_map( 'strval', \array_keys( self::styles() ) ) ) ),
				'scripts' => \array_values( \array_intersect( $scripts, \array_map( 'strval', \array_keys( self::scripts() ) ) ) ),
			),
			false
		);
	}

	// endregion

	// region HELPERS

	/**
	 * One checklist item, with its group and default read from where its file lives.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $label        The handle or module ID.
	 * @param   string $url          The file URL, or '' for inline code only.
	 * @param   string $note         What else it prints, such as "inline CSS", or ''.
	 * @param   string $inline_group The group for items with no file.
	 *
	 * @return  ItemData
	 */
	private static function item( string $label, string $url, string $note, string $inline_group ): array {
		$notes = '' !== $note ? array( $note ) : array();
		if ( '' === $url ) {
			return array(
				'label'   => $label,
				'url'     => '',
				'notes'   => $notes,
				'group'   => $inline_group,
				'default' => true,
			);
		}

		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		\array_unshift( $notes, \basename( $path ) );

		if ( 1 === \preg_match( '#/themes/([^/]+)/#', $path, $match ) ) {
			$name = wp_get_theme( $match[1] )->get( 'Name' );
			/* translators: %s: theme name */
			$group   = \sprintf( __( 'Theme: %s', 'a8csp-cached-404-page' ), \is_string( $name ) && '' !== $name ? $name : $match[1] );
			$default = true;
		} elseif ( 1 === \preg_match( '#/(?:mu-)?plugins/([^/]+)/#', $path, $match ) ) {
			/* translators: %s: plugin name */
			$group   = \sprintf( __( 'Plugin: %s', 'a8csp-cached-404-page' ), self::plugin_name( $match[1] ) );
			$default = false;
		} elseif ( \str_contains( $path, '/wp-includes/' ) ) {
			$group   = __( 'WordPress', 'a8csp-cached-404-page' );
			$default = true;
		} else {
			$group   = __( 'Other', 'a8csp-cached-404-page' );
			$default = false;
		}

		return array(
			'label'   => $label,
			'url'     => $url,
			'notes'   => $notes,
			'group'   => $group,
			'default' => $default,
		);
	}

	/**
	 * A plugin's name from its folder, or the folder when no installed plugin matches.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $folder The plugin folder.
	 *
	 * @return  string
	 */
	private static function plugin_name( string $folder ): string {
		if ( ! \function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		foreach ( get_plugins() as $file => $data ) {
			if ( \str_starts_with( $file, $folder . '/' ) && '' !== $data['Name'] ) {
				return $data['Name'];
			}
		}

		return $folder;
	}

	// endregion
}
