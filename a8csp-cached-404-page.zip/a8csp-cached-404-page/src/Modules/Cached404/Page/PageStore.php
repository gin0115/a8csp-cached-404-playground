<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Page;

use A8C\SpecialProjects\A8cspCached404Page\Settings\Settings;

\defined( 'ABSPATH' ) || exit;

/**
 * Sets the stored 404 page: a filter's file, the uploaded file, plain "Not Found", or the captured
 * 404 written into uploads. The request check only reads the path saved here.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class PageStore {
	// region FIELDS AND CONSTANTS

	/**
	 * The folder under the uploads base directory.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string DIRECTORY = 'a8csp-cached-404';

	/**
	 * The file name.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string FILE = '404.html';

	/**
	 * The file a site can place in the uploads folder itself.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string UPLOADED_FILE = 'cached-404.html';

	/**
	 * The filter that sets the page file, overruling the chosen source.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string FILTER = 'a8csp_cached_404_page_file';

	// endregion

	// region METHODS

	/**
	 * Returns the settings with the stored page's path, or with no path when there is none, so the
	 * plain "Not Found" page is sent.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The current settings.
	 *
	 * @return  Settings
	 */
	public function build( Settings $settings ): Settings {
		$filtered = self::filtered_file();
		if ( null !== $filtered ) {
			return $settings->with_page_file( \is_readable( $filtered ) ? $filtered : '' );
		}

		return match ( $settings->page_source() ) {
			'file'  => $settings->with_page_file( \is_readable( self::uploaded_file() ) ? self::uploaded_file() : '' ),
			'plain' => $settings->with_page_file( '' ),
			default => $this->write( $settings ),
		};
	}

	/**
	 * The page file a filter sets, or null when none does. Read on Save and in WP-CLI, where themes
	 * and plugins have loaded; the request check runs before them.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  string|null
	 */
	public static function filtered_file(): ?string {
		/**
		 * Filters the absolute path of the page sent for missing items. A path overrules the chosen source.
		 *
		 * @since 1.0.0
		 *
		 * @param string $file The path, or '' to use the chosen source.
		 */
		$file = apply_filters( 'a8csp_cached_404_page_file', '' ); // Same as `FILTER`; PHPCS needs the name written out.

		return \is_string( $file ) && '' !== $file ? $file : null;
	}

	/**
	 * The absolute path of `uploads/cached-404.html`, or '' when uploads is unavailable.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  string
	 */
	public static function uploaded_file(): string {
		$uploads = wp_upload_dir( null, false );
		if ( false !== $uploads['error'] && '' !== $uploads['error'] ) {
			return '';
		}

		return trailingslashit( $uploads['basedir'] ) . self::UPLOADED_FILE;
	}

	// endregion

	// region HELPERS

	/**
	 * Writes the captured 404, with the ticked stylesheets and scripts, into uploads and returns the
	 * settings with its path, or with no path when writing failed. Before a capture it writes the
	 * placeholder page.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The current settings.
	 *
	 * @return  Settings
	 */
	private function write( Settings $settings ): Settings {
		$uploads = wp_upload_dir( null, true );
		if ( false !== $uploads['error'] && '' !== $uploads['error'] ) {
			return $settings->with_page_file( '' );
		}

		$directory = trailingslashit( $uploads['basedir'] ) . self::DIRECTORY;
		if ( ! wp_mkdir_p( $directory ) ) {
			return $settings->with_page_file( '' );
		}

		$file     = $directory . '/' . self::FILE;
		$captured = Capture::html();
		$html     = '' !== $captured ? PageBuilder::build( $captured, AssetList::ticked() ) : self::html( get_bloginfo( 'name' ), home_url( '/' ), get_bloginfo( 'language' ) );

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- A single local write into uploads, run from the admin page or WP-CLI.
		if ( false === \file_put_contents( $file, $html ) ) {
			return $settings->with_page_file( '' );
		}

		return $settings->with_page_file( $file );
	}

	/**
	 * The placeholder page, used while the template has no content: a plain document with no
	 * external assets.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $site_name The site name.
	 * @param   string $home_url  The home URL.
	 * @param   string $language  The site language tag.
	 *
	 * @return  string
	 */
	public static function html( string $site_name, string $home_url, string $language ): string {
		$title = __( 'Page not found', 'a8csp-cached-404-page' );

		return '<!DOCTYPE html>'
			. '<html lang="' . esc_attr( $language ) . '">'
			. '<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">'
			. '<title>' . esc_html( $title . ' | ' . $site_name ) . '</title></head>'
			. '<body><h1>' . esc_html( $title ) . '</h1>'
			. '<p>' . esc_html__( 'The page you were looking for does not exist.', 'a8csp-cached-404-page' ) . '</p>'
			. '<p><a href="' . esc_url( $home_url ) . '">' . esc_html( $site_name ) . '</a></p>'
			. '</body></html>';
	}

	// endregion
}
