<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Request;

\defined( 'ABSPATH' ) || exit;

/**
 * What a shortcut found for a request path.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
enum ShortcutResult {
	/**
	 * The path is this shortcut's URL type and the item does not exist.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	case Missing;

	/**
	 * The path is this shortcut's URL type and the item exists.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	case Exists;

	/**
	 * The path is not this shortcut's URL type, or it cannot tell.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	case NotMine;
}
