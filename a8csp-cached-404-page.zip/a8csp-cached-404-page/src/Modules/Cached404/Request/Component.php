<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Request;

use A8C\SpecialProjects\A8cspCached404Page\AbstractComponent;
use A8C\SpecialProjects\A8cspCached404Page\Request\Shortcut\Taxonomy;

\defined( 'ABSPATH' ) || exit;

/**
 * Keeps the request check's cached lookups in step with content changes.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class Component extends AbstractComponent {
	// region METHODS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function register_hooks(): void {
		add_action( 'saved_term', array( $this, 'forget_term' ), 10, 3 );
	}

	// endregion

	// region HOOKS

	/**
	 * Clears a saved term's cached lookup, so a new or renamed term is never cached as missing.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   int    $term_id  The term ID.
	 * @param   int    $tt_id    The term taxonomy ID.
	 * @param   string $taxonomy The taxonomy name.
	 *
	 * @return  void
	 */
	public function forget_term( int $term_id, int $tt_id, string $taxonomy ): void {
		$term = get_term( $term_id, $taxonomy );
		if ( $term instanceof \WP_Term ) {
			wp_cache_delete( Taxonomy::cache_key( $taxonomy, $term->slug ), Taxonomy::CACHE_GROUP );
		}
	}

	// endregion
}
