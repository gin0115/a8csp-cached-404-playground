<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Request\Prefix;

\defined( 'ABSPATH' ) || exit;

/**
 * Removes a Weglot language folder and swaps each translated part of the rest back to the original,
 * as Weglot does before WordPress reads the address (`Url::detectUrlDetails()` in Weglot 6.4.2).
 * The swaps are Weglot's own, `[language => [translated => original]]`: the `weglot_slugs_cache`
 * transient, plus `custom_urls` in its cached settings, `weglot_cache_cdn`. Without either, or for
 * a part Weglot would redirect, the request is left to WordPress.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class WeglotPrefix implements PathPrefixInterface {
	// region CONSTRUCTORS

	/**
	 * WeglotPrefix constructor.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   list<string> $folders The Weglot folders that are on, such as `fr`.
	 */
	public function __construct( private readonly array $folders ) {}

	// endregion

	// region METHODS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function strip( string $path ): ?string {
		foreach ( $this->folders as $folder ) {
			if ( ! \str_starts_with( $path, '/' . $folder . '/' ) ) {
				continue;
			}

			$swaps = self::swaps( $folder );
			if ( null === $swaps ) {
				return null;
			}

			$parts = \explode( '/', \substr( $path, \strlen( $folder ) + 1 ) );
			foreach ( $parts as $index => $part ) {
				$part = \urldecode( $part );

				// Weglot redirects an original that has a translation, such as /fr/product/ to /fr/produit/.
				if ( \in_array( $part, $swaps, true ) ) {
					return null;
				}

				if ( isset( $swaps[ $part ] ) ) {
					$parts[ $index ] = \rawurlencode( $swaps[ $part ] );
				}
			}

			return \implode( '/', $parts );
		}

		return $path;
	}

	// endregion

	// region HELPERS

	/**
	 * Weglot's translated-to-original parts for a folder's language, or null when its stored lists
	 * are missing or do not name the folder.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $folder The folder, such as `fr`.
	 *
	 * @return  array<string, string>|null
	 */
	private static function swaps( string $folder ): ?array {
		$settings = get_transient( 'weglot_cache_cdn' );
		$slugs    = get_transient( 'weglot_slugs_cache' );
		if ( ! \is_array( $settings ) || ! \is_array( $slugs ) || ! \is_array( $settings['languages'] ?? null ) ) {
			return null;
		}

		// The folder is the custom code when set, else the language code. A language whose address code
		// differs from its own (pt-br for br) is not matched, so its addresses are left to WordPress.
		$language = null;
		foreach ( $settings['languages'] as $entry ) {
			$code    = \is_array( $entry ) ? ( $entry['language_to'] ?? null ) : null;
			$custom  = \is_array( $entry ) ? ( $entry['custom_code'] ?? null ) : null;
			$address = \is_string( $custom ) && '' !== $custom ? $custom : $code;
			if ( \is_string( $code ) && $address === $folder ) {
				$language = $code;
				break;
			}
		}

		if ( null === $language || ! \is_array( $slugs[ $language ] ?? null ) ) {
			return null;
		}

		// Weglot merges the slugs over the custom URLs, so the slugs win.
		$custom_urls = \is_array( $settings['custom_urls'] ?? null ) && \is_array( $settings['custom_urls'][ $language ] ?? null ) ? $settings['custom_urls'][ $language ] : array();
		$swaps       = array();
		foreach ( $slugs[ $language ] + $custom_urls as $translated => $original ) {
			if ( \is_string( $original ) && '' !== $original ) {
				$swaps[ (string) $translated ] = $original;
			}
		}

		return $swaps;
	}

	// endregion
}
