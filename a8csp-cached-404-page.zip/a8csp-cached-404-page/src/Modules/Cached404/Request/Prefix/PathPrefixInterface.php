<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Request\Prefix;

\defined( 'ABSPATH' ) || exit;

/**
 * One step that prepares the request path before the shortcuts see it.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
interface PathPrefixInterface {
	// region METHODS

	/**
	 * Returns the path with this step's prefix removed, the path unchanged, or null to skip every
	 * shortcut for this request.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $path The request path, starting with `/`.
	 *
	 * @return  string|null
	 */
	public function strip( string $path ): ?string;

	// endregion
}
