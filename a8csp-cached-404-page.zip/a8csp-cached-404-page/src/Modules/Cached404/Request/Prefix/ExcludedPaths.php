<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Request\Prefix;

\defined( 'ABSPATH' ) || exit;

/**
 * Skips every shortcut for paths that start with an excluded path.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class ExcludedPaths implements PathPrefixInterface {
	// region CONSTRUCTORS

	/**
	 * ExcludedPaths constructor.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   list<string> $excluded Path starts, each beginning with `/`.
	 */
	public function __construct( private readonly array $excluded ) {}

	// endregion

	// region METHODS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function strip( string $path ): ?string {
		foreach ( $this->excluded as $excluded ) {
			if ( \str_starts_with( $path, $excluded ) ) {
				return null;
			}
		}

		return $path;
	}

	// endregion
}
