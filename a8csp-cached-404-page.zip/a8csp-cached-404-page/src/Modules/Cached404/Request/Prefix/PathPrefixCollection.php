<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Request\Prefix;

use A8C\SpecialProjects\A8cspCached404Page\Detection\Language\Weglot;
use A8C\SpecialProjects\A8cspCached404Page\Settings\Settings;

\defined( 'ABSPATH' ) || exit;

/**
 * The path steps for this request, run in order: the site folder, then the language folders that
 * are on, then the exclusions (which are written without either).
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class PathPrefixCollection {
	// region CONSTRUCTORS

	/**
	 * PathPrefixCollection constructor.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   list<PathPrefixInterface> $steps The steps, in order.
	 */
	public function __construct( private readonly array $steps ) {}

	// endregion

	// region METHODS

	/**
	 * Builds the steps from the settings.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The current settings.
	 *
	 * @return  self
	 */
	public static function from_settings( Settings $settings ): self {
		$steps = array();
		if ( '' !== $settings->site_path() ) {
			$steps[] = new SitePath( $settings->site_path() );
		}

		$folders = array();
		$weglot  = array();
		foreach ( $settings->prefixes() as $key => $prefix ) {
			if ( ! $prefix['enabled'] ) {
				continue;
			}

			// Weglot's folders also need its translated slugs swapped back.
			if ( Weglot::KEY === $key ) {
				$weglot = $prefix['values'];
			} else {
				$folders = \array_merge( $folders, $prefix['values'] );
			}
		}

		if ( array() !== $folders ) {
			$steps[] = new LanguagePrefix( \array_values( \array_unique( $folders ) ) );
		}

		if ( array() !== $weglot ) {
			$steps[] = new WeglotPrefix( $weglot );
		}

		if ( array() !== $settings->excluded() ) {
			$steps[] = new ExcludedPaths( $settings->excluded() );
		}

		return new self( $steps );
	}

	/**
	 * Runs every step, or returns null as soon as one says to skip the shortcuts.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $path The request path.
	 *
	 * @return  string|null
	 */
	public function apply( string $path ): ?string {
		foreach ( $this->steps as $step ) {
			$path = $step->strip( $path );
			if ( null === $path ) {
				return null;
			}
		}

		return $path;
	}

	// endregion
}
