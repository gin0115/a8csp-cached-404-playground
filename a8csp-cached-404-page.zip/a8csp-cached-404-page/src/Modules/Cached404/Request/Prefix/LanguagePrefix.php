<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Request\Prefix;

\defined( 'ABSPATH' ) || exit;

/**
 * Removes one known language folder, such as `/fr`. Detection supplies the folders for each
 * translation plugin; a folder it does not know stays on the path, so that URL matches no shortcut.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class LanguagePrefix implements PathPrefixInterface {
	// region CONSTRUCTORS

	/**
	 * LanguagePrefix constructor.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   list<string> $folders The language folders, without slashes.
	 */
	public function __construct( private readonly array $folders ) {}

	// endregion

	// region METHODS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function strip( string $path ): string {
		foreach ( $this->folders as $folder ) {
			if ( \str_starts_with( $path, '/' . $folder . '/' ) ) {
				return \substr( $path, \strlen( $folder ) + 1 );
			}
		}

		return $path;
	}

	// endregion
}
