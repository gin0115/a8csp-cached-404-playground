<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Request\Prefix;

\defined( 'ABSPATH' ) || exit;

/**
 * Removes the folder a site is installed under, such as `/blog` for `https://example.com/blog/`.
 * A path outside that folder is not this site's, so every shortcut is skipped.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class SitePath implements PathPrefixInterface {
	// region CONSTRUCTORS

	/**
	 * SitePath constructor.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $site_path The folder, without slashes.
	 */
	public function __construct( private readonly string $site_path ) {}

	// endregion

	// region METHODS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function strip( string $path ): ?string {
		$folder = '/' . $this->site_path;
		if ( $path === $folder ) {
			return '/';
		}

		return \str_starts_with( $path, $folder . '/' ) ? \substr( $path, \strlen( $folder ) ) : null;
	}

	// endregion
}
