<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Request;

use A8C\SpecialProjects\A8cspCached404Page\Page\Capture;
use A8C\SpecialProjects\A8cspCached404Page\Request\Prefix\PathPrefixCollection;
use A8C\SpecialProjects\A8cspCached404Page\Request\Shortcut\ShortcutCollection;
use A8C\SpecialProjects\A8cspCached404Page\Settings\Settings;

\defined( 'ABSPATH' ) || exit;

/**
 * Runs the request check against the live request, from the entry file, before normal plugins,
 * the theme and the main query load.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class EarlyResponse {
	// region METHODS

	/**
	 * Sends the light 404 and exits when the requested item is missing; otherwise returns.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public static function maybe_send(): void {
		$method = isset( $_SERVER['REQUEST_METHOD'] ) && \is_string( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Compared against fixed values only.
		if ( ( 'GET' !== $method && 'HEAD' !== $method ) || is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
			return;
		}

		// Only front-end pages: index.php defines this first, unlike wp-login.php and the other entry files.
		if ( ! \defined( 'WP_USE_THEMES' ) || ! \constant( 'WP_USE_THEMES' ) ) {
			return;
		}

		// The capture of the site's own 404 goes to WordPress; its key is checked once plugins load.
		$settings = Settings::load();
		if ( ! $settings->is_enabled() || Capture::is_marked() ) {
			return;
		}

		// Not sanitised: that strips %XX octets. Each shortcut's own pattern is the validation.
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$uri = isset( $_SERVER['REQUEST_URI'] ) && \is_string( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';

		$check = new RequestCheck( ShortcutCollection::from_settings( $settings ), PathPrefixCollection::from_settings( $settings ) );
		$key   = $check->check( $method, $uri );
		if ( null !== $key ) {
			Responder::send( $key, $settings->page_file() );
		}
	}

	// endregion
}
