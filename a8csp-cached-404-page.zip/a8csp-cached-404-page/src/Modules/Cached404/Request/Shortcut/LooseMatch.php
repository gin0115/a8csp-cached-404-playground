<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Request\Shortcut;

use A8C\SpecialProjects\A8cspCached404Page\Request\ShortcutResult;

\defined( 'ABSPATH' ) || exit;

/**
 * Loose mode: any address, checked against the site's saved rewrite rules the way
 * `WP::parse_request()` reads them. The first rule that matches decides; it is answered only when
 * that rule names a single page, attachment, post or post type item, with nothing beside it but a
 * page number, the post type or date parts, and no post could answer the name. Every other rule
 * (REST, sitemaps, search, feeds, archives, endpoints) is left to WordPress, as are `.xml` and
 * `.xsl` files, which sitemap plugins may answer in their own code. Other plugins that route
 * addresses in their own code, outside the rules, are not seen this early.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class LooseMatch implements ShortcutInterface {
	// region FIELDS AND CONSTANTS

	/**
	 * The query variables that name a page, an attachment or a post.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @var     list<string>
	 */
	private const array NAME_VARS = array( 'pagename', 'attachment', 'name' );

	/**
	 * Query variables that may sit beside the name without changing what WordPress looks up.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @var     list<string>
	 */
	private const array PLAIN_VARS = array( 'page', 'post_type', 'year', 'monthnum', 'day', 'hour', 'minute', 'second' );

	// endregion

	// region CONSTRUCTORS

	/**
	 * LooseMatch constructor.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   array<string, string> $rules          The saved rewrite rules, pattern to query, in order.
	 * @param   bool                  $verbose_pages  Whether WordPress skips a page rule whose page does not exist.
	 * @param   list<string>          $post_type_vars The query variables that name a post type's item.
	 */
	public function __construct(
		private readonly array $rules,
		private readonly bool $verbose_pages,
		private readonly array $post_type_vars,
	) {}

	// endregion

	// region METHODS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function key(): string {
		return 'loose';
	}

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function check( string $path ): ShortcutResult {
		$request = \trim( $path, '/' );
		if ( '' === $request ) {
			return ShortcutResult::NotMine;
		}

		// Sitemap plugins may answer these in their own code, outside the rules.
		if ( 1 === \preg_match( '/\.(xml|xsl)$/i', $request ) ) {
			return ShortcutResult::NotMine;
		}

		foreach ( $this->rules as $pattern => $query ) {
			if ( 1 !== \preg_match( '#^' . $pattern . '#', $request, $matches ) && 1 !== \preg_match( '#^' . $pattern . '#', \urldecode( $request ), $matches ) ) {
				continue;
			}

			$vars = self::vars( $query, $matches );

			// As WordPress does with verbose page rules, a page rule whose page is not found is passed over.
			if ( $this->verbose_pages && isset( $vars['pagename'] ) && 1 === \preg_match( '/pagename=\$matches\[[0-9]+\]/', $query ) && ! self::exists( $vars['pagename'] ) ) {
				continue;
			}

			return $this->decide( $vars );
		}

		return ShortcutResult::NotMine;
	}

	// endregion

	// region HELPERS

	/**
	 * The rule's query variables with the matched parts put in. Empty ones are kept: an endpoint
	 * with no value, such as `members-area=`, still changes what WordPress does.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string                    $query   The rule's query, such as `index.php?pagename=$matches[1]`.
	 * @param   array<int|string, string> $matches The parts the rule matched.
	 *
	 * @return  array<string, string>
	 */
	private static function vars( string $query, array $matches ): array {
		$query = (string) \preg_replace( '/^index\.php\?/', '', $query );
		$query = (string) \preg_replace_callback( '/\$matches\[([0-9]+)\]/', static fn ( array $part ): string => \rawurlencode( $matches[ (int) $part[1] ] ?? '' ), $query );

		\parse_str( $query, $parsed );

		$vars = array();
		foreach ( $parsed as $var => $value ) {
			$vars[ (string) $var ] = \is_string( $value ) ? $value : '';
		}

		return $vars;
	}

	/**
	 * Missing when the rule names one item, with nothing else that changes the lookup, and no post
	 * could answer it; otherwise exists or not this check's.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   array<string, string> $vars The rule's query variables.
	 *
	 * @return  ShortcutResult
	 */
	private function decide( array $vars ): ShortcutResult {
		$named = \array_filter( $vars, static fn ( string $value ): bool => '' !== $value );
		$names = \array_values( \array_intersect( \array_keys( $named ), \array_merge( self::NAME_VARS, $this->post_type_vars ) ) );
		if ( 1 !== \count( $names ) ) {
			return ShortcutResult::NotMine;
		}

		// Anything else present, even empty, changes the lookup; only an empty or numeric page does not.
		foreach ( $vars as $var => $value ) {
			if ( $var !== $names[0] && ( ! \in_array( $var, self::PLAIN_VARS, true ) || ( 'page' === $var && 1 !== \preg_match( '/^[0-9]*$/', $value ) ) ) ) {
				return ShortcutResult::NotMine;
			}
		}

		return self::exists( $vars[ $names[0] ] ) ? ShortcutResult::Exists : ShortcutResult::Missing;
	}

	/**
	 * Whether a post could answer the last part of a name, as written or in the dashed form
	 * WordPress guesses redirects with (`state.cartItem` becomes `state-cartitem`).
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $name The page path, attachment name or post name.
	 *
	 * @return  bool
	 */
	private static function exists( string $name ): bool {
		$parts = \explode( '/', \trim( $name, '/' ) );
		$slug  = \strtolower( $parts[ \count( $parts ) - 1 ] );
		if ( '' === $slug ) {
			return true;
		}

		$slugs = array( $slug );
		if ( \function_exists( 'sanitize_title_with_dashes' ) ) {
			$slugs[] = sanitize_title_with_dashes( $slug );
		}

		foreach ( \array_unique( $slugs ) as $candidate ) {
			if ( '' !== $candidate && PostLookup::exists( $candidate ) ) {
				return true;
			}
		}

		return false;
	}

	// endregion
}
