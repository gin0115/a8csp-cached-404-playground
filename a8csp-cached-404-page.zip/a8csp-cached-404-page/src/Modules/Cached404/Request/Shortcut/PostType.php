<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Request\Shortcut;

\defined( 'ABSPATH' ) || exit;

/**
 * Single items of a post type that has a URL base, such as `/product/<slug>/`, plus the embed and
 * `<slug>/2/` page forms. A hierarchical post type takes nested paths, and the last part is checked.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class PostType extends AbstractBaseShortcut implements SingleItemShortcut {
	// region METHODS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function matches( string $path ): bool {
		return null !== $this->slug( $path );
	}

	// endregion

	// region HELPERS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	protected function endings(): string {
		return '(?:embed/|[0-9]+/)?';
	}

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	protected function exists( string $slug ): bool {
		return PostLookup::exists( $slug );
	}

	// endregion
}
