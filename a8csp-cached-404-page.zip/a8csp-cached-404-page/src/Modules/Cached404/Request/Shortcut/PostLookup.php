<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Request\Shortcut;

\defined( 'ABSPATH' ) || exit;

/**
 * Whether WordPress could answer a single-item URL with something other than a 404. A missing slug
 * is not enough: `redirect_guess_404_permalink()` redirects to any post whose name starts with it
 * (`post_name LIKE 'slug%'`), and `wp_old_slug_redirect()` redirects renamed items through
 * `_wp_old_slug`. Both are checked across every post type and status, which only errs towards "exists".
 *
 * Only found posts are cached. A new post named `hello-world` makes `hello` exist too, so a cached
 * miss for `hello` could not be cleared by an exact key.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class PostLookup {
	// region METHODS

	/**
	 * Whether a post could answer this slug.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $slug The lower-cased slug.
	 *
	 * @return  bool
	 */
	public static function exists( string $slug ): bool {
		global $wpdb;

		$cache_key = 'post:' . $slug;
		if ( 0 < (int) wp_cache_get( $cache_key, Taxonomy::CACHE_GROUP ) ) {
			return true;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Found posts are cached below; misses cannot be.
		$found = (int) $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_name LIKE %s LIMIT 1", $wpdb->esc_like( $slug ) . '%' ) );
		if ( 0 === $found ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.SlowDBQuery.slow_db_query_meta_key, WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- Same lookup as _find_post_by_old_slug(), run only when no post name matched.
			$found = (int) $wpdb->get_var( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_wp_old_slug' AND meta_value = %s LIMIT 1", $slug ) );
		}

		if ( 0 < $found ) {
			wp_cache_set( $cache_key, $found, Taxonomy::CACHE_GROUP, Taxonomy::CACHE_SECONDS );
		}

		return 0 < $found;
	}

	// endregion
}
