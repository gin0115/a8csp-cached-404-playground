<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Request\Shortcut;

use A8C\SpecialProjects\A8cspCached404Page\Request\ShortcutResult;

\defined( 'ABSPATH' ) || exit;

/**
 * One made-up segment after a real single item, such as `/product/<slug>/<anything>/`, often used to
 * get past page caches. WordPress's single-item rules read that segment as an attachment name
 * (`<base>/[^/]+/([^/]+)/?$` → `attachment=`), so the path is missing when no post could answer the
 * segment. Endpoints registered for single items, WordPress's own path words, a missing item, and
 * another archive's address of the same shape (`/blog/type/aside/` under `/blog/%postname%/`) are
 * left to WordPress.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class ExtraSegment implements ShortcutInterface {
	// region FIELDS AND CONSTANTS

	/**
	 * Path words WordPress gives a meaning after an item, and page numbers.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	private const string RESERVED = '/^(?:page|feed|rdf|rss|rss2|atom|embed|trackback|attachment|comment-page-[0-9]+|[0-9]+)$/';

	// endregion

	// region CONSTRUCTORS

	/**
	 * ExtraSegment constructor.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   SingleItemShortcut $item      The single-item URL type the segment follows.
	 * @param   list<string>       $endpoints The endpoints registered for single items.
	 * @param   list<string>       $archives  The fixed start of other archives' addresses, such as `blog/type`.
	 */
	public function __construct(
		private readonly SingleItemShortcut $item,
		private readonly array $endpoints,
		private readonly array $archives = array(),
	) {}

	// endregion

	// region METHODS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function key(): string {
		return $this->item->key() . '/extra';
	}

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function check( string $path ): ShortcutResult {
		if ( 1 !== \preg_match( '#^(?<item>/(?:[^/]+/)*(?<last>[^/]+)/)(?<extra>[A-Za-z0-9-]+)/$#', $path, $matches ) ) {
			return ShortcutResult::NotMine;
		}

		// The item must be the bare single-item path, not its embed or page form.
		$extra = \strtolower( $matches['extra'] );
		if ( 1 === \preg_match( self::RESERVED, $extra ) || 1 === \preg_match( self::RESERVED, \strtolower( $matches['last'] ) ) || \in_array( $extra, $this->endpoints, true ) ) {
			return ShortcutResult::NotMine;
		}

		if ( ! $this->item->matches( $matches['item'] ) || \in_array( \strtolower( \trim( $matches['item'], '/' ) ), $this->archives, true ) ) {
			return ShortcutResult::NotMine;
		}

		// Only after a real item: an unknown name in the item's place may be another plugin's address.
		if ( ShortcutResult::Exists !== $this->item->check( $matches['item'] ) ) {
			return ShortcutResult::NotMine;
		}

		return PostLookup::exists( $extra ) ? ShortcutResult::Exists : ShortcutResult::Missing;
	}

	// endregion
}
