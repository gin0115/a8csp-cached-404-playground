<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Request\Shortcut;

\defined( 'ABSPATH' ) || exit;

/**
 * Author archives: `/<base>/<nicename>/` and their paged form. WordPress does not 404 an author
 * with no posts, so only a nicename no user has counts as missing.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class Author extends AbstractBaseShortcut {
	// region HELPERS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	protected function endings(): string {
		return '(?:page/[0-9]+/)?';
	}

	/**
	 * Whether a user has this nicename. Only found users are cached.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $slug The nicename.
	 *
	 * @return  bool
	 */
	#[\Override]
	protected function exists( string $slug ): bool {
		global $wpdb;

		$cache_key = 'author:' . $slug;
		if ( 0 < (int) wp_cache_get( $cache_key, Taxonomy::CACHE_GROUP ) ) {
			return true;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Found users are cached below.
		$found = (int) $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM {$wpdb->users} WHERE user_nicename = %s LIMIT 1", $slug ) );
		if ( 0 < $found ) {
			wp_cache_set( $cache_key, $found, Taxonomy::CACHE_GROUP, Taxonomy::CACHE_SECONDS );
		}

		return 0 < $found;
	}

	// endregion
}
