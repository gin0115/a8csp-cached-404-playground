<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Request\Shortcut;

\defined( 'ABSPATH' ) || exit;

/**
 * Term archives: `/<base>/<slug>/`, plus the embed and paged forms WordPress registers for them. A
 * hierarchical taxonomy also takes nested paths, and the last part is checked.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class Taxonomy extends AbstractBaseShortcut {
	// region FIELDS AND CONSTANTS

	/**
	 * Object cache group for every lookup the request check makes.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string CACHE_GROUP = 'a8csp_cached_404';

	/**
	 * How long a lookup stays cached.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const int CACHE_SECONDS = 3600;

	// endregion

	// region CONSTRUCTORS

	/**
	 * Taxonomy constructor.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $key          The shortcut key.
	 * @param   string $taxonomy     The taxonomy name.
	 * @param   string $base         The URL base, without slashes.
	 * @param   bool   $hierarchical Whether terms nest in the URL.
	 * @param   bool   $cache_misses Whether lookups that find nothing are cached.
	 */
	public function __construct(
		string $key,
		private readonly string $taxonomy,
		string $base,
		bool $hierarchical,
		private readonly bool $cache_misses,
	) {
		parent::__construct( $key, $base, $hierarchical );
	}

	// endregion

	// region METHODS

	/**
	 * The object cache key for one term slug.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $taxonomy The taxonomy name.
	 * @param   string $slug     The term slug.
	 *
	 * @return  string
	 */
	public static function cache_key( string $taxonomy, string $slug ): string {
		return $taxonomy . ':' . \strtolower( $slug );
	}

	// endregion

	// region HELPERS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	protected function endings(): string {
		return '(?:embed/|page/[0-9]+/)?';
	}

	/**
	 * Whether a term with this slug exists in the taxonomy. One query, cached for an hour.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $slug The term slug.
	 *
	 * @return  bool
	 */
	#[\Override]
	protected function exists( string $slug ): bool {
		global $wpdb;

		$cache_key = self::cache_key( $this->taxonomy, $slug );
		$found     = wp_cache_get( $cache_key, self::CACHE_GROUP );
		if ( false !== $found ) {
			return 0 < (int) $found;
		}

		// Taxonomies are not registered this early, so term_exists() cannot be used.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Cached in the object cache just below.
		$found = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT tt.term_taxonomy_id FROM {$wpdb->term_taxonomy} tt INNER JOIN {$wpdb->terms} t ON t.term_id = tt.term_id WHERE t.slug = %s AND tt.taxonomy = %s LIMIT 1",
				$slug,
				$this->taxonomy
			)
		);

		if ( 0 < $found || $this->cache_misses ) {
			wp_cache_set( $cache_key, $found, self::CACHE_GROUP, self::CACHE_SECONDS );
		}

		return 0 < $found;
	}

	// endregion
}
