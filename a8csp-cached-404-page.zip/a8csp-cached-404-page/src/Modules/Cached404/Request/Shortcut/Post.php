<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Request\Shortcut;

use A8C\SpecialProjects\A8cspCached404Page\Request\ShortcutResult;

\defined( 'ABSPATH' ) || exit;

/**
 * Posts, matched by the permalink structure, plus the embed and `<slug>/2/` page forms. Only
 * structures with something in front of `%postname%` (a word or date parts) and nothing after it
 * are supported. `/%postname%/` is never claimed: at the top level a slug could be a page, a
 * custom rewrite rule or a plugin endpoint, which this early check cannot tell apart.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class Post implements SingleItemShortcut {
	// region FIELDS AND CONSTANTS

	/**
	 * The structure tags that may come before `%postname%`, as regex parts.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @var     array<string, string>
	 */
	private const array DATE_TAGS = array(
		'%year%'     => '[0-9]{4}',
		'%monthnum%' => '[0-9]{1,2}',
		'%day%'      => '[0-9]{1,2}',
		'%hour%'     => '[0-9]{1,2}',
		'%minute%'   => '[0-9]{1,2}',
		'%second%'   => '[0-9]{1,2}',
	);

	// endregion

	// region CONSTRUCTORS

	/**
	 * Post constructor.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $key       The shortcut key.
	 * @param   string $structure The permalink structure, without its outer slashes.
	 */
	public function __construct(
		private readonly string $key,
		private readonly string $structure,
	) {}

	// endregion

	// region METHODS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function key(): string {
		return $this->key;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function check( string $path ): ShortcutResult {
		$slug = $this->slug( $path );
		if ( null === $slug ) {
			return ShortcutResult::NotMine;
		}

		return PostLookup::exists( $slug ) ? ShortcutResult::Exists : ShortcutResult::Missing;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function matches( string $path ): bool {
		return null !== $this->slug( $path );
	}

	/**
	 * The path regex for a permalink structure, or null when the structure is not supported.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $structure The permalink structure, with or without its outer slashes.
	 *
	 * @return  string|null
	 */
	public static function pattern( string $structure ): ?string {
		$structure = \trim( $structure, '/' );
		$parts     = \explode( '%postname%', $structure );
		if ( 2 !== \count( $parts ) || '' !== $parts[1] || '' === \trim( $parts[0], '/' ) ) {
			return null;
		}

		$front = \preg_split( '/(%[a-z_]+%)/', $parts[0], -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
		if ( false === $front ) {
			return null;
		}

		$regex = '';
		foreach ( $front as $part ) {
			if ( \str_starts_with( $part, '%' ) ) {
				if ( ! isset( self::DATE_TAGS[ $part ] ) ) {
					return null;
				}

				$regex .= self::DATE_TAGS[ $part ];
				continue;
			}

			$regex .= \preg_quote( $part, '#' );
		}

		return '#^/' . $regex . '(?<slug>[^/]+)/(?:embed/|[0-9]+/)?$#';
	}

	// endregion

	// region HELPERS

	/**
	 * The lower-cased slug from the path, or null when the path is not a post's.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $path The request path.
	 *
	 * @return  string|null
	 */
	private function slug( string $path ): ?string {
		$pattern = self::pattern( $this->structure );
		if ( null === $pattern || 1 !== \preg_match( $pattern, $path, $matches ) ) {
			return null;
		}

		// A slug of digits only could be a date archive or a page number, so it is left to WordPress.
		$slug = \strtolower( $matches['slug'] );
		if ( 1 !== \preg_match( '/^[a-z0-9-]*[a-z][a-z0-9-]*$/', $slug ) || 1 === \preg_match( '/^(?:page|feed|embed|trackback|attachment)$/', $slug ) ) {
			return null;
		}

		return $slug;
	}

	// endregion
}
