<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Request\Shortcut;

use A8C\SpecialProjects\A8cspCached404Page\Request\ShortcutResult;

\defined( 'ABSPATH' ) || exit;

/**
 * One URL type the request check can answer. A shortcut must only say `Missing` when it is sure:
 * when in doubt it says `NotMine` or `Exists`, and WordPress handles the request as normal.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
interface ShortcutInterface {
	// region METHODS

	/**
	 * The shortcut key, used in the settings, WP-CLI and the response header.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  string
	 */
	public function key(): string;

	/**
	 * Checks a request path (no query string).
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $path The request path.
	 *
	 * @return  ShortcutResult
	 */
	public function check( string $path ): ShortcutResult;

	// endregion
}
