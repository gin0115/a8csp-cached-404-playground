<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Request\Shortcut;

use A8C\SpecialProjects\A8cspCached404Page\Request\ShortcutResult;
use A8C\SpecialProjects\A8cspCached404Page\Settings\Settings;

\defined( 'ABSPATH' ) || exit;

/**
 * The enabled shortcuts for this request, in settings order.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class ShortcutCollection {
	// region CONSTRUCTORS

	/**
	 * ShortcutCollection constructor.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   list<ShortcutInterface> $shortcuts The shortcuts to run.
	 */
	public function __construct( private readonly array $shortcuts ) {}

	// endregion

	// region METHODS

	/**
	 * Builds the enabled shortcuts from the settings.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The current settings.
	 *
	 * @return  self
	 */
	public static function from_settings( Settings $settings ): self {
		$endpoints = \array_values( \array_filter( \explode( ',', $settings->detected()['sources']['permalink_endpoints'] ?? '' ), static fn ( string $endpoint ): bool => '' !== $endpoint ) );
		$archives  = \array_values( \array_filter( \explode( ',', $settings->detected()['sources']['archive_paths'] ?? '' ), static fn ( string $archive ): bool => '' !== $archive ) );

		$shortcuts = array();
		foreach ( $settings->shortcuts() as $key => $shortcut ) {
			if ( ! $shortcut['enabled'] ) {
				continue;
			}

			$built = match ( $shortcut['type'] ) {
				'taxonomy'  => new Taxonomy( $key, $shortcut['name'], $shortcut['base'], $shortcut['hierarchical'], $settings->cache_misses() ),
				'post_type' => new PostType( $key, $shortcut['base'], $shortcut['hierarchical'] ),
				'post'      => new Post( $key, $shortcut['base'] ),
				'author'    => new Author( $key, $shortcut['base'], false ),
				default     => null,
			};
			if ( null === $built ) {
				continue;
			}

			$shortcuts[] = $built;

			// A nested post type already takes more path parts as its own items.
			if ( $settings->extra_segments() && $built instanceof SingleItemShortcut && ! $shortcut['hierarchical'] ) {
				$shortcuts[] = new ExtraSegment( $built, $endpoints, $archives );
			}
		}

		$loose = $settings->loose() ? self::loose( $settings ) : null;
		if ( null !== $loose ) {
			$shortcuts[] = $loose;
		}

		return new self( $shortcuts );
	}

	/**
	 * The key of the shortcut that found the item missing, or null. Any `Exists` wins, so two URL
	 * types sharing a base can never send a 404 for a real item.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $path The request path.
	 *
	 * @return  string|null
	 */
	public function first_missing( string $path ): ?string {
		$missing = null;
		foreach ( $this->shortcuts as $shortcut ) {
			$result = $shortcut->check( $path );
			if ( ShortcutResult::Exists === $result ) {
				return null;
			}

			if ( ShortcutResult::Missing === $result && null === $missing ) {
				$missing = $shortcut->key();
			}
		}

		return $missing;
	}

	/**
	 * The loose mode check, built from the saved rewrite rules (an autoloaded option), or null when
	 * the site has none, as with plain permalinks.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The current settings.
	 *
	 * @return  LooseMatch|null
	 */
	private static function loose( Settings $settings ): ?LooseMatch {
		$saved = get_option( 'rewrite_rules' );
		$rules = array();
		foreach ( \is_array( $saved ) ? $saved : array() as $pattern => $query ) {
			if ( \is_string( $pattern ) && \is_string( $query ) ) {
				$rules[ $pattern ] = $query;
			}
		}

		if ( array() === $rules ) {
			return null;
		}

		$sources = $settings->detected()['sources'];
		$vars    = \array_values( \array_filter( \explode( ',', $sources['post_type_query_vars'] ?? '' ), static fn ( string $part ): bool => '' !== $part ) );
		$verbose = isset( $sources['verbose_page_rules'] ) && '1' === $sources['verbose_page_rules'];

		return new LooseMatch( $rules, $verbose, $vars );
	}

	/**
	 * How many shortcuts are enabled.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  int
	 */
	public function count(): int {
		return \count( $this->shortcuts );
	}

	// endregion
}
