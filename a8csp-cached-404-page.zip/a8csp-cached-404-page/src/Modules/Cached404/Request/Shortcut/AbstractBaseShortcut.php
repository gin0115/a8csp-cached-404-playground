<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Request\Shortcut;

use A8C\SpecialProjects\A8cspCached404Page\Request\ShortcutResult;

\defined( 'ABSPATH' ) || exit;

/**
 * Shared matching for URL types shaped `/<base>/<slug>/`: term archives, single items of a post
 * type with a base, and author archives. Feeds are always left to WordPress: `WP::handle_404()`
 * answers a feed for a missing item with an empty feed, not a 404.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
abstract class AbstractBaseShortcut implements ShortcutInterface {
	// region FIELDS AND CONSTANTS

	/**
	 * A feed ending, which WordPress answers with an empty feed instead of a 404.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	private const string FEED_ENDING = '#/(?:feed|rdf|rss|rss2|atom)/$#';

	/**
	 * Slugs WordPress uses as path words, such as `/base/page/2/` for an archive's second page.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	private const string RESERVED_SLUG = '/^(?:page|feed|embed|trackback|attachment|comment-page-[0-9]+)$/';

	// endregion

	// region CONSTRUCTORS

	/**
	 * AbstractBaseShortcut constructor.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $key          The shortcut key.
	 * @param   string $base         The URL base, without slashes.
	 * @param   bool   $hierarchical Whether items nest in the URL.
	 */
	public function __construct(
		private readonly string $key,
		private readonly string $base,
		private readonly bool $hierarchical,
	) {}

	// endregion

	// region METHODS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function key(): string {
		return $this->key;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function check( string $path ): ShortcutResult {
		$slug = $this->slug( $path );
		if ( null === $slug ) {
			return ShortcutResult::NotMine;
		}

		return $this->exists( $slug ) ? ShortcutResult::Exists : ShortcutResult::Missing;
	}

	// endregion

	// region HELPERS

	/**
	 * The optional endings WordPress answers with a 404 when the item is missing, as a regex part.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  string
	 */
	abstract protected function endings(): string;

	/**
	 * Whether the item with this lower-cased slug exists, or might, so WordPress should answer.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $slug The slug.
	 *
	 * @return  bool
	 */
	abstract protected function exists( string $slug ): bool;

	/**
	 * The lower-cased slug from the path, or null when the path is not this URL type's, the slug
	 * holds anything but letters, digits and hyphens (including percent-encoded octets), or it is a
	 * reserved path word.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $path The request path.
	 *
	 * @return  string|null
	 */
	protected function slug( string $path ): ?string {
		if ( '' === $this->base || 1 === \preg_match( self::FEED_ENDING, $path ) ) {
			return null;
		}

		$items   = $this->hierarchical ? '((?:[^/]+/)+?)' : '([^/]+/)';
		$pattern = '#^/' . \preg_quote( $this->base, '#' ) . '/' . $items . $this->endings() . '$#';
		if ( 1 !== \preg_match( $pattern, $path, $matches ) ) {
			return null;
		}

		$parts = \explode( '/', \trim( $matches[1], '/' ) );
		foreach ( $parts as $part ) {
			if ( 1 !== \preg_match( '/^[A-Za-z0-9-]+$/', $part ) ) {
				return null;
			}
		}

		$slug = \strtolower( $parts[ \count( $parts ) - 1 ] );

		return 1 === \preg_match( self::RESERVED_SLUG, $slug ) ? null : $slug;
	}

	// endregion
}
