<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Request\Shortcut;

\defined( 'ABSPATH' ) || exit;

/**
 * A URL type for single items, such as posts or a post type's items, whose paths can carry one
 * made-up segment after the item (see `ExtraSegment`).
 *
 * @since   1.0.0
 * @version 1.0.0
 */
interface SingleItemShortcut extends ShortcutInterface {
	// region METHODS

	/**
	 * Whether the path has this URL type's single-item shape, without looking the item up.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $path The request path.
	 *
	 * @return  bool
	 */
	public function matches( string $path ): bool;

	// endregion
}
