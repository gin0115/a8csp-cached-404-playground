<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Request;

\defined( 'ABSPATH' ) || exit;

/**
 * Sends the light 404 and stops.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class Responder {
	// region FIELDS AND CONSTANTS

	/**
	 * The response header naming the shortcut that answered.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string HEADER = 'X-A8CSP-404';

	/**
	 * The body sent when no stored page exists.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string PLAIN_HTML = '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Not Found</title></head><body><h1>Not Found</h1></body></html>';

	// endregion

	// region METHODS

	/**
	 * Sends the 404 status, headers and body, then exits.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $key       The shortcut key that answered.
	 * @param   string $page_file Absolute path of the stored page, or ''.
	 *
	 * @return  never
	 */
	public static function send( string $key, string $page_file ): never {
		status_header( 404 );
		nocache_headers();
		\header( 'Content-Type: text/html; charset=utf-8' );
		\header( self::HEADER . ': ' . $key );

		if ( '' !== $page_file && \is_readable( $page_file ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile -- Streams the stored page; WP_Filesystem is not loaded this early.
			\readfile( $page_file );
		} else {
			echo self::PLAIN_HTML; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup.
		}

		exit;
	}

	// endregion
}
