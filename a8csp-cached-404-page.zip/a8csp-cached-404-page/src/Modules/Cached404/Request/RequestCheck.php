<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Request;

use A8C\SpecialProjects\A8cspCached404Page\Request\Prefix\PathPrefixCollection;
use A8C\SpecialProjects\A8cspCached404Page\Request\Shortcut\ShortcutCollection;

\defined( 'ABSPATH' ) || exit;

/**
 * Decides whether a request is for a missing item. Sends nothing itself.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class RequestCheck {
	// region CONSTRUCTORS

	/**
	 * RequestCheck constructor.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   ShortcutCollection   $shortcuts The enabled shortcuts.
	 * @param   PathPrefixCollection $prefixes  The path steps run before the shortcuts.
	 */
	public function __construct(
		private readonly ShortcutCollection $shortcuts,
		private readonly PathPrefixCollection $prefixes = new PathPrefixCollection( array() ),
	) {}

	// endregion

	// region METHODS

	/**
	 * The key of the shortcut that found the requested item missing, or null to leave the request
	 * to WordPress. Only GET and HEAD requests are checked.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $method The request method.
	 * @param   string $uri    The request URI, query string included.
	 *
	 * @return  string|null
	 */
	public function check( string $method, string $uri ): ?string {
		if ( 'GET' !== $method && 'HEAD' !== $method ) {
			return null;
		}

		$path = wp_parse_url( $uri, PHP_URL_PATH );
		if ( ! \is_string( $path ) || '' === $path ) {
			return null;
		}

		// A feed or a search changes what WordPress sends, even for a missing item.
		$query = wp_parse_url( $uri, PHP_URL_QUERY );
		if ( \is_string( $query ) && '' !== $query ) {
			\parse_str( $query, $vars );
			if ( isset( $vars['feed'] ) || isset( $vars['s'] ) ) {
				return null;
			}
		}

		// With or without the trailing slash is the same URL, so excluded paths and folders match either way.
		$path = \str_ends_with( $path, '/' ) ? $path : $path . '/';
		$path = $this->prefixes->apply( $path );

		return null === $path ? null : $this->shortcuts->first_missing( $path );
	}

	// endregion
}
