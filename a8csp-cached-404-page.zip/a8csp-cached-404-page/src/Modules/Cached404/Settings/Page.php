<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Settings;

use A8C\SpecialProjects\A8cspCached404Page\Page\Capture;
use A8C\SpecialProjects\A8cspCached404Page\Page\Component as PageComponent;
use A8C\SpecialProjects\A8cspCached404Page\Page\PageStore;
use A8C\SpecialProjects\A8cspCached404Page\Page\ScriptList;
use A8C\SpecialProjects\A8cspCached404Page\Page\StyleList;
use A8C\SpecialProjects\A8cspCached404Page\Request\Shortcut\Post;

\defined( 'ABSPATH' ) || exit;

/**
 * Renders Settings → Cached 404: the on/off switch, then the 404 page and What to answer boxes,
 * each saved on its own by `cached-404-settings.js`.
 *
 * @since   1.0.0
 * @version 1.0.0
 *
 * @phpstan-import-type ShortcutData from Settings
 */
final class Page {
	// region METHODS

	/**
	 * Prints the page.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The settings, with the site's current URL types detected.
	 *
	 * @return  void
	 */
	public function render( Settings $settings ): void {
		echo '<div class="wrap a8csp-cached-404-settings">';
		echo '<h1>' . esc_html__( 'Cached 404', 'a8csp-cached-404-page' ) . '</h1>';
		echo '<p class="a8csp-cached-404-intro">' . esc_html__( 'Answers requests for missing archives and items with a static 404 page, before plugins and the theme load. Anything it isn\'t sure about goes to WordPress.', 'a8csp-cached-404-page' ) . '</p>';

		$this->status_box( $settings );
		$this->page_box( $settings );
		$this->answer_box( $settings );

		echo '</div>';
	}

	/**
	 * What the saved settings do now: `on`, `off` or `idle`, the badge text and a sentence.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The saved settings.
	 *
	 * @return  array{state: string, label: string, text: string}
	 */
	public static function status( Settings $settings ): array {
		$types = \count( \array_filter( $settings->shortcuts(), static fn ( array $shortcut ): bool => $shortcut['enabled'] ) );
		$langs = \count( \array_filter( $settings->prefixes(), static fn ( array $prefix ): bool => $prefix['enabled'] ) );

		if ( ! $settings->is_enabled() ) {
			return array(
				'state' => 'off',
				'label' => __( 'Off', 'a8csp-cached-404-page' ),
				'text'  => __( 'Off. Every request goes to WordPress as normal.', 'a8csp-cached-404-page' ),
			);
		}

		if ( 0 === $types && ! $settings->loose() ) {
			return array(
				'state' => 'idle',
				'label' => __( 'Idle', 'a8csp-cached-404-page' ),
				'text'  => __( 'On, but nothing is ticked under What to answer, so nothing is answered yet.', 'a8csp-cached-404-page' ),
			);
		}

		/* translators: %d: number of ticked URL types */
		$text = \sprintf( _n( 'Answering %d URL type', 'Answering %d URL types', $types, 'a8csp-cached-404-page' ), $types );
		if ( $settings->loose() ) {
			$text .= __( ', plus loose mode', 'a8csp-cached-404-page' );
		}
		if ( 0 < $langs ) {
			$text .= __( ', also inside language folders', 'a8csp-cached-404-page' );
		}

		return array(
			'state' => 'on',
			'label' => __( 'On', 'a8csp-cached-404-page' ),
			'text'  => $text . '.',
		);
	}

	/**
	 * What the last capture loaded, such as "Captured 21 Oct 2026, 1:54 am · 25 stylesheets, 1 script".
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  string
	 */
	public static function recorded(): string {
		$styles  = \count( StyleList::load() );
		$scripts = ScriptList::load();
		$scripts = \count( $scripts['scripts'] ) + \count( \array_filter( $scripts['modules'], static fn ( array $module ): bool => $module['enqueued'] ) );
		if ( 0 === $styles && 0 === $scripts ) {
			return __( 'Not created yet.', 'a8csp-cached-404-page' );
		}

		$summary = \sprintf(
			/* translators: 1: number of stylesheets, such as "25 stylesheets", 2: number of scripts, such as "1 script" */
			__( '%1$s, %2$s', 'a8csp-cached-404-page' ),
			/* translators: %d: number of stylesheets */
			\sprintf( _n( '%d stylesheet', '%d stylesheets', $styles, 'a8csp-cached-404-page' ), $styles ),
			/* translators: %d: number of scripts */
			\sprintf( _n( '%d script', '%d scripts', $scripts, 'a8csp-cached-404-page' ), $scripts )
		);

		$at = get_option( Capture::RECORDED_AT_OPTION );
		if ( ! \is_numeric( $at ) || 0 >= (int) $at ) {
			return $summary;
		}

		/* translators: 1: date and time, 2: what was loaded */
		return \sprintf( __( 'Captured %1$s · %2$s', 'a8csp-cached-404-page' ), wp_date( get_option( 'date_format' ) . ', ' . get_option( 'time_format' ), (int) $at ), $summary );
	}

	// endregion

	// region HELPERS

	/**
	 * The on/off switch, what it currently does, and a badge.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The settings.
	 *
	 * @return  void
	 */
	private function status_box( Settings $settings ): void {
		$status = self::status( $settings );

		echo '<section class="a8csp-cached-404-card a8csp-cached-404-status" aria-labelledby="a8csp-cached-404-status-title" data-a8csp-cached-404-save="status">';
		echo '<div class="a8csp-cached-404-status-main">';
		echo '<label class="a8csp-cached-404-switch"><input type="checkbox" role="switch" name="' . esc_attr( Form::FIELD . '[enabled]' ) . '" value="1" aria-labelledby="a8csp-cached-404-status-title" aria-describedby="a8csp-cached-404-status-text"' . checked( $settings->is_enabled(), true, false ) . ' /><span aria-hidden="true"></span></label>';
		echo '<div><h2 id="a8csp-cached-404-status-title">' . esc_html__( 'Answer missing URLs early', 'a8csp-cached-404-page' ) . '</h2>';
		echo '<p id="a8csp-cached-404-status-text" class="a8csp-cached-404-status-text" data-a8csp-cached-404-status="text">' . esc_html( $status['text'] ) . '</p></div>';
		echo '</div>';
		echo '<div class="a8csp-cached-404-status-side">';
		$this->note( '', '' );
		echo '<span class="a8csp-cached-404-pill is-' . esc_attr( $status['state'] ) . '" data-a8csp-cached-404-status="pill"><span aria-hidden="true"></span><span data-a8csp-cached-404-status="label">' . esc_html( $status['label'] ) . '</span></span>';
		echo '</div>';
		echo '</section>';
	}

	/**
	 * Which page is sent for missing items, as three cards, and a filter that overrules the choice.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The settings.
	 *
	 * @return  void
	 */
	private function page_box( Settings $settings ): void {
		$filtered = PageStore::filtered_file();
		$uploaded = PageStore::uploaded_file();
		$has_file = '' !== $uploaded && \is_readable( $uploaded );
		$captured = '' !== Capture::html();
		$name     = Form::FIELD . '[page_source]';
		$shown    = '' !== $uploaded ? \ltrim( \str_replace( wp_normalize_path( ABSPATH ), '', wp_normalize_path( $uploaded ) ), '/' ) : 'wp-content/uploads/' . PageStore::UPLOADED_FILE;

		echo '<section class="a8csp-cached-404-card" aria-labelledby="a8csp-cached-404-page-title" data-a8csp-cached-404-save="page">';
		echo '<h2 id="a8csp-cached-404-page-title">' . esc_html__( 'The 404 page sent', 'a8csp-cached-404-page' ) . '</h2>';

		if ( null !== $filtered ) {
			echo '<div class="notice notice-info inline"><p>';
			/* translators: 1: filter name, 2: file path */
			\printf( esc_html__( 'Set by the %1$s filter: %2$s. This overrules the choice below.', 'a8csp-cached-404-page' ), '<code>' . esc_html( PageStore::FILTER ) . '</code>', '<code>' . esc_html( $filtered ) . '</code>' );
			if ( ! \is_readable( $filtered ) ) {
				echo ' ' . esc_html__( 'That file is not found, so the plain "Not Found" page is sent.', 'a8csp-cached-404-page' );
			}
			echo '</p></div>';
		}

		echo '<div class="a8csp-cached-404-page-layout">';

		// The page in use, loaded from the preview link and scaled down to fit; there is no screenshot.
		// Sandboxed so its scripts, such as analytics, do not run in wp-admin.
		echo '<div class="a8csp-cached-404-preview">';
		echo '<div class="a8csp-cached-404-preview-frame"><iframe src="' . esc_url( PageComponent::preview_url() ) . '" title="' . esc_attr__( 'The 404 page sent, scaled down', 'a8csp-cached-404-page' ) . '" sandbox="allow-same-origin" tabindex="-1" loading="lazy" data-a8csp-cached-404-preview></iframe></div>';
		echo '<a href="' . esc_url( PageComponent::preview_url() ) . '" target="_blank" rel="noopener">' . esc_html__( 'Open full page', 'a8csp-cached-404-page' ) . ' <span class="dashicons dashicons-external" aria-hidden="true"></span><span class="screen-reader-text">' . esc_html__( '(opens in a new tab)', 'a8csp-cached-404-page' ) . '</span></a>';
		echo '</div>';

		echo '<fieldset class="a8csp-cached-404-options"><legend class="screen-reader-text">' . esc_html__( 'Which page to send', 'a8csp-cached-404-page' ) . '</legend>';

		echo '<div class="a8csp-cached-404-option a8csp-cached-404-capture" id="a8csp-cached-404-capture">';
		echo '<label><input type="radio" name="' . esc_attr( $name ) . '" value="captured"' . checked( $settings->page_source(), 'captured', false ) . ' /><span>';
		echo '<span class="a8csp-cached-404-option-title">' . esc_html__( 'Captured from your theme', 'a8csp-cached-404-page' ) . '</span>';
		echo '<span class="a8csp-cached-404-option-text" data-a8csp-cached-404-capture="summary">' . esc_html( self::recorded() ) . '</span>';
		echo '</span></label>';
		echo '<div class="a8csp-cached-404-option-more"><button type="button" class="button" data-a8csp-cached-404-capture="start">' . esc_html( $captured ? __( 'Recapture…', 'a8csp-cached-404-page' ) : __( 'Create the 404 page', 'a8csp-cached-404-page' ) ) . '</button></div>';
		$this->dialog( $captured );
		echo '</div>';

		echo '<div class="a8csp-cached-404-option">';
		echo '<label><input type="radio" name="' . esc_attr( $name ) . '" value="file"' . checked( $settings->page_source(), 'file', false ) . disabled( $has_file, false, false ) . ' /><span>';
		echo '<span class="a8csp-cached-404-option-title">' . esc_html__( 'Your own HTML page', 'a8csp-cached-404-page' ) . '</span>';
		if ( $has_file ) {
			$changed = \filemtime( $uploaded );
			echo '<span class="a8csp-cached-404-option-text"><code>' . esc_html( $shown ) . '</code>';
			if ( false !== $changed ) {
				/* translators: %s: date the file changed */
				echo ' · ' . esc_html( \sprintf( __( 'changed %s', 'a8csp-cached-404-page' ), wp_date( (string) get_option( 'date_format' ), $changed ) ) );
			}
			echo '</span>';
			echo '<span class="a8csp-cached-404-option-text">' . esc_html__( 'To change it, replace that file on the server. It\'s sent exactly as it is.', 'a8csp-cached-404-page' ) . '</span>';
		} else {
			echo '<span class="a8csp-cached-404-option-text">' . esc_html__( 'A complete HTML page you design yourself. Not set up yet.', 'a8csp-cached-404-page' ) . '</span>';
		}
		echo '</span></label>';
		if ( ! $has_file ) {
			echo '<ol class="a8csp-cached-404-option-more">';
			echo '<li>' . esc_html__( 'Write a full HTML document. It\'s sent exactly as it is, so link stylesheets, scripts and images by full URL, not relative paths.', 'a8csp-cached-404-page' ) . '</li>';
			/* translators: %s: file path */
			echo '<li>' . \sprintf( esc_html__( 'Put it on the server at %s by SFTP or SSH.', 'a8csp-cached-404-page' ), '<code>' . esc_html( $shown ) . '</code>' ) . '</li>';
			echo '<li>' . esc_html__( 'Reload this page, choose this option and save.', 'a8csp-cached-404-page' ) . '</li>';
			echo '</ol>';
		}
		echo '</div>';

		echo '<div class="a8csp-cached-404-option">';
		echo '<label><input type="radio" name="' . esc_attr( $name ) . '" value="plain"' . checked( $settings->page_source(), 'plain', false ) . ' /><span>';
		echo '<span class="a8csp-cached-404-option-title">' . esc_html__( 'Plain "Not Found" text', 'a8csp-cached-404-page' ) . '</span>';
		echo '<span class="a8csp-cached-404-option-text">' . esc_html__( 'No styling. Also sent whenever the chosen page can\'t be read.', 'a8csp-cached-404-page' ) . '</span>';
		echo '</span></label>';
		echo '</div>';

		echo '</fieldset>';
		echo '</div>';

		$this->save_bar( __( 'Save changes to the 404 page', 'a8csp-cached-404-page' ), __( 'Unsaved changes', 'a8csp-cached-404-page' ) );
		echo '</section>';
	}

	/**
	 * The capture dialog: record, choose what to keep, create. `cached-404-capture.js` moves between the steps.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   bool $captured Whether a capture exists already.
	 *
	 * @return  void
	 */
	private function dialog( bool $captured ): void {
		$part = static fn ( string $name ): string => ' data-a8csp-cached-404-capture="' . esc_attr( $name ) . '"';

		echo '<dialog class="a8csp-cached-404-dialog" aria-labelledby="a8csp-cached-404-dialog-title"' . $part( 'dialog' ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $part() escapes.

		echo '<div class="a8csp-cached-404-dialog-head">';
		echo '<h2 id="a8csp-cached-404-dialog-title"' . $part( 'title' ) . '>' . esc_html( $captured ? __( 'Recapture the 404 page', 'a8csp-cached-404-page' ) : __( 'Create the 404 page', 'a8csp-cached-404-page' ) ) . '</h2>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $part() escapes.
		echo '<button type="button" class="a8csp-cached-404-dialog-close"' . $part( 'close' ) . '><span class="dashicons dashicons-no-alt" aria-hidden="true"></span><span class="screen-reader-text">' . esc_html__( 'Close', 'a8csp-cached-404-page' ) . '</span></button>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $part() escapes.
		echo '</div>';

		echo '<ol class="a8csp-cached-404-steps">';
		$number = 0;
		foreach ( array(
			'record' => __( 'Record', 'a8csp-cached-404-page' ),
			'choose' => __( 'Choose what to keep', 'a8csp-cached-404-page' ),
			'create' => __( 'Create', 'a8csp-cached-404-page' ),
		) as $step => $label ) {
			++$number;
			echo '<li data-a8csp-cached-404-step="' . esc_attr( $step ) . '"><button type="button" class="a8csp-cached-404-step" disabled><span class="a8csp-cached-404-step-number" data-number="' . esc_attr( (string) $number ) . '">' . esc_html( (string) $number ) . '</span>' . esc_html( $label ) . '</button></li>';
		}
		echo '</ol>';

		echo '<p class="a8csp-cached-404-capture-status" role="alert"' . $part( 'status' ) . '></p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $part() escapes.

		echo '<div class="a8csp-cached-404-dialog-step" data-a8csp-cached-404-panel="record">';
		echo '<div class="a8csp-cached-404-dialog-body">';
		echo '<p>' . esc_html__( 'Loading your site\'s 404 out of sight, logged out, and recording the stylesheets and scripts it loads.', 'a8csp-cached-404-page' ) . '</p>';
		echo '<div class="a8csp-cached-404-progress" role="progressbar" aria-label="' . esc_attr__( 'Recording', 'a8csp-cached-404-page' ) . '" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"' . $part( 'progress' ) . '><span></span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $part() escapes.
		echo '<p class="description">' . esc_html__( 'About 5 seconds.', 'a8csp-cached-404-page' ) . '</p>';
		echo '</div>';
		echo '<div class="a8csp-cached-404-dialog-foot"><span></span><div class="a8csp-cached-404-dialog-actions">';
		echo '<button type="button" class="button"' . $part( 'close' ) . '>' . esc_html__( 'Cancel', 'a8csp-cached-404-page' ) . '</button>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $part() escapes.
		echo '</div></div>';
		echo '</div>';

		echo '<div class="a8csp-cached-404-dialog-step" data-a8csp-cached-404-panel="choose" hidden>';
		echo '<div class="a8csp-cached-404-dialog-body a8csp-cached-404-dialog-lists"' . $part( 'lists' ) . '></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $part() escapes.
		echo '<div class="a8csp-cached-404-dialog-foot"><p class="description">' . esc_html__( 'Creating saves straight away and makes this the 404 page in use.', 'a8csp-cached-404-page' ) . '</p><div class="a8csp-cached-404-dialog-actions">';
		echo '<button type="button" class="button"' . $part( 'back' ) . '>' . esc_html__( 'Back', 'a8csp-cached-404-page' ) . '</button>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $part() escapes.
		echo '<button type="button" class="button"' . $part( 'close' ) . '>' . esc_html__( 'Cancel', 'a8csp-cached-404-page' ) . '</button>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $part() escapes.
		echo '<button type="button" class="button button-primary"' . $part( 'build' ) . '>' . esc_html__( 'Create 404 page', 'a8csp-cached-404-page' ) . '</button>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $part() escapes.
		echo '</div></div>';
		echo '</div>';

		echo '<div class="a8csp-cached-404-dialog-step" data-a8csp-cached-404-panel="create" hidden>';
		echo '<div class="a8csp-cached-404-dialog-body">';
		echo '<p class="a8csp-cached-404-building"' . $part( 'building' ) . '>' . esc_html__( 'Creating the 404 page…', 'a8csp-cached-404-page' ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $part() escapes.
		echo '<div class="a8csp-cached-404-done"' . $part( 'done' ) . ' hidden><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $part() escapes.
		echo '<p class="a8csp-cached-404-done-title">' . esc_html__( 'The 404 page is created and in use.', 'a8csp-cached-404-page' ) . '</p>';
		echo '<p class="description"' . $part( 'kept' ) . '></p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $part() escapes.
		echo '</div></div>';
		echo '</div>';
		echo '<div class="a8csp-cached-404-dialog-foot"><span></span><div class="a8csp-cached-404-dialog-actions">';
		echo '<button type="button" class="button"' . $part( 'back' ) . '>' . esc_html__( 'Back', 'a8csp-cached-404-page' ) . '</button>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $part() escapes.
		echo '<a class="button" href="' . esc_url( PageComponent::preview_url() ) . '" target="_blank" rel="noopener"' . $part( 'open' ) . ' hidden>' . esc_html__( 'Open 404 page', 'a8csp-cached-404-page' ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $part() escapes.
		echo '<button type="button" class="button button-primary"' . $part( 'close' ) . '>' . esc_html__( 'Done', 'a8csp-cached-404-page' ) . '</button>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $part() escapes.
		echo '</div></div>';
		echo '</div>';

		echo '</dialog>';
	}

	/**
	 * The URL types to answer as ticked groups, the wider options, the paths never answered and lookups.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The settings.
	 *
	 * @return  void
	 */
	private function answer_box( Settings $settings ): void {
		echo '<section class="a8csp-cached-404-card" aria-labelledby="a8csp-cached-404-answer-title" data-a8csp-cached-404-save="answer">';
		echo '<h2 id="a8csp-cached-404-answer-title">' . esc_html__( 'What to answer', 'a8csp-cached-404-page' ) . '</h2>';
		echo '<p class="a8csp-cached-404-card-text">' . esc_html__( 'Missing URLs of the ticked types get the cached 404.', 'a8csp-cached-404-page' ) . '</p>';

		$labels = \array_count_values( \array_column( $settings->shortcuts(), 'label' ) );
		$lists  = array();
		foreach ( array(
			'archives' => array( __( 'Archives', 'a8csp-cached-404-page' ), array( 'taxonomy', 'author' ) ),
			'single'   => array( __( 'Single items', 'a8csp-cached-404-page' ), array( 'post', 'post_type' ) ),
		) as $list => list( $title, $types ) ) {
			$items = array();
			foreach ( $settings->shortcuts() as $key => $shortcut ) {
				if ( \in_array( $shortcut['type'], $types, true ) ) {
					// Two types can share a label, such as two plugins' "Products"; the type name tells them apart.
					$items[] = array(
						'field'   => Form::FIELD . '[shortcuts][' . $key . ']',
						'label'   => 1 < ( $labels[ $shortcut['label'] ] ?? 0 ) ? $shortcut['label'] . ' (' . $shortcut['name'] . ')' : $shortcut['label'],
						'detail'  => $this->example( $shortcut ),
						'checked' => $shortcut['enabled'],
					);
				}
			}

			if ( array() !== $items ) {
				$lists[ $list ] = array( $title, $items, '' );
			}
		}

		$languages = array();
		foreach ( $settings->prefixes() as $key => $prefix ) {
			$languages[] = array(
				'field'   => Form::FIELD . '[prefixes][' . $key . ']',
				'label'   => $prefix['label'],
				'detail'  => '/' . \implode( '/ /', $prefix['values'] ) . '/',
				'checked' => $prefix['enabled'],
			);
		}
		if ( array() !== $languages ) {
			$lists['languages'] = array( __( 'Language folders', 'a8csp-cached-404-page' ), $languages, __( 'Also answer the URL types above when they start with one of these folders.', 'a8csp-cached-404-page' ) );
		}

		if ( array() === $lists ) {
			echo '<p>' . esc_html__( 'Nothing on this site can be answered early.', 'a8csp-cached-404-page' ) . '</p>';
		}

		foreach ( $lists as list( $title, $items, $note ) ) {
			$this->group( $title, $items, $note );
		}

		list( $why_title, $why ) = $this->unavailable( $settings );
		if ( '' !== $why ) {
			echo '<details class="a8csp-cached-404-why"><summary>' . esc_html( $why_title ) . '</summary><p>' . esc_html( $why ) . '</p></details>';
		}

		echo '<div class="a8csp-cached-404-part">';
		echo '<h3>' . esc_html__( 'Wider matching', 'a8csp-cached-404-page' ) . '</h3>';
		if ( isset( $lists['single'] ) ) {
			$this->check(
				Form::FIELD . '[extra_segments]',
				$settings->extra_segments(),
				__( 'Made-up paths after a single item', 'a8csp-cached-404-page' ),
				'/product/anything/made-up/',
				__( 'Often used to get past page caches. Endpoints that plugins add to single items still go to WordPress.', 'a8csp-cached-404-page' )
			);
		}
		$this->check(
			Form::FIELD . '[loose]',
			$settings->loose(),
			__( 'Loose mode: any other missing address the saved rewrite rules recognise', 'a8csp-cached-404-page' ),
			'',
			__( 'Catches missing pages and attachments wherever they sit, such as /2015/04/old-post/image/. Redirect plugins route addresses in their own code and aren\'t seen this early: list their paths under Never answer.', 'a8csp-cached-404-page' )
		);
		echo '</div>';

		echo '<div class="a8csp-cached-404-part">';
		echo '<label class="a8csp-cached-404-part-title" for="a8csp-cached-404-excluded">' . esc_html__( 'Never answer', 'a8csp-cached-404-page' ) . '</label>';
		echo '<textarea id="a8csp-cached-404-excluded" class="code" rows="3" placeholder="' . esc_attr( "/go/\n/shop/legacy/" ) . '" name="' . esc_attr( Form::FIELD . '[excluded]' ) . '">' . esc_textarea( \implode( "\n", $settings->excluded() ) ) . '</textarea>';
		echo '<p class="description">' . esc_html__( 'One path per line. Requests starting with these always go to WordPress.', 'a8csp-cached-404-page' ) . '</p>';
		echo '</div>';

		echo '<div class="a8csp-cached-404-part">';
		echo '<h3>' . esc_html__( 'Lookups', 'a8csp-cached-404-page' ) . '</h3>';
		$this->check( Form::FIELD . '[cache_misses]', $settings->cache_misses(), __( 'Remember tags and categories that don\'t exist, for an hour', 'a8csp-cached-404-page' ), '', '' );
		echo '</div>';

		$this->save_bar( __( 'Save changes to what to answer', 'a8csp-cached-404-page' ), __( 'Unsaved changes. The status above shows what\'s live.', 'a8csp-cached-404-page' ) );
		echo '</section>';
	}

	/**
	 * One group of URL types: a title with a ticked count, tick all or none, and the checkboxes in a grid.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string                                                                   $title The group title.
	 * @param   list<array{field: string, label: string, detail: string, checked: bool}> $items The checkboxes.
	 * @param   string                                                                   $note  A line under the grid, or ''.
	 *
	 * @return  void
	 */
	private function group( string $title, array $items, string $note ): void {
		$ticked = \count( \array_filter( $items, static fn ( array $item ): bool => $item['checked'] ) );
		$all    = \count( $items ) === $ticked;

		echo '<fieldset class="a8csp-cached-404-types" data-a8csp-cached-404-group>';
		echo '<legend>' . esc_html( $title ) . ' <span class="a8csp-cached-404-group-count">';
		/* translators: 1: number ticked, 2: number in the group */
		\printf( esc_html__( '%1$s of %2$s', 'a8csp-cached-404-page' ), '<span class="a8csp-cached-404-group-ticked">' . esc_html( (string) $ticked ) . '</span>', esc_html( (string) \count( $items ) ) );
		echo '</span></legend>';
		echo '<div class="a8csp-cached-404-types-actions"><button type="button" class="button-link" data-a8csp-cached-404-tick="' . ( $all ? 'none' : 'all' ) . '" data-a8csp-cached-404-tick-all="' . esc_attr__( 'Tick all', 'a8csp-cached-404-page' ) . '" data-a8csp-cached-404-tick-none="' . esc_attr__( 'Untick all', 'a8csp-cached-404-page' ) . '">' . esc_html( $all ? __( 'Untick all', 'a8csp-cached-404-page' ) : __( 'Tick all', 'a8csp-cached-404-page' ) ) . '</button></div>';
		echo '<div class="a8csp-cached-404-grid">';
		foreach ( $items as $item ) {
			echo '<label class="a8csp-cached-404-item"><input type="checkbox" name="' . esc_attr( $item['field'] ) . '" value="1"' . checked( $item['checked'], true, false ) . ' />';
			echo '<span class="a8csp-cached-404-item-name">' . esc_html( $item['label'] ) . '</span>';
			echo '<span class="a8csp-cached-404-item-file">' . esc_html( $item['detail'] ) . '</span></label>';
		}
		echo '</div>';
		if ( '' !== $note ) {
			echo '<p class="description">' . esc_html( $note ) . '</p>';
		}
		echo '</fieldset>';
	}

	/**
	 * One checkbox with its label, an optional example path and an optional description.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $field   The field name.
	 * @param   bool   $checked Whether it is ticked.
	 * @param   string $label   The label.
	 * @param   string $example An example path, or ''.
	 * @param   string $text    The description, or ''.
	 *
	 * @return  void
	 */
	private function check( string $field, bool $checked, string $label, string $example, string $text ): void {
		echo '<label class="a8csp-cached-404-check"><input type="checkbox" name="' . esc_attr( $field ) . '" value="1"' . checked( $checked, true, false ) . ' /><span>';
		echo '<span class="a8csp-cached-404-check-label">' . esc_html( $label );
		if ( '' !== $example ) {
			echo ' <span class="a8csp-cached-404-check-example">' . esc_html( $example ) . '</span>';
		}
		echo '</span>';
		if ( '' !== $text ) {
			echo '<span class="a8csp-cached-404-check-text">' . esc_html( $text ) . '</span>';
		}
		echo '</span></label>';
	}

	/**
	 * A box's Save changes button and the note beside it.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $label The button's accessible name.
	 * @param   string $dirty The note shown while there are unsaved changes.
	 *
	 * @return  void
	 */
	private function save_bar( string $label, string $dirty ): void {
		echo '<div class="a8csp-cached-404-save-bar">';
		echo '<button type="button" class="button button-primary" aria-label="' . esc_attr( $label ) . '" data-a8csp-cached-404-save-button disabled>' . esc_html__( 'Save changes', 'a8csp-cached-404-page' ) . '</button>';
		$this->note( $dirty, '' );
		echo '</div>';
	}

	/**
	 * The note that shows "Unsaved changes", "Saved" or an error; `cached-404-settings.js` fills it.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $dirty The text for unsaved changes, or ''.
	 * @param   string $text  The starting text.
	 *
	 * @return  void
	 */
	private function note( string $dirty, string $text ): void {
		echo '<span class="a8csp-cached-404-note" role="status" data-a8csp-cached-404-note data-dirty="' . esc_attr( $dirty ) . '" data-saved="' . esc_attr__( 'Saved', 'a8csp-cached-404-page' ) . '">' . esc_html( $text ) . '</span>';
	}

	/**
	 * An example URL for a shortcut, such as `/tag/anything/`.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   ShortcutData $shortcut The shortcut.
	 *
	 * @return  string
	 */
	private function example( array $shortcut ): string {
		if ( 'post' === $shortcut['type'] ) {
			return '/' . \str_replace(
				array( '%year%', '%monthnum%', '%day%', '%hour%', '%minute%', '%second%', '%postname%' ),
				array( '2024', '01', '31', '09', '30', '00', 'anything' ),
				$shortcut['base']
			) . '/';
		}

		return '/' . $shortcut['base'] . '/anything/';
	}

	/**
	 * Why some URLs are not listed, as a title and a plain sentence, or two ''.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The settings.
	 *
	 * @return  array{0: string, 1: string}
	 */
	private function unavailable( Settings $settings ): array {
		$structure = (string) get_option( 'permalink_structure', '' );
		if ( '' === $structure ) {
			return array(
				__( 'Why isn\'t anything listed?', 'a8csp-cached-404-page' ),
				__( 'This site uses plain permalinks (?p=123), so there are no URLs to check early.', 'a8csp-cached-404-page' ),
			);
		}

		$feeds = __( 'Feeds are never answered either: WordPress replies to a missing feed with an empty feed, not a 404.', 'a8csp-cached-404-page' );

		if ( ! isset( $settings->shortcuts()['post_type:post'] ) || null === Post::pattern( $structure ) ) {
			return array(
				__( 'Why aren\'t posts and pages listed?', 'a8csp-cached-404-page' ),
				\sprintf(
					/* translators: %s: the permalink structure, such as /%postname%/ */
					__( 'With this site\'s permalinks (%s), posts and pages sit at the top level, where a missing one can\'t be told apart from another plugin\'s URL this early.', 'a8csp-cached-404-page' ),
					$structure
				) . ' ' . $feeds,
			);
		}

		return array(
			__( 'Why aren\'t pages listed?', 'a8csp-cached-404-page' ),
			__( 'Pages sit at the top level, where a missing page can\'t be told apart from another plugin\'s URL this early.', 'a8csp-cached-404-page' ) . ' ' . $feeds,
		);
	}

	// endregion
}
