<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Settings;

use A8C\SpecialProjects\A8cspCached404Page\Page\Capture;
use A8C\SpecialProjects\A8cspCached404Page\Page\Component as PageComponent;
use A8C\SpecialProjects\A8cspCached404Page\Page\PageStore;
use A8C\SpecialProjects\A8cspCached404Page\Page\ScriptList;
use A8C\SpecialProjects\A8cspCached404Page\Page\StyleList;
use A8C\SpecialProjects\A8cspCached404Page\Request\Shortcut\Post;

\defined( 'ABSPATH' ) || exit;

/**
 * Renders Settings → Cached 404: one form in boxes, one Save button.
 *
 * @since   1.0.0
 * @version 1.0.0
 *
 * @phpstan-import-type ShortcutData from Settings
 */
final class Page {
	// region METHODS

	/**
	 * Prints the page.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The settings, with the site's current URL types detected.
	 * @param   bool     $saved    Whether the form was just saved.
	 *
	 * @return  void
	 */
	public function render( Settings $settings, bool $saved ): void {
		echo '<div class="wrap a8csp-cached-404-settings">';
		echo '<h1>' . esc_html__( 'Cached 404', 'a8csp-cached-404-page' ) . '</h1>';

		if ( $saved ) {
			wp_admin_notice(
				__( 'Saved.', 'a8csp-cached-404-page' ),
				array(
					'type'        => 'success',
					'dismissible' => true,
				)
			);
		}

		echo '<p class="a8csp-cached-404-intro">' . esc_html__( 'Missing addresses of the ticked types are answered at once with a light 404 page, before plugins and the theme load. Anything else is left to WordPress.', 'a8csp-cached-404-page' ) . '</p>';

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( Component::SAVE_ACTION );
		echo '<input type="hidden" name="action" value="' . esc_attr( Component::SAVE_ACTION ) . '" />';

		$this->status( $settings );
		$this->page( $settings );
		$this->answer( $settings );
		$this->advanced( $settings );

		submit_button( __( 'Save changes', 'a8csp-cached-404-page' ) );

		echo '</form>';
		echo '</div>';
	}

	// endregion

	// region HELPERS

	/**
	 * The main on/off, with what it currently does underneath.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The settings.
	 *
	 * @return  void
	 */
	private function status( Settings $settings ): void {
		$on = \count( \array_filter( $settings->shortcuts(), static fn ( array $shortcut ): bool => $shortcut['enabled'] ) );

		if ( ! $settings->is_enabled() ) {
			$status = __( 'Off. Every request goes to WordPress as normal.', 'a8csp-cached-404-page' );
		} elseif ( 0 === $on && ! $settings->loose() ) {
			$status = __( 'On, but nothing is ticked below, so nothing is answered yet.', 'a8csp-cached-404-page' );
		} else {
			/* translators: %d: number of ticked URL types */
			$status = \sprintf( _n( 'On. Answering %d type of missing URL.', 'On. Answering %d types of missing URL.', $on, 'a8csp-cached-404-page' ), $on );
			if ( $settings->loose() ) {
				$status .= ' ' . __( 'Loose mode is on.', 'a8csp-cached-404-page' );
			}
		}

		$this->open( __( 'Status', 'a8csp-cached-404-page' ) );
		echo '<label><input type="checkbox" name="' . esc_attr( Form::FIELD . '[enabled]' ) . '" value="1"' . checked( $settings->is_enabled(), true, false ) . ' /> ' . esc_html__( 'Turned on', 'a8csp-cached-404-page' ) . '</label>';
		echo '<p class="description">' . esc_html( $status ) . '</p>';
		echo '</div>';
	}

	/**
	 * Which page is sent for missing items, and a filter that overrules the choice.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The settings.
	 *
	 * @return  void
	 */
	private function page( Settings $settings ): void {
		$filtered = PageStore::filtered_file();
		$uploaded = PageStore::uploaded_file();
		$has_file = '' !== $uploaded && \is_readable( $uploaded );
		$captured = '' !== Capture::html();
		$in_use   = '' !== $settings->page_file() && \is_readable( $settings->page_file() );
		$name     = Form::FIELD . '[page_source]';

		$this->open( __( '404 page', 'a8csp-cached-404-page' ) );

		if ( null !== $filtered ) {
			echo '<div class="notice notice-info inline"><p>';
			/* translators: 1: filter name, 2: file path */
			\printf( esc_html__( 'Set by the %1$s filter: %2$s. This overrules the choice below.', 'a8csp-cached-404-page' ), '<code>' . esc_html( PageStore::FILTER ) . '</code>', '<code>' . esc_html( $filtered ) . '</code>' );
			if ( ! \is_readable( $filtered ) ) {
				echo ' ' . esc_html__( 'That file is not found, so the plain "Not Found" page is sent.', 'a8csp-cached-404-page' );
			}
			echo '</p></div>';
		}

		echo '<fieldset><legend class="screen-reader-text">' . esc_html__( '404 page', 'a8csp-cached-404-page' ) . '</legend>';

		echo '<div class="a8csp-cached-404-choice"><label><input type="radio" name="' . esc_attr( $name ) . '" value="captured"' . checked( $settings->page_source(), 'captured', false ) . ' /> ' . esc_html__( 'Your site\'s own 404, captured', 'a8csp-cached-404-page' ) . '</label>';
		if ( ! $captured ) {
			echo '<span class="description">' . esc_html__( 'Not created yet', 'a8csp-cached-404-page' ) . '</span>';
		}
		echo '</div>';

		echo '<div class="a8csp-cached-404-choice"><label><input type="radio" name="' . esc_attr( $name ) . '" value="file"' . checked( $settings->page_source(), 'file', false ) . disabled( $has_file, false, false ) . ' /> ' . esc_html__( 'Uploaded file', 'a8csp-cached-404-page' ) . '</label>';
		echo '<code>' . esc_html( '' !== $uploaded ? $uploaded : 'uploads/' . PageStore::UPLOADED_FILE ) . '</code>';
		if ( ! $has_file ) {
			echo '<span class="description">' . esc_html__( 'Not found', 'a8csp-cached-404-page' ) . '</span>';
		}
		echo '</div>';

		echo '<div class="a8csp-cached-404-choice"><label><input type="radio" name="' . esc_attr( $name ) . '" value="plain"' . checked( $settings->page_source(), 'plain', false ) . ' /> ' . esc_html__( 'Plain "Not Found"', 'a8csp-cached-404-page' ) . '</label></div>';
		echo '</fieldset>';

		echo '<div class="a8csp-cached-404-capture" id="a8csp-cached-404-capture">';
		echo '<p class="a8csp-cached-404-summary" data-a8csp-cached-404-capture="summary">' . esc_html( self::recorded() ) . '</p>';
		echo '<p class="a8csp-cached-404-choice"><button type="button" class="button button-primary" data-a8csp-cached-404-capture="start">' . esc_html( $captured ? __( 'Capture again', 'a8csp-cached-404-page' ) : __( 'Create the 404 page', 'a8csp-cached-404-page' ) ) . '</button>';
		echo '<a class="button" href="' . esc_url( PageComponent::preview_url() ) . '" target="_blank" rel="noopener" data-a8csp-cached-404-capture="view"' . ( $in_use ? '' : ' hidden' ) . '>' . esc_html__( 'View 404 page', 'a8csp-cached-404-page' ) . '</a></p>';
		echo '<p class="a8csp-cached-404-capture-status" data-a8csp-cached-404-capture="status" aria-live="polite"></p>';
		echo '<div data-a8csp-cached-404-capture="lists" hidden></div>';
		echo '<p data-a8csp-cached-404-capture="next" hidden><button type="button" class="button button-primary" data-a8csp-cached-404-capture="build">' . esc_html__( 'Next: create the page', 'a8csp-cached-404-page' ) . '</button></p>';
		echo '</div>';

		echo '<p class="description">' . esc_html__( 'Creating opens your site\'s own 404 in a new window for a few seconds, logged out, and records the stylesheets and scripts it loads. You then choose which to keep, and the page is saved to uploads. When the chosen page is missing, the plain "Not Found" page is sent.', 'a8csp-cached-404-page' ) . '</p>';
		echo '</div>';
	}

	/**
	 * The URL types to answer in tabs, the wider options, and what this site cannot answer.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The settings.
	 *
	 * @return  void
	 */
	private function answer( Settings $settings ): void {
		$this->open( __( 'What to answer', 'a8csp-cached-404-page' ) );

		$labels = \array_count_values( \array_column( $settings->shortcuts(), 'label' ) );
		$lists  = array();
		foreach ( array(
			'archives' => array( __( 'Archives', 'a8csp-cached-404-page' ), array( 'taxonomy', 'author' ) ),
			'single'   => array( __( 'Single items', 'a8csp-cached-404-page' ), array( 'post', 'post_type' ) ),
		) as $list => list( $title, $types ) ) {
			$items = array();
			foreach ( $settings->shortcuts() as $key => $shortcut ) {
				if ( \in_array( $shortcut['type'], $types, true ) ) {
					// Two types can share a label, such as two plugins' "Products"; the type name tells them apart.
					$items[] = array(
						'field'   => Form::FIELD . '[shortcuts][' . $key . ']',
						'label'   => 1 < ( $labels[ $shortcut['label'] ] ?? 0 ) ? $shortcut['label'] . ' (' . $shortcut['name'] . ')' : $shortcut['label'],
						'detail'  => $this->example( $shortcut ),
						'checked' => $shortcut['enabled'],
					);
				}
			}

			if ( array() !== $items ) {
				$lists[ $list ] = array( $title, $items );
			}
		}

		$languages = array();
		foreach ( $settings->prefixes() as $key => $prefix ) {
			$languages[] = array(
				'field'   => Form::FIELD . '[prefixes][' . $key . ']',
				'label'   => $prefix['label'],
				'detail'  => '/' . \implode( '/ /', $prefix['values'] ) . '/',
				'checked' => $prefix['enabled'],
			);
		}
		if ( array() !== $languages ) {
			$lists['languages'] = array( __( 'Language folders', 'a8csp-cached-404-page' ), $languages );
		}

		if ( array() === $lists ) {
			echo '<p>' . esc_html__( 'Nothing on this site can be answered early.', 'a8csp-cached-404-page' ) . '</p>';
		} else {
			$this->tabs( $lists );
		}

		echo '<h3>' . esc_html__( 'Also answer', 'a8csp-cached-404-page' ) . '</h3>';

		if ( isset( $lists['single'] ) ) {
			echo '<label><input type="checkbox" name="' . esc_attr( Form::FIELD . '[extra_segments]' ) . '" value="1"' . checked( $settings->extra_segments(), true, false ) . ' /> ';
			echo esc_html__( 'Made-up paths after a single item, such as /product/anything/made-up/', 'a8csp-cached-404-page' ) . '</label>';
			echo '<p class="description">' . esc_html__( 'Often used to get past page caches. Answered when no post or attachment has a name starting with the extra part; endpoints added for single items are left to WordPress.', 'a8csp-cached-404-page' ) . '</p>';
		}

		echo '<label><input type="checkbox" name="' . esc_attr( Form::FIELD . '[loose]' ) . '" value="1"' . checked( $settings->loose(), true, false ) . ' /> ';
		echo esc_html__( 'Loose mode: any other missing address, checked against the site\'s saved rewrite rules', 'a8csp-cached-404-page' ) . '</label>';
		echo '<p class="description">' . esc_html__( 'Answers missing pages, attachments and items wherever they sit, such as /2015/04/old-post/image/. Plugins that redirect or route addresses in their own code, such as redirect managers, are not seen this early: add their paths to Never answer.', 'a8csp-cached-404-page' ) . '</p>';

		$unavailable = $this->unavailable( $settings );
		if ( '' !== $unavailable ) {
			echo '<p class="description a8csp-cached-404-unavailable">' . esc_html( $unavailable ) . '</p>';
		}

		echo '</div>';
	}

	/**
	 * The lists as tabs, each showing how many are ticked, with the checkboxes in a grid.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   array<string, array{0: string, 1: list<array{field: string, label: string, detail: string, checked: bool}>}> $lists The lists, keyed by name.
	 *
	 * @return  void
	 */
	private function tabs( array $lists ): void {
		echo '<div class="a8csp-cached-404-tab-list" role="tablist">';
		$first = true;
		foreach ( $lists as $list => list( $title, $items ) ) {
			$ticked = \count( \array_filter( $items, static fn ( array $item ): bool => $item['checked'] ) );

			echo '<button type="button" role="tab" class="a8csp-cached-404-tab" id="' . esc_attr( 'a8csp-cached-404-tab-' . $list ) . '" aria-controls="' . esc_attr( 'a8csp-cached-404-panel-' . $list ) . '" aria-selected="' . ( $first ? 'true' : 'false' ) . '">';
			echo esc_html( $title ) . ' <span class="a8csp-cached-404-tab-count"><span data-a8csp-cached-404-count="' . esc_attr( $list ) . '">' . esc_html( (string) $ticked ) . '</span>/' . esc_html( (string) \count( $items ) ) . '</span>';
			echo '</button>';

			$first = false;
		}
		echo '</div>';

		$first = true;
		foreach ( $lists as $list => list( $title, $items ) ) {
			echo '<div role="tabpanel" class="a8csp-cached-404-panel" id="' . esc_attr( 'a8csp-cached-404-panel-' . $list ) . '" aria-labelledby="' . esc_attr( 'a8csp-cached-404-tab-' . $list ) . '" data-a8csp-cached-404-list="' . esc_attr( $list ) . '"' . ( $first ? '' : ' hidden' ) . '>';
			echo '<fieldset><legend class="screen-reader-text">' . esc_html( $title ) . '</legend><div class="a8csp-cached-404-grid">';
			foreach ( $items as $item ) {
				echo '<label class="a8csp-cached-404-item"><input type="checkbox" name="' . esc_attr( $item['field'] ) . '" value="1"' . checked( $item['checked'], true, false ) . ' />';
				echo '<span class="a8csp-cached-404-item-name">' . esc_html( $item['label'] ) . '</span>';
				echo '<span class="a8csp-cached-404-item-file">' . esc_html( $item['detail'] ) . '</span></label>';
			}
			echo '</div></fieldset>';

			if ( 'languages' === $list ) {
				echo '<p class="description">' . esc_html__( 'Also answer the URLs above when they start with one of these language folders.', 'a8csp-cached-404-page' ) . '</p>';
			}

			echo '</div>';
			$first = false;
		}
	}

	/**
	 * The paths that are never answered, and miss caching, collapsed unless paths are set.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The settings.
	 *
	 * @return  void
	 */
	private function advanced( Settings $settings ): void {
		echo '<details class="a8csp-cached-404-card a8csp-cached-404-advanced"' . ( array() !== $settings->excluded() ? ' open' : '' ) . '>';
		echo '<summary>' . esc_html__( 'Advanced: never answer, cache', 'a8csp-cached-404-page' ) . '</summary>';

		echo '<p><label for="a8csp-cached-404-excluded"><strong>' . esc_html__( 'Never answer', 'a8csp-cached-404-page' ) . '</strong></label></p>';
		echo '<textarea id="a8csp-cached-404-excluded" class="large-text code" rows="3" name="' . esc_attr( Form::FIELD . '[excluded]' ) . '">' . esc_textarea( \implode( "\n", $settings->excluded() ) ) . '</textarea>';
		echo '<p class="description">' . esc_html__( 'One path per line, for example /tag/keep-me/. Requests starting with these always go to WordPress.', 'a8csp-cached-404-page' ) . '</p>';

		echo '<p><label><input type="checkbox" name="' . esc_attr( Form::FIELD . '[cache_misses]' ) . '" value="1"' . checked( $settings->cache_misses(), true, false ) . ' /> ';
		echo esc_html__( 'Also remember tags and categories that do not exist, for an hour', 'a8csp-cached-404-page' ) . '</label></p>';
		echo '</details>';
	}

	/**
	 * Opens a box with its heading; the caller closes it.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $title The heading.
	 *
	 * @return  void
	 */
	private function open( string $title ): void {
		echo '<div class="a8csp-cached-404-card"><h2>' . esc_html( $title ) . '</h2>';
	}

	/**
	 * What the last capture loaded, such as "32 stylesheets (15 files, 17 inline only)", and when.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  string
	 */
	public static function recorded(): string {
		$styles  = StyleList::load();
		$scripts = ScriptList::load();
		$modules = \count( \array_filter( $scripts['modules'], static fn ( array $module ): bool => $module['enqueued'] ) );
		if ( array() === $styles && array() === $scripts['scripts'] && 0 === $modules ) {
			return __( 'Nothing captured yet.', 'a8csp-cached-404-page' );
		}

		$style_files  = \count( \array_filter( $styles, static fn ( array $style ): bool => '' !== $style['url'] ) );
		$script_files = \count( \array_filter( $scripts['scripts'], static fn ( array $script ): bool => '' !== $script['url'] ) );

		$summary = \sprintf(
			/* translators: 1: stylesheets, 2: stylesheet files, 3: inline-only stylesheets, 4: scripts, 5: script files, 6: inline-only scripts, 7: script modules */
			__( '%1$d stylesheets (%2$d files, %3$d inline only) and %4$d scripts (%5$d files, %6$d inline only, %7$d modules).', 'a8csp-cached-404-page' ),
			\count( $styles ),
			$style_files,
			\count( $styles ) - $style_files,
			\count( $scripts['scripts'] ) + $modules,
			$script_files,
			\count( $scripts['scripts'] ) - $script_files,
			$modules
		);

		$at = get_option( Capture::RECORDED_AT_OPTION );
		if ( ! \is_numeric( $at ) || 0 >= (int) $at ) {
			return $summary;
		}

		/* translators: 1: date and time, 2: what was loaded */
		return \sprintf( __( 'Last captured %1$s: %2$s', 'a8csp-cached-404-page' ), wp_date( get_option( 'date_format' ) . ', ' . get_option( 'time_format' ), (int) $at ), $summary );
	}

	/**
	 * An example URL for a shortcut, such as `/tag/anything/`.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   ShortcutData $shortcut The shortcut.
	 *
	 * @return  string
	 */
	private function example( array $shortcut ): string {
		if ( 'post' === $shortcut['type'] ) {
			return '/' . \str_replace(
				array( '%year%', '%monthnum%', '%day%', '%hour%', '%minute%', '%second%', '%postname%' ),
				array( '2024', '01', '31', '09', '30', '00', 'anything' ),
				$shortcut['base']
			) . '/';
		}

		return '/' . $shortcut['base'] . '/anything/';
	}

	/**
	 * A plain sentence naming what this site cannot answer early, or ''.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The settings.
	 *
	 * @return  string
	 */
	private function unavailable( Settings $settings ): string {
		$structure = (string) get_option( 'permalink_structure', '' );
		if ( '' === $structure ) {
			return __( 'This site uses plain permalinks (?p=123), so there are no URLs to check early.', 'a8csp-cached-404-page' );
		}

		$feeds = __( 'Feeds are never answered: WordPress replies to a missing feed with an empty feed, not a 404.', 'a8csp-cached-404-page' );

		if ( ! isset( $settings->shortcuts()['post_type:post'] ) || null === Post::pattern( $structure ) ) {
			return \sprintf(
				/* translators: %s: the permalink structure, such as /%postname%/ */
				__( 'Not available: posts and pages. With this site\'s permalinks (%s) they sit at the top level, where a missing item cannot be told apart from another plugin\'s URL this early.', 'a8csp-cached-404-page' ),
				$structure
			) . ' ' . $feeds;
		}

		return __( 'Not available: pages. They sit at the top level, where a missing page cannot be told apart from another plugin\'s URL this early.', 'a8csp-cached-404-page' ) . ' ' . $feeds;
	}

	// endregion
}
