<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Settings;

\defined( 'ABSPATH' ) || exit;

/**
 * Applies one box of the admin page's posted form to the settings. Each box saves on its own, so
 * each only touches its own values.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class Form {
	// region FIELDS AND CONSTANTS

	/**
	 * The posted field name everything sits under.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string FIELD = 'a8csp_cached_404';

	// endregion

	// region METHODS

	/**
	 * Returns the settings with the posted on/off switch applied.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The current settings.
	 * @param   mixed    $form     The value posted under `FIELD`.
	 *
	 * @return  Settings
	 */
	public static function apply_status( Settings $settings, mixed $form ): Settings {
		$form = \is_array( $form ) ? $form : array();

		return $settings->with_enabled( isset( $form['enabled'] ) );
	}

	/**
	 * Returns the settings with the posted page source applied.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The current settings.
	 * @param   mixed    $form     The value posted under `FIELD`.
	 *
	 * @return  Settings
	 */
	public static function apply_page( Settings $settings, mixed $form ): Settings {
		$form = \is_array( $form ) ? $form : array();

		// A disabled radio posts nothing, so the current source stays.
		if ( \is_string( $form['page_source'] ?? null ) ) {
			$settings = $settings->with_page_source( $form['page_source'] );
		}

		return $settings;
	}

	/**
	 * Returns the settings with the posted What to answer values applied. A box left unticked is off.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The current settings.
	 * @param   mixed    $form     The value posted under `FIELD`.
	 *
	 * @return  Settings
	 */
	public static function apply_answer( Settings $settings, mixed $form ): Settings {
		$form = \is_array( $form ) ? $form : array();

		$settings = $settings
			->with_cache_misses( isset( $form['cache_misses'] ) )
			->with_extra_segments( isset( $form['extra_segments'] ) )
			->with_loose( isset( $form['loose'] ) );

		$ticked = \is_array( $form['shortcuts'] ?? null ) ? \array_map( 'strval', \array_keys( $form['shortcuts'] ) ) : array();
		foreach ( \array_keys( $settings->shortcuts() ) as $key ) {
			$settings = $settings->with_shortcut_enabled( $key, \in_array( $key, $ticked, true ) );
		}

		$ticked = \is_array( $form['prefixes'] ?? null ) ? \array_map( 'strval', \array_keys( $form['prefixes'] ) ) : array();
		foreach ( \array_keys( $settings->prefixes() ) as $key ) {
			$settings = $settings->with_prefix_enabled( $key, \in_array( $key, $ticked, true ) );
		}

		$lines = \is_string( $form['excluded'] ?? null ) ? \preg_split( '/\R/', $form['excluded'] ) : array();

		return $settings->with_excluded( Settings::clean_paths( $lines ) );
	}

	// endregion
}
