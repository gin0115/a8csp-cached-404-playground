<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Settings;

use A8C\SpecialProjects\A8cspCached404Page\AbstractComponent;
use A8C\SpecialProjects\A8cspCached404Page\Detection\Detector;
use A8C\SpecialProjects\A8cspCached404Page\Page\Component as PageComponent;
use A8C\SpecialProjects\A8cspCached404Page\Page\PageStore;

\defined( 'ABSPATH' ) || exit;

/**
 * Composes the Settings feature: the Settings → Cached 404 page and its save callback.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class Component extends AbstractComponent {
	// region FIELDS AND CONSTANTS

	/**
	 * The admin page slug.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string PAGE = 'a8csp-cached-404';

	/**
	 * The `admin-post.php` action and nonce action for the form.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string SAVE_ACTION = 'a8csp_cached_404_save';

	/**
	 * The page's hook suffix, set once the page is added.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @var     string
	 */
	private string $hook_suffix = '';

	// endregion

	// region METHODS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function register_hooks(): void {
		add_action( 'admin_menu', array( $this, 'add_page' ) );
		add_action( 'admin_post_' . self::SAVE_ACTION, array( $this, 'save' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_styles' ) );
	}

	// endregion

	// region HOOKS

	/**
	 * Adds Settings → Cached 404.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function add_page(): void {
		$this->hook_suffix = (string) add_options_page(
			__( 'Cached 404', 'a8csp-cached-404-page' ),
			__( 'Cached 404', 'a8csp-cached-404-page' ),
			'manage_options',
			self::PAGE,
			array( $this, 'render_page' )
		);
	}

	/**
	 * Prints the admin page.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// The list always reflects the site as it is now; it is only stored when the form is saved.
		$settings = Settings::load();
		$detector = new Detector();
		if ( 0 === $settings->detected()['at'] || $detector->is_stale( $settings ) ) {
			$settings = $detector->detect( $settings );
		}

		( new Page() )->render( $settings, isset( $_GET['updated'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only shows the "Saved" notice.
	}

	/**
	 * Handles the form: re-runs detection, applies the posted values, rebuilds the stored page,
	 * then returns to the admin page.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  never
	 */
	public function save(): never {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to change these settings.', 'a8csp-cached-404-page' ), '', array( 'response' => 403 ) );
		}

		check_admin_referer( self::SAVE_ACTION );

		$settings = ( new Detector() )->detect( Settings::load() );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Form::apply() reads only booleans, known keys and cleaned paths.
		$settings = Form::apply( $settings, isset( $_POST[ Form::FIELD ] ) ? wp_unslash( $_POST[ Form::FIELD ] ) : array() );
		$settings = ( new PageStore() )->build( $settings );
		$settings->save();

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'    => self::PAGE,
					'updated' => '1',
				),
				admin_url( 'options-general.php' )
			)
		);
		exit;
	}

	/**
	 * Enqueues the settings styles and the tab script on the plugin's admin page.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $hook_suffix The current admin page's hook suffix.
	 *
	 * @return  void
	 */
	public function enqueue_admin_styles( string $hook_suffix ): void {
		if ( '' === $this->hook_suffix || $this->hook_suffix !== $hook_suffix ) {
			return;
		}

		$plugin_slug = a8csp_cached_404_get_plugin_slug();
		$base_url    = \constant( 'A8CSP_CACHED_404_DIR_URL' );

		$tabs = a8csp_cached_404_get_asset_meta( 'assets/js/build/cached-404-tabs.js' );
		if ( null !== $tabs ) {
			wp_enqueue_script( "$plugin_slug-tabs", $base_url . 'assets/js/build/cached-404-tabs.js', $tabs['dependencies'], $tabs['version'], array( 'in_footer' => true ) );
		}

		$capture = a8csp_cached_404_get_asset_meta( 'assets/js/build/cached-404-capture.js' );
		if ( null !== $capture ) {
			wp_enqueue_script( "$plugin_slug-capture", $base_url . 'assets/js/build/cached-404-capture.js', $capture['dependencies'], $capture['version'], array( 'in_footer' => true ) );
			wp_localize_script(
				"$plugin_slug-capture",
				'a8cspCached404Capture',
				array(
					'ajaxUrl' => admin_url( 'admin-ajax.php' ),
					'nonce'   => wp_create_nonce( PageComponent::AJAX_NONCE ),
					'actions' => array(
						'start' => PageComponent::START_ACTION,
						'lists' => PageComponent::LISTS_ACTION,
						'build' => PageComponent::BUILD_ACTION,
					),
					'text'    => array(
						'opening'   => __( 'Opening your 404 page in a new window…', 'a8csp-cached-404-page' ),
						'recording' => __( 'Recording the stylesheets and scripts it loads…', 'a8csp-cached-404-page' ),
						'building'  => __( 'Creating the 404 page…', 'a8csp-cached-404-page' ),
						'done'      => __( 'The 404 page is created and in use.', 'a8csp-cached-404-page' ),
						'again'     => __( 'Capture again', 'a8csp-cached-404-page' ),
						'blocked'   => __( 'The new window was blocked. Allow pop-ups for this site and try again.', 'a8csp-cached-404-page' ),
						'failed'    => __( 'Something went wrong. Try again.', 'a8csp-cached-404-page' ),
					),
				)
			);
		}

		$asset_meta = a8csp_cached_404_get_asset_meta( 'assets/css/build/cached-404-settings.css' );
		if ( \is_null( $asset_meta ) ) {
			return;
		}

		wp_enqueue_style( "$plugin_slug-settings", $base_url . 'assets/css/build/cached-404-settings.css', $asset_meta['dependencies'], $asset_meta['version'] );
		wp_style_add_data( "$plugin_slug-settings", 'rtl', 'replace' );
	}

	// endregion
}
