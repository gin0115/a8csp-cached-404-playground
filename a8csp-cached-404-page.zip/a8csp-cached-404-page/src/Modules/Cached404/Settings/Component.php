<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Settings;

use A8C\SpecialProjects\A8cspCached404Page\AbstractComponent;
use A8C\SpecialProjects\A8cspCached404Page\Detection\Detector;
use A8C\SpecialProjects\A8cspCached404Page\Page\Component as PageComponent;
use A8C\SpecialProjects\A8cspCached404Page\Page\PageStore;

\defined( 'ABSPATH' ) || exit;

/**
 * Composes the Settings feature: the Settings → Cached 404 page and its three AJAX saves.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class Component extends AbstractComponent {
	// region FIELDS AND CONSTANTS

	/**
	 * The admin page slug.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string PAGE = 'a8csp-cached-404';

	/**
	 * The AJAX action for the on/off switch.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string STATUS_ACTION = 'a8csp_cached_404_save_status';

	/**
	 * The AJAX action for the 404 page box.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string PAGE_ACTION = 'a8csp_cached_404_save_page';

	/**
	 * The AJAX action for the What to answer box.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string ANSWER_ACTION = 'a8csp_cached_404_save_answer';

	/**
	 * The nonce action shared by the three saves.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string AJAX_NONCE = 'a8csp_cached_404_settings';

	/**
	 * The page's hook suffix, set once the page is added.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @var     string
	 */
	private string $hook_suffix = '';

	// endregion

	// region METHODS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function register_hooks(): void {
		add_action( 'admin_menu', array( $this, 'add_page' ) );
		add_action( 'wp_ajax_' . self::STATUS_ACTION, array( $this, 'ajax_status' ) );
		add_action( 'wp_ajax_' . self::PAGE_ACTION, array( $this, 'ajax_page' ) );
		add_action( 'wp_ajax_' . self::ANSWER_ACTION, array( $this, 'ajax_answer' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_styles' ) );
	}

	// endregion

	// region HOOKS

	/**
	 * Adds Settings → Cached 404.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function add_page(): void {
		$this->hook_suffix = (string) add_options_page(
			__( 'Cached 404', 'a8csp-cached-404-page' ),
			__( 'Cached 404', 'a8csp-cached-404-page' ),
			'manage_options',
			self::PAGE,
			array( $this, 'render_page' )
		);
	}

	/**
	 * Prints the admin page.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// The list always reflects the site as it is now; it is only stored when a box is saved.
		$settings = Settings::load();
		$detector = new Detector();
		if ( 0 === $settings->detected()['at'] || $detector->is_stale( $settings ) ) {
			$settings = $detector->detect( $settings );
		}

		( new Page() )->render( $settings );
	}

	/**
	 * Saves the on/off switch.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function ajax_status(): void {
		self::save( Form::apply_status( ... ) );
	}

	/**
	 * Saves the 404 page box.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function ajax_page(): void {
		self::save( Form::apply_page( ... ) );
	}

	/**
	 * Saves the What to answer box.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function ajax_answer(): void {
		self::save( Form::apply_answer( ... ) );
	}

	/**
	 * Enqueues the settings styles and scripts on the plugin's admin page.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $hook_suffix The current admin page's hook suffix.
	 *
	 * @return  void
	 */
	public function enqueue_admin_styles( string $hook_suffix ): void {
		if ( '' === $this->hook_suffix || $this->hook_suffix !== $hook_suffix ) {
			return;
		}

		$plugin_slug = a8csp_cached_404_get_plugin_slug();
		$base_url    = \constant( 'A8CSP_CACHED_404_DIR_URL' );

		$tabs = a8csp_cached_404_get_asset_meta( 'assets/js/build/cached-404-tabs.js' );
		if ( null !== $tabs ) {
			wp_enqueue_script( "$plugin_slug-tabs", $base_url . 'assets/js/build/cached-404-tabs.js', $tabs['dependencies'], $tabs['version'], array( 'in_footer' => true ) );
		}

		$save = a8csp_cached_404_get_asset_meta( 'assets/js/build/cached-404-settings.js' );
		if ( null !== $save ) {
			wp_enqueue_script( "$plugin_slug-save", $base_url . 'assets/js/build/cached-404-settings.js', $save['dependencies'], $save['version'], array( 'in_footer' => true ) );
			wp_localize_script(
				"$plugin_slug-save",
				'a8cspCached404Settings',
				array(
					'ajaxUrl' => admin_url( 'admin-ajax.php' ),
					'nonce'   => wp_create_nonce( self::AJAX_NONCE ),
					'actions' => array(
						'status' => self::STATUS_ACTION,
						'page'   => self::PAGE_ACTION,
						'answer' => self::ANSWER_ACTION,
					),
					'text'    => array(
						'failed' => __( 'Not saved. Something went wrong, try again.', 'a8csp-cached-404-page' ),
					),
				)
			);
		}

		$capture = a8csp_cached_404_get_asset_meta( 'assets/js/build/cached-404-capture.js' );
		if ( null !== $capture ) {
			wp_enqueue_script( "$plugin_slug-capture", $base_url . 'assets/js/build/cached-404-capture.js', $capture['dependencies'], $capture['version'], array( 'in_footer' => true ) );
			wp_localize_script(
				"$plugin_slug-capture",
				'a8cspCached404Capture',
				array(
					'ajaxUrl' => admin_url( 'admin-ajax.php' ),
					'nonce'   => wp_create_nonce( PageComponent::AJAX_NONCE ),
					'actions' => array(
						'start' => PageComponent::START_ACTION,
						'lists' => PageComponent::LISTS_ACTION,
						'build' => PageComponent::BUILD_ACTION,
					),
					'text'    => array(
						'again'      => __( 'Recapture…', 'a8csp-cached-404-page' ),
						'titleAgain' => __( 'Recapture the 404 page', 'a8csp-cached-404-page' ),
						/* translators: 1: stylesheets kept, 2: stylesheets found, 3: scripts kept, 4: scripts found */
						'kept'       => __( 'Stylesheets kept: %1$s of %2$s. Scripts kept: %3$s of %4$s.', 'a8csp-cached-404-page' ),
						'failed'     => __( 'Something went wrong. Try again.', 'a8csp-cached-404-page' ),
					),
				)
			);
		}

		$asset_meta = a8csp_cached_404_get_asset_meta( 'assets/css/build/cached-404-settings.css' );
		if ( \is_null( $asset_meta ) ) {
			return;
		}

		wp_enqueue_style( "$plugin_slug-settings", $base_url . 'assets/css/build/cached-404-settings.css', $asset_meta['dependencies'], $asset_meta['version'] );
		wp_style_add_data( "$plugin_slug-settings", 'rtl', 'replace' );
	}

	// endregion

	// region HELPERS

	/**
	 * Re-runs detection, applies one box's posted values, rebuilds the stored page, saves, and
	 * answers with the new status.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   callable(Settings, mixed): Settings $apply The box's `Form` method.
	 *
	 * @return  void
	 */
	private static function save( callable $apply ): void {
		check_ajax_referer( self::AJAX_NONCE );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'You are not allowed to change these settings.', 'a8csp-cached-404-page' ) ), 403 );
		}

		$settings = ( new Detector() )->detect( Settings::load() );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Form reads only booleans, known keys and cleaned paths.
		$settings = $apply( $settings, isset( $_POST[ Form::FIELD ] ) ? wp_unslash( $_POST[ Form::FIELD ] ) : array() );
		$settings = ( new PageStore() )->build( $settings );
		$settings->save();

		wp_send_json_success( Page::status( $settings ) );
	}

	// endregion
}
