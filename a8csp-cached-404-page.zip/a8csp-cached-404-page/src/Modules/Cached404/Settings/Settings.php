<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Settings;

\defined( 'ABSPATH' ) || exit;

/**
 * Reads, cleans and writes the plugin's single option. Every change returns a new instance.
 *
 * @since   1.0.0
 * @version 1.0.0
 *
 * @phpstan-type ShortcutData array{type: string, name: string, base: string, hierarchical: bool, label: string, enabled: bool}
 * @phpstan-type PrefixData array{label: string, values: list<string>, enabled: bool}
 * @phpstan-type DetectedData array{at: int, sources: array<string, string>}
 * @phpstan-type StoredData array{enabled: bool, cache_misses: bool, extra_segments: bool, loose: bool, shortcuts: array<string, ShortcutData>, page_file: string, page_source: string, detected: DetectedData, site_path: string, prefixes: array<string, PrefixData>, excluded: list<string>}
 */
final class Settings {
	// region FIELDS AND CONSTANTS

	/**
	 * The option name.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string OPTION = 'a8csp_cached_404_settings';

	/**
	 * The shortcut types the option accepts.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @var     list<string>
	 */
	public const array SHORTCUT_TYPES = array( 'taxonomy', 'post_type', 'post', 'author' );

	/**
	 * Where the stored page comes from: the captured 404, the uploaded file, or plain "Not Found".
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @var     list<string>
	 */
	public const array PAGE_SOURCES = array( 'captured', 'file', 'plain' );

	/**
	 * What a path segment list may hold: letters, digits, `_`, `-` and `/`.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	private const string PATH_PATTERN = '#^[A-Za-z0-9_/-]+$#';

	// endregion

	// region CONSTRUCTORS

	/**
	 * Settings constructor. Use `load()` or `from_array()`.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   StoredData $data The cleaned settings.
	 */
	private function __construct( private readonly array $data ) {}

	// endregion

	// region METHODS

	/**
	 * Reads the stored option.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  self
	 */
	public static function load(): self {
		return self::from_array( get_option( self::OPTION, array() ) );
	}

	/**
	 * Builds settings from a raw value, dropping anything that does not fit.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   mixed $value The raw option value.
	 *
	 * @return  self
	 */
	public static function from_array( mixed $value ): self {
		$value = \is_array( $value ) ? $value : array();

		$shortcuts = array();
		foreach ( \is_array( $value['shortcuts'] ?? null ) ? $value['shortcuts'] : array() as $key => $shortcut ) {
			$shortcut = self::clean_shortcut( (string) $key, $shortcut );
			if ( null !== $shortcut ) {
				$shortcuts[ (string) $key ] = $shortcut;
			}
		}

		$prefixes = array();
		foreach ( \is_array( $value['prefixes'] ?? null ) ? $value['prefixes'] : array() as $key => $prefix ) {
			$prefix = self::clean_prefix( (string) $key, $prefix );
			if ( null !== $prefix ) {
				$prefixes[ (string) $key ] = $prefix;
			}
		}

		$site_path = \is_string( $value['site_path'] ?? null ) ? \trim( $value['site_path'], '/' ) : '';
		$source    = $value['page_source'] ?? null;

		return new self(
			array(
				'enabled'        => true === ( $value['enabled'] ?? false ),
				'cache_misses'   => true === ( $value['cache_misses'] ?? true ),
				'extra_segments' => true === ( $value['extra_segments'] ?? false ),
				'loose'          => true === ( $value['loose'] ?? false ),
				'shortcuts'      => $shortcuts,
				'page_file'      => \is_string( $value['page_file'] ?? null ) ? $value['page_file'] : '',
				'page_source'    => \is_string( $source ) && \in_array( $source, self::PAGE_SOURCES, true ) ? $source : 'captured',
				'detected'       => self::clean_detected( $value['detected'] ?? null ),
				'site_path'      => 1 === \preg_match( self::PATH_PATTERN, $site_path ) ? $site_path : '',
				'prefixes'       => $prefixes,
				'excluded'       => self::clean_paths( $value['excluded'] ?? null ),
			)
		);
	}

	/**
	 * Writes the settings to the autoloaded option.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function save(): void {
		update_option( self::OPTION, $this->to_array(), true );
	}

	/**
	 * The settings as stored.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  StoredData
	 */
	public function to_array(): array {
		return $this->data;
	}

	/**
	 * Main on/off.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  bool
	 */
	public function is_enabled(): bool {
		return $this->data['enabled'];
	}

	/**
	 * Whether missing slugs are cached as well as existing ones.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  bool
	 */
	public function cache_misses(): bool {
		return $this->data['cache_misses'];
	}

	/**
	 * Whether a made-up segment after a single item, such as `/product/<slug>/<anything>/`, is
	 * answered too.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  bool
	 */
	public function extra_segments(): bool {
		return $this->data['extra_segments'];
	}

	/**
	 * Whether loose mode is on: any other address is checked against the saved rewrite rules.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  bool
	 */
	public function loose(): bool {
		return $this->data['loose'];
	}

	/**
	 * All known shortcuts, keyed by shortcut key.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  array<string, ShortcutData>
	 */
	public function shortcuts(): array {
		return $this->data['shortcuts'];
	}

	/**
	 * Absolute path of the stored page, or '' when none is built.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  string
	 */
	public function page_file(): string {
		return $this->data['page_file'];
	}

	/**
	 * Where the stored page comes from: `captured`, `file` or `plain`.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  string
	 */
	public function page_source(): string {
		return $this->data['page_source'];
	}

	/**
	 * When detection last ran and the values it read.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  DetectedData
	 */
	public function detected(): array {
		return $this->data['detected'];
	}

	/**
	 * The path the site lives under, without slashes, or '' at the domain root.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  string
	 */
	public function site_path(): string {
		return $this->data['site_path'];
	}

	/**
	 * The detected language prefixes, keyed by prefix key.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  array<string, PrefixData>
	 */
	public function prefixes(): array {
		return $this->data['prefixes'];
	}

	/**
	 * Path starts the request check never answers, each beginning with `/`.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  list<string>
	 */
	public function excluded(): array {
		return $this->data['excluded'];
	}

	/**
	 * Returns a copy with the main on/off changed.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   bool $enabled The new value.
	 *
	 * @return  self
	 */
	public function with_enabled( bool $enabled ): self {
		return $this->with( array( 'enabled' => $enabled ) );
	}

	/**
	 * Returns a copy with miss caching changed.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   bool $cache_misses The new value.
	 *
	 * @return  self
	 */
	public function with_cache_misses( bool $cache_misses ): self {
		return $this->with( array( 'cache_misses' => $cache_misses ) );
	}

	/**
	 * Returns a copy with made-up segments after single items answered or not.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   bool $extra_segments The new value.
	 *
	 * @return  self
	 */
	public function with_extra_segments( bool $extra_segments ): self {
		return $this->with( array( 'extra_segments' => $extra_segments ) );
	}

	/**
	 * Returns a copy with loose mode turned on or off.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   bool $loose The new value.
	 *
	 * @return  self
	 */
	public function with_loose( bool $loose ): self {
		return $this->with( array( 'loose' => $loose ) );
	}

	/**
	 * Returns a copy with one shortcut turned on or off. Unknown keys are ignored.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $key     The shortcut key.
	 * @param   bool   $enabled The new value.
	 *
	 * @return  self
	 */
	public function with_shortcut_enabled( string $key, bool $enabled ): self {
		$shortcut = $this->data['shortcuts'][ $key ] ?? null;
		if ( null === $shortcut ) {
			return $this;
		}

		$shortcut['enabled'] = $enabled;
		$shortcuts           = $this->data['shortcuts'];
		$shortcuts[ $key ]   = $shortcut;

		return $this->with( array( 'shortcuts' => $shortcuts ) );
	}

	/**
	 * Returns a copy with one language prefix turned on or off. Unknown keys are ignored.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $key     The prefix key.
	 * @param   bool   $enabled The new value.
	 *
	 * @return  self
	 */
	public function with_prefix_enabled( string $key, bool $enabled ): self {
		$prefix = $this->data['prefixes'][ $key ] ?? null;
		if ( null === $prefix ) {
			return $this;
		}

		$prefix['enabled'] = $enabled;
		$prefixes          = $this->data['prefixes'];
		$prefixes[ $key ]  = $prefix;

		return $this->with( array( 'prefixes' => $prefixes ) );
	}

	/**
	 * Returns a copy with the excluded paths replaced.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   list<string> $excluded The paths.
	 *
	 * @return  self
	 */
	public function with_excluded( array $excluded ): self {
		return $this->with( array( 'excluded' => $excluded ) );
	}

	/**
	 * Returns a copy with fresh detection results. Existing on/off values are kept.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   array<string, ShortcutData> $shortcuts The detected shortcuts; their `enabled` is ignored.
	 * @param   array<string, string>       $sources   The values detection read.
	 * @param   int                         $at        When detection ran.
	 * @param   string                      $site_path The path the site lives under.
	 * @param   array<string, PrefixData>   $prefixes  The detected language prefixes; their `enabled` is ignored.
	 *
	 * @return  self
	 */
	public function with_detected( array $shortcuts, array $sources, int $at, string $site_path = '', array $prefixes = array() ): self {
		foreach ( $shortcuts as $key => $shortcut ) {
			$shortcuts[ $key ]['enabled'] = $this->data['shortcuts'][ $key ]['enabled'] ?? false;
		}

		foreach ( $prefixes as $key => $prefix ) {
			$prefixes[ $key ]['enabled'] = $this->data['prefixes'][ $key ]['enabled'] ?? false;
		}

		return $this->with(
			array(
				'shortcuts' => $shortcuts,
				'detected'  => array(
					'at'      => $at,
					'sources' => $sources,
				),
				'site_path' => $site_path,
				'prefixes'  => $prefixes,
			)
		);
	}

	/**
	 * Returns a copy with the stored page path changed.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $page_file Absolute path, or ''.
	 *
	 * @return  self
	 */
	public function with_page_file( string $page_file ): self {
		return $this->with( array( 'page_file' => $page_file ) );
	}

	/**
	 * Returns a copy with the page source changed. Unknown sources fall back to `captured`.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $page_source One of `PAGE_SOURCES`.
	 *
	 * @return  self
	 */
	public function with_page_source( string $page_source ): self {
		return $this->with( array( 'page_source' => $page_source ) );
	}

	/**
	 * The choices a person makes, without anything site-specific, for copying between sites.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  array{enabled: bool, cache_misses: bool, extra_segments: bool, loose: bool, shortcuts: list<string>, prefixes: list<string>, excluded: list<string>}
	 */
	public function choices(): array {
		return array(
			'enabled'        => $this->data['enabled'],
			'cache_misses'   => $this->data['cache_misses'],
			'extra_segments' => $this->data['extra_segments'],
			'loose'          => $this->data['loose'],
			'shortcuts'      => \array_keys( \array_filter( $this->data['shortcuts'], static fn ( array $shortcut ): bool => $shortcut['enabled'] ) ),
			'prefixes'       => \array_keys( \array_filter( $this->data['prefixes'], static fn ( array $prefix ): bool => $prefix['enabled'] ) ),
			'excluded'       => $this->data['excluded'],
		);
	}

	/**
	 * Returns a copy with exported choices applied. Keys this site does not have are ignored.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   mixed $choices The decoded choices, as `choices()` returns them.
	 *
	 * @return  self
	 */
	public function with_choices( mixed $choices ): self {
		$choices  = \is_array( $choices ) ? $choices : array();
		$shortcut = \is_array( $choices['shortcuts'] ?? null ) ? $choices['shortcuts'] : array();
		$prefix   = \is_array( $choices['prefixes'] ?? null ) ? $choices['prefixes'] : array();

		$settings = $this
			->with_enabled( true === ( $choices['enabled'] ?? false ) )
			->with_cache_misses( true === ( $choices['cache_misses'] ?? true ) )
			->with_extra_segments( true === ( $choices['extra_segments'] ?? false ) )
			->with_loose( true === ( $choices['loose'] ?? false ) )
			->with_excluded( self::clean_paths( $choices['excluded'] ?? null ) );
		foreach ( \array_keys( $this->data['shortcuts'] ) as $key ) {
			$settings = $settings->with_shortcut_enabled( $key, \in_array( $key, $shortcut, true ) );
		}
		foreach ( \array_keys( $this->data['prefixes'] ) as $key ) {
			$settings = $settings->with_prefix_enabled( $key, \in_array( $key, $prefix, true ) );
		}

		return $settings;
	}

	/**
	 * Cleans a list of path starts: each gets a leading `/`, and empty or odd ones are dropped.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   mixed $paths The raw list.
	 *
	 * @return  list<string>
	 */
	public static function clean_paths( mixed $paths ): array {
		$clean = array();
		foreach ( \is_array( $paths ) ? $paths : array() as $path ) {
			if ( ! \is_string( $path ) ) {
				continue;
			}

			$path = \trim( $path );
			if ( '' === \trim( $path, '/' ) || 1 !== \preg_match( self::PATH_PATTERN, $path ) ) {
				continue;
			}

			$clean[] = '/' . \ltrim( $path, '/' );
		}

		return \array_values( \array_unique( $clean ) );
	}

	// endregion

	// region HELPERS

	/**
	 * Returns a copy with some stored values replaced, cleaned again.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   array<string, mixed> $changes The values to replace.
	 *
	 * @return  self
	 */
	private function with( array $changes ): self {
		return self::from_array( \array_replace( $this->data, $changes ) );
	}

	/**
	 * Cleans one stored shortcut, or returns null when it does not fit.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $key      The shortcut key.
	 * @param   mixed  $shortcut The raw shortcut.
	 *
	 * @return  ShortcutData|null
	 */
	private static function clean_shortcut( string $key, mixed $shortcut ): ?array {
		if ( ! \is_array( $shortcut ) || 1 !== \preg_match( '/^[a-z_]+(?::[a-z0-9_-]+)?$/', $key ) ) {
			return null;
		}

		$type = $shortcut['type'] ?? null;
		if ( ! \is_string( $type ) || ! \in_array( $type, self::SHORTCUT_TYPES, true ) ) {
			return null;
		}

		return array(
			'type'         => $type,
			'name'         => \is_string( $shortcut['name'] ?? null ) ? $shortcut['name'] : '',
			'base'         => \is_string( $shortcut['base'] ?? null ) ? \trim( $shortcut['base'], '/' ) : '',
			'hierarchical' => true === ( $shortcut['hierarchical'] ?? false ),
			'label'        => \is_string( $shortcut['label'] ?? null ) ? $shortcut['label'] : $key,
			'enabled'      => true === ( $shortcut['enabled'] ?? false ),
		);
	}

	/**
	 * Cleans one stored language prefix, or returns null when it does not fit.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $key    The prefix key.
	 * @param   mixed  $prefix The raw prefix.
	 *
	 * @return  PrefixData|null
	 */
	private static function clean_prefix( string $key, mixed $prefix ): ?array {
		if ( ! \is_array( $prefix ) || 1 !== \preg_match( '/^[a-z_]+$/', $key ) ) {
			return null;
		}

		$values = array();
		foreach ( \is_array( $prefix['values'] ?? null ) ? $prefix['values'] : array() as $value ) {
			$value = \is_string( $value ) ? \trim( $value, '/' ) : '';
			if ( '' !== $value && 1 === \preg_match( self::PATH_PATTERN, $value ) ) {
				$values[] = $value;
			}
		}

		if ( array() === $values ) {
			return null;
		}

		return array(
			'label'   => \is_string( $prefix['label'] ?? null ) ? $prefix['label'] : $key,
			'values'  => \array_values( \array_unique( $values ) ),
			'enabled' => true === ( $prefix['enabled'] ?? false ),
		);
	}

	/**
	 * Cleans the stored detection record.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   mixed $detected The raw record.
	 *
	 * @return  DetectedData
	 */
	private static function clean_detected( mixed $detected ): array {
		$detected = \is_array( $detected ) ? $detected : array();

		$sources = array();
		foreach ( \is_array( $detected['sources'] ?? null ) ? $detected['sources'] : array() as $name => $source ) {
			if ( \is_string( $source ) ) {
				$sources[ (string) $name ] = $source;
			}
		}

		return array(
			'at'      => \is_int( $detected['at'] ?? null ) ? $detected['at'] : 0,
			'sources' => $sources,
		);
	}

	// endregion
}
