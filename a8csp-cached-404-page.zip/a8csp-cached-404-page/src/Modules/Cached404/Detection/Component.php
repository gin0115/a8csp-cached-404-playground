<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Detection;

use A8C\SpecialProjects\A8cspCached404Page\AbstractComponent;
use A8C\SpecialProjects\A8cspCached404Page\Settings\Settings;

\defined( 'ABSPATH' ) || exit;

/**
 * Re-runs detection on the next admin request after the site changes. Taxonomies keep the rewrite
 * slug they registered with on `init`, so re-detecting in the request that saved new permalinks
 * would read the old bases; the redirect back to the admin is the first request that sees the new ones.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class Component extends AbstractComponent {
	// region METHODS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function register_hooks(): void {
		add_action( 'admin_init', array( $this, 'maybe_redetect' ) );
	}

	// endregion

	// region HOOKS

	/**
	 * Re-detects and saves when the stored detection no longer matches the site. Skipped until
	 * detection has run once, so a site that never set the plugin up is left untouched.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function maybe_redetect(): void {
		if ( wp_doing_ajax() ) {
			return;
		}

		$settings = Settings::load();
		$detector = new Detector();
		if ( 0 === $settings->detected()['at'] || ! $detector->is_stale( $settings ) ) {
			return;
		}

		$detector->detect( $settings )->save();
	}

	// endregion
}
