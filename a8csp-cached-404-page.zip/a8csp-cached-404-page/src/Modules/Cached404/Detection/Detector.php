<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Detection;

use A8C\SpecialProjects\A8cspCached404Page\Detection\Language\LanguageDetectorInterface;
use A8C\SpecialProjects\A8cspCached404Page\Detection\Language\Polylang;
use A8C\SpecialProjects\A8cspCached404Page\Detection\Language\TranslatePress;
use A8C\SpecialProjects\A8cspCached404Page\Detection\Language\Weglot;
use A8C\SpecialProjects\A8cspCached404Page\Detection\Language\Wpml;
use A8C\SpecialProjects\A8cspCached404Page\Request\Shortcut\Post;
use A8C\SpecialProjects\A8cspCached404Page\Settings\Settings;

\defined( 'ABSPATH' ) || exit;

/**
 * Builds the list of URL types and path prefixes the site can short-cut from what it has
 * registered. Runs only once plugins and the theme have loaded (admin requests and WP-CLI), never
 * in the request check.
 *
 * @since   1.0.0
 * @version 1.0.0
 *
 * @phpstan-import-type ShortcutData from Settings
 * @phpstan-import-type PrefixData from Settings
 */
final class Detector {
	// region FIELDS AND CONSTANTS

	/**
	 * The translation plugins detection knows. Add a class here to support another one.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @var     list<class-string<LanguageDetectorInterface>>
	 */
	private const array LANGUAGE_DETECTORS = array(
		Polylang::class,
		Wpml::class,
		TranslatePress::class,
		Weglot::class,
	);

	/**
	 * Taxonomies whose URL slug is not the stored term slug, so a slug check would get them wrong.
	 * `post_format` maps `/type/aside/` to the term `post-format-aside` (see `_post_format_request()`).
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @var     list<string>
	 */
	private const array SKIPPED_TAXONOMIES = array( 'post_format' );

	/**
	 * Post types with no URL base of their own: posts follow the permalink structure (see `Post`),
	 * and pages and attachments sit at the top level, which the request check never claims.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @var     list<string>
	 */
	private const array SKIPPED_POST_TYPES = array( 'post', 'page', 'attachment' );

	// endregion

	// region METHODS

	/**
	 * Returns the settings with freshly detected shortcuts and sources.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The current settings.
	 *
	 * @return  Settings
	 */
	public function detect( Settings $settings ): Settings {
		return $settings->with_detected( $this->shortcuts(), $this->sources(), \time(), $this->site_path(), $this->prefixes() );
	}

	/**
	 * The values detection depends on. When these change, detection is out of date.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  array<string, string>
	 */
	public function sources(): array {
		return array(
			'permalink_structure'  => (string) get_option( 'permalink_structure', '' ),
			'tag_base'             => (string) get_option( 'tag_base', '' ),
			'category_base'        => (string) get_option( 'category_base', '' ),
			'permalink_endpoints'  => \implode( ',', $this->permalink_endpoints() ),
			'verbose_page_rules'   => $this->verbose_page_rules() ? '1' : '',
			'post_type_query_vars' => \implode( ',', $this->post_type_query_vars() ),
			'archive_paths'        => \implode( ',', $this->archive_paths() ),
		);
	}

	/**
	 * Whether the stored detection no longer matches the site: a source value changed, or a URL
	 * type was added, removed or moved.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   Settings $settings The current settings.
	 *
	 * @return  bool
	 */
	public function is_stale( Settings $settings ): bool {
		if ( $settings->detected()['sources'] !== $this->sources() || $settings->site_path() !== $this->site_path() ) {
			return true;
		}

		$stored_shortcuts = array();
		foreach ( $settings->shortcuts() as $key => $shortcut ) {
			$shortcut['enabled']      = false;
			$stored_shortcuts[ $key ] = $shortcut;
		}

		$stored_prefixes = array();
		foreach ( $settings->prefixes() as $key => $prefix ) {
			$prefix['enabled']       = false;
			$stored_prefixes[ $key ] = $prefix;
		}

		return $stored_shortcuts !== $this->shortcuts() || $stored_prefixes !== $this->prefixes();
	}

	// endregion

	// region HELPERS

	/**
	 * Whether WordPress checks that a page exists before using a page rewrite rule, and otherwise
	 * tries the next rule.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  bool
	 */
	private function verbose_page_rules(): bool {
		global $wp_rewrite;

		return $wp_rewrite instanceof \WP_Rewrite && true === $wp_rewrite->use_verbose_page_rules;
	}

	/**
	 * The query variables publicly queryable post types use to name an item, such as `product`,
	 * sorted.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  list<string>
	 */
	private function post_type_query_vars(): array {
		$vars = array();
		foreach ( get_post_types( array( 'publicly_queryable' => true ), 'objects' ) as $post_type ) {
			if ( \is_string( $post_type->query_var ) && '' !== $post_type->query_var ) {
				$vars[] = $post_type->query_var;
			}
		}

		$vars = \array_values( \array_unique( $vars ) );
		\sort( $vars );

		return $vars;
	}

	/**
	 * The endpoints registered for single items (`EP_PERMALINK`), such as
	 * `/product/<slug>/<endpoint>/`, lower-cased and sorted.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  list<string>
	 */
	private function permalink_endpoints(): array {
		global $wp_rewrite;

		$names = array();
		foreach ( $wp_rewrite instanceof \WP_Rewrite ? $wp_rewrite->endpoints : array() as $endpoint ) {
			if ( \is_array( $endpoint ) && \is_int( $endpoint[0] ?? null ) && \is_string( $endpoint[1] ?? null ) && 0 !== ( $endpoint[0] & EP_PERMALINK ) ) {
				$names[] = \strtolower( $endpoint[1] );
			}
		}

		$names = \array_values( \array_unique( $names ) );
		\sort( $names );

		return $names;
	}

	/**
	 * The fixed start of the author archive's and every other registered archive's address, such as
	 * `blog/type` from `/blog/type/%post_format%`, lower-cased and sorted. Under a structure with a
	 * front these share the shape of an item and a made-up segment.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  list<string>
	 */
	private function archive_paths(): array {
		global $wp_rewrite;

		if ( ! $wp_rewrite instanceof \WP_Rewrite ) {
			return array();
		}

		$structs = array( (string) $wp_rewrite->get_author_permastruct() );
		foreach ( $wp_rewrite->extra_permastructs as $permastruct ) {
			$structs[] = \is_array( $permastruct ) && \is_string( $permastruct['struct'] ?? null ) ? $permastruct['struct'] : '';
		}

		$paths = array();
		foreach ( $structs as $struct ) {
			$fixed = \strstr( $struct, '%', true );
			$fixed = \strtolower( \trim( false === $fixed ? '' : $fixed, '/' ) );
			if ( '' !== $fixed && 1 === \preg_match( '#^[a-z0-9/_.-]+$#', $fixed ) ) {
				$paths[] = $fixed;
			}
		}

		$paths = \array_values( \array_unique( $paths ) );
		\sort( $paths );

		return $paths;
	}

	/**
	 * The folder the site lives under, from the path part of `home`, without slashes.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  string
	 */
	private function site_path(): string {
		$path = wp_parse_url( home_url(), PHP_URL_PATH );

		return \is_string( $path ) ? \trim( $path, '/' ) : '';
	}

	/**
	 * One prefix per active translation plugin that puts languages in folders.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  array<string, PrefixData>
	 */
	private function prefixes(): array {
		$prefixes = array();
		foreach ( self::LANGUAGE_DETECTORS as $class ) {
			$detector = new $class();
			$folders  = $detector->folders();
			if ( null !== $folders ) {
				$prefixes[ $detector->key() ] = array(
					'label'   => $detector->label(),
					'values'  => $folders,
					'enabled' => false,
				);
			}
		}

		return $prefixes;
	}

	/**
	 * One shortcut per public taxonomy that has a pretty URL base.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  array<string, ShortcutData>
	 */
	private function shortcuts(): array {
		$shortcuts = array();
		foreach ( get_taxonomies( array( 'public' => true ), 'objects' ) as $taxonomy ) {
			if ( \in_array( $taxonomy->name, self::SKIPPED_TAXONOMIES, true ) || ! is_taxonomy_viewable( $taxonomy ) ) {
				continue;
			}

			$base = $this->base( $taxonomy->name );
			if ( null === $base ) {
				continue;
			}

			$shortcuts[ 'taxonomy:' . $taxonomy->name ] = array(
				'type'         => 'taxonomy',
				'name'         => $taxonomy->name,
				'base'         => $base,
				'hierarchical' => \is_array( $taxonomy->rewrite ) && true === ( $taxonomy->rewrite['hierarchical'] ?? false ),
				'label'        => $taxonomy->label,
				'enabled'      => false,
			);
		}

		$structure = (string) get_option( 'permalink_structure', '' );
		if ( null !== Post::pattern( $structure ) ) {
			$shortcuts['post_type:post'] = array(
				'type'         => 'post',
				'name'         => 'post',
				'base'         => \trim( $structure, '/' ),
				'hierarchical' => false,
				'label'        => __( 'Posts', 'a8csp-cached-404-page' ),
				'enabled'      => false,
			);
		}

		foreach ( get_post_types( array( 'public' => true ), 'objects' ) as $post_type ) {
			// A type that is not viewable has no front-end URLs to answer.
			if ( \in_array( $post_type->name, self::SKIPPED_POST_TYPES, true ) || ! is_post_type_viewable( $post_type ) ) {
				continue;
			}

			$base = $this->base( $post_type->name );
			if ( null === $base ) {
				continue;
			}

			$shortcuts[ 'post_type:' . $post_type->name ] = array(
				'type'         => 'post_type',
				'name'         => $post_type->name,
				'base'         => $base,
				'hierarchical' => $post_type->hierarchical,
				'label'        => $post_type->label,
				'enabled'      => false,
			);
		}

		global $wp_rewrite;
		$author_base = $wp_rewrite instanceof \WP_Rewrite ? $this->base_from( (string) $wp_rewrite->get_author_permastruct(), 'author' ) : null;
		if ( null !== $author_base ) {
			$shortcuts['author'] = array(
				'type'         => 'author',
				'name'         => 'author',
				'base'         => $author_base,
				'hierarchical' => false,
				'label'        => __( 'Authors', 'a8csp-cached-404-page' ),
				'enabled'      => false,
			);
		}

		return $shortcuts;
	}

	/**
	 * The URL base in front of `%name%` in the registered extra permastruct, or null when there is
	 * none or it holds other placeholders.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $name The taxonomy or post type name.
	 *
	 * @return  string|null
	 */
	private function base( string $name ): ?string {
		global $wp_rewrite;

		$struct = $wp_rewrite instanceof \WP_Rewrite ? $wp_rewrite->get_extra_permastruct( $name ) : false;

		return \is_string( $struct ) ? $this->base_from( $struct, $name ) : null;
	}

	/**
	 * The URL base in front of `%tag%` in a permastruct, or null when there is none or it holds
	 * other placeholders.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @param   string $struct The permastruct, such as `/tag/%post_tag%`.
	 * @param   string $tag    The placeholder name without its `%` signs.
	 *
	 * @return  string|null
	 */
	private function base_from( string $struct, string $tag ): ?string {
		$position = \strpos( $struct, '%' . $tag . '%' );
		if ( false === $position ) {
			return null;
		}

		$base = \trim( \substr( $struct, 0, $position ), '/' );

		return '' === $base || \str_contains( $base, '%' ) ? null : $base;
	}

	// endregion
}
