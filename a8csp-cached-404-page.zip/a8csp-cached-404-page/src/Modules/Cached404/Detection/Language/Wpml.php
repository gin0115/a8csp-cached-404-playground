<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Detection\Language;

\defined( 'ABSPATH' ) || exit;

/**
 * WPML in folder mode. Its translations are normal terms and posts. Read through WPML's own
 * `wpml_setting` filter, which answers the default when WPML is not active. `language_negotiation_type`
 * 1 is folders (2 is domains, confirmed in WPML's code; 1 and 3 from one third-party guide).
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class Wpml implements LanguageDetectorInterface {
	// region METHODS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function key(): string {
		return 'wpml';
	}

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function label(): string {
		return 'WPML';
	}

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function folders(): ?array {
		$negotiation = apply_filters( 'wpml_setting', false, 'language_negotiation_type' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WPML's own filter.
		if ( ! \in_array( $negotiation, array( 1, '1' ), true ) ) {
			return null;
		}

		$languages = apply_filters( 'wpml_setting', array(), 'active_languages' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WPML's own filter.
		if ( ! \is_array( $languages ) ) {
			return null;
		}

		// Accept a list of codes or an array keyed by code, since the stored shape is not documented.
		$folders = array();
		foreach ( $languages as $key => $language ) {
			$code = \is_string( $language ) ? $language : ( \is_string( $key ) ? $key : '' );
			if ( 1 === \preg_match( '/^[A-Za-z0-9_-]+$/', $code ) ) {
				$folders[] = $code;
			}
		}

		return array() === $folders ? null : $folders;
	}

	// endregion
}
