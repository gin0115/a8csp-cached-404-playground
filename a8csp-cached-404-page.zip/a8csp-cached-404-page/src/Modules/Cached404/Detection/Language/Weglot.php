<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Detection\Language;

\defined( 'ABSPATH' ) || exit;

/**
 * Weglot, which always puts languages in folders. Its translated slugs are not in `wp_terms` or
 * `wp_posts`, so `Request\Prefix\WeglotPrefix` swaps them back from Weglot's own stored list when a
 * request comes in. Read from Weglot 6.4.2.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class Weglot implements LanguageDetectorInterface {
	// region FIELDS AND CONSTANTS

	/**
	 * The prefix key, which also gives these folders `WeglotPrefix` instead of `LanguagePrefix`.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	public const string KEY = 'weglot';

	// endregion

	// region METHODS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function key(): string {
		return self::KEY;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function label(): string {
		return 'Weglot';
	}

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function folders(): ?array {
		if ( ! \function_exists( 'weglot_get_service' ) ) {
			return null;
		}

		try {
			$service = weglot_get_service( 'Language_Service_Weglot' );
		} catch ( \Throwable ) {
			return null;
		}

		// Public languages only, by the code Weglot puts in the address: the custom code when set.
		$codes = \is_object( $service ) && \method_exists( $service, 'get_destination_languages_external' ) ? $service->get_destination_languages_external() : null;
		if ( ! \is_array( $codes ) ) {
			return null;
		}

		$folders = array();
		foreach ( $codes as $code ) {
			if ( \is_string( $code ) && 1 === \preg_match( '/^[A-Za-z0-9_-]+$/', $code ) ) {
				$folders[] = $code;
			}
		}

		return array() === $folders ? null : $folders;
	}

	// endregion
}
