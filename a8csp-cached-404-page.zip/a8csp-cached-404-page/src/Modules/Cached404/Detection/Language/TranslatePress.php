<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Detection\Language;

\defined( 'ABSPATH' ) || exit;

/**
 * TranslatePress. Without its paid SEO Pack (`TRP_IN_Seo_Pack`, `TRP_Seo_Pack` before) it does not
 * translate slugs, so every published language's folder is safe to remove. With the SEO Pack,
 * translated slugs live in its own tables, not `wp_terms`, so only the default language's folder is.
 * The default language has a folder only when `add-subdirectory-to-default-language` is on.
 * Read from TranslatePress 3.3.7.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class TranslatePress implements LanguageDetectorInterface {
	// region METHODS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function key(): string {
		return 'translatepress';
	}

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function label(): string {
		return 'TranslatePress';
	}

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function folders(): ?array {
		if ( ! \class_exists( 'TRP_Translate_Press', false ) ) {
			return null;
		}

		$settings = get_option( 'trp_settings' );
		if ( ! \is_array( $settings ) ) {
			return null;
		}

		$default = $settings['default-language'] ?? null;
		$slugs   = $settings['url-slugs'] ?? null;
		if ( ! \is_string( $default ) || ! \is_array( $slugs ) ) {
			return null;
		}

		$seo_pack  = \class_exists( 'TRP_IN_Seo_Pack' ) || \class_exists( 'TRP_Seo_Pack' );
		$languages = ! $seo_pack && \is_array( $settings['publish-languages'] ?? null ) ? $settings['publish-languages'] : array( $default );

		$folders = array();
		foreach ( $languages as $language ) {
			if ( $default === $language && 'yes' !== ( $settings['add-subdirectory-to-default-language'] ?? 'no' ) ) {
				continue;
			}

			$slug = \is_string( $language ) ? ( $slugs[ $language ] ?? null ) : null;
			if ( \is_string( $slug ) && 1 === \preg_match( '/^[A-Za-z0-9_-]+$/', $slug ) ) {
				$folders[] = $slug;
			}
		}

		return array() === $folders ? null : $folders;
	}

	// endregion
}
