<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Detection\Language;

\defined( 'ABSPATH' ) || exit;

/**
 * Reads one translation plugin's language folders while plugins are loaded. Only folders whose
 * translated slugs live in the normal WordPress tables may be returned; anything else must stay
 * on the path, so those URLs match no shortcut.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
interface LanguageDetectorInterface {
	// region METHODS

	/**
	 * The prefix key, used in the settings and WP-CLI.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  string
	 */
	public function key(): string;

	/**
	 * The name shown on the admin page.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  string
	 */
	public function label(): string;

	/**
	 * The language folders, without slashes, or null when the plugin is not active or does not
	 * put languages in folders.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  list<string>|null
	 *
	 * @phpstan-impure
	 */
	public function folders(): ?array;

	// endregion
}
