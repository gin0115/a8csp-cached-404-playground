<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page\Detection\Language;

\defined( 'ABSPATH' ) || exit;

/**
 * Polylang in folder mode. Its translations are normal terms and posts, so a slug check stays
 * correct once the folder is removed. Option values from Polylang 3.8: `force_lang` 1 is "the
 * language is set from the directory name", and with `rewrite` off the folder sits under `language/`.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class Polylang implements LanguageDetectorInterface {
	// region METHODS

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function key(): string {
		return 'polylang';
	}

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function label(): string {
		return 'Polylang';
	}

	/**
	 * {@inheritDoc}
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 */
	#[\Override]
	public function folders(): ?array {
		if ( ! \function_exists( 'pll_languages_list' ) ) {
			return null;
		}

		$options = get_option( 'polylang' );
		if ( ! \is_array( $options ) || ! \in_array( $options['force_lang'] ?? null, array( 1, '1' ), true ) ) {
			return null;
		}

		$languages = pll_languages_list( array( 'fields' => 'slug' ) );
		if ( ! \is_array( $languages ) ) {
			return null;
		}

		$base    = \in_array( $options['rewrite'] ?? 1, array( 0, '0', false ), true ) ? 'language/' : '';
		$folders = array();
		foreach ( $languages as $slug ) {
			if ( \is_string( $slug ) && '' !== $slug ) {
				$folders[] = $base . $slug;
			}
		}

		return array() === $folders ? null : $folders;
	}

	// endregion
}
