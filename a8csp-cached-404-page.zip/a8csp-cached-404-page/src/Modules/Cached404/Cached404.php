<?php declare( strict_types=1 );

namespace A8C\SpecialProjects\A8cspCached404Page;

\defined( 'ABSPATH' ) || exit;

/**
 * The Cached 404 module, laid out as an Atlantis module: `initialize()` starts its components.
 *
 * @since   1.0.0
 * @version 1.0.0
 */
final class Cached404 {
	// region FIELDS AND CONSTANTS

	/**
	 * The module's components; they run through each phase in this order.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @var     array<int, class-string<ComponentInterface>>
	 */
	private const array COMPONENTS = array(
		Request\Component::class,
		Detection\Component::class,
		Settings\Component::class,
		Page\Component::class,
		CLI\Component::class,
	);

	// endregion

	// region METHODS

	/**
	 * The module's name.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  string
	 */
	public function get_name(): string {
		return 'Cached 404';
	}

	/**
	 * The module's short description.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  string
	 */
	public function get_description(): string {
		return __( 'Answers requests for terms, posts, items and authors that do not exist with a stored 404 page, before plugins and the theme load.', 'a8csp-cached-404-page' );
	}

	/**
	 * Builds the components and registers their hooks.
	 *
	 * @since   1.0.0
	 * @version 1.0.0
	 *
	 * @return  void
	 */
	public function initialize(): void {
		$components = ComponentCollection::assemble( self::COMPONENTS );
		$components->initialize();
		$components->register_hooks();
	}

	// endregion
}
